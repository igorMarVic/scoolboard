<?php
	$host = "localhost";
	$user = "user_tcc";
	$password = "";
	$database = "sistema_tcc";

	$url = "http://localhost/tcc/quati/src/";
?>
