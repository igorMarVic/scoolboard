<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
require 'PHPMailer/PHPMailer/src/OAuth.php';

include_once "config.php";
include_once "connection.php";
$conexao = new Connection($host, $user, $password, $database);

?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Login</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">

    <link rel="manifest" href="../manifest.json">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#1B7A0C">

    <link rel="apple-touch-icon" sizes="57x57" href="../images/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="../images/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="../images/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="../images/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="../images/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="../images/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="../images/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="../images/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="../images/apple-icon-180x180.png">
    <link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="../images/favicon.ico" type="image/x-icon">

    <!--<link rel="icon" type="image/png" sizes="192x192"  href="../images/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="../images/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../images/favicon-16x16.png">-->

    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="InFo">
    <link rel="apple-touch-icon" href="../images/icons/icon-152x152.png">
    <meta name="msapplication-TileImage" content="../images/icons/icon-144x144.png">
    <meta name="msapplication-TileColor" content="#1B7A0C">

  </head>

  <body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>
<?php
		date_default_timezone_set("America/Sao_Paulo");
		if (isset($_POST['acao']) && $_POST['acao'] == 'recuperar'):
			$email= strip_tags(filter_input(INPUT_POST, 'emailRecupera', FILTER_SANITIZE_STRING));

			$sql = "SELECT email_professor FROM professor WHERE email_professor ='$email'";
			$conexao->query($sql);

			if($conexao->num_rows() ==1) {
				echo "$email";
				$codigo = base64_encode($email);
				$data_expirar= date('Y-m-d H:i:s', strtotime('+1 day'));

				try {
          $mail = new PHPMailer;
          $mail->CharSet = "UTF-8";
          $mail->IsSMTP();
          $mail->SMPTSecure = 'starttls';

          $mail->Host = 'smtp-mail.outlook.com';
          $mail->SMTPAuth = true;
          $mail->Port = 587;
          $mail->Username ='scooboard@outlook.com';
          $mail->Password ='boardscool2019';
          $mail->SetFrom('scooboard@outlook.com','Recuperação de Senha');
          $mail->AddReplyTo('scooboard@outlook.com','Recuperação de Senha');
          $mail->Subject='Alteração da senha';

					//EMAIL DO USUARIO
					$mail->AddAddress($email,'Alteração da senha');

					$mail ->MsgHTML('<p>Recebemos uma tentativa de recuperação de senha para este e-mail, caso não tenha sido você, desconsidere este e-mail, caso contrário clique no link abaixo <br /> <a href="localhost/tcc/quati/src/recuperar.php?codigo='.$codigo.'">Link</a> </p>');

					$enviado = $mail->Send();

					//ISSO VERIFICA SE O EMAIL FOI ENVIADO TAOQUEI


					if ($enviado) {
						echo "sucesso";
						$sql2 = "INSERT INTO recuperacao_senha SET codigo_re = '$codigo', data = '$data_expirar'";
						$conexao->query($sql2);
						?>
						<script type="text/javascript">
						alert( "Link enviado para o email com sucesso" );
						</script>
						<?php
						header("Refresh: 0; url=login.php");
						exit(0);
					}else {
						echo "erro tentar novamente";
						header("Refresh: 2; url=login.php");
						exit(0);
					}



				} catch (phpmailerException $e) {
					echo $e->errorMessage();
				}

			}else{

				$sql = "SELECT email_aluno FROM aluno WHERE email_aluno ='$email'";
				$conexao->query($sql);

				if($conexao->num_rows() ==1) {
					echo "$email";
					$codigo = base64_encode($email);
					$data_expirar= date('Y-m-d H:i:s', strtotime('+1 day'));

					try {
						$mail = new PHPMailer;
						$mail->CharSet = "UTF-8";
						$mail->IsSMTP();
						$mail->SMPTSecure = 'starttls';

						$mail->Host = 'smtp-mail.outlook.com';
						$mail->SMTPAuth = true;
						$mail->Port = 587;
            $mail->Username ='scooboard@outlook.com';
  					$mail->Password ='boardscool2019';
  					$mail->SetFrom('scooboard@outlook.com','Recuperação de Senha');
  					$mail->AddReplyTo('scooboard@outlook.com','Recuperação de Senha');
						$mail->Subject='Alteração da senha';

						//EMAIL DO USUARIO
						$mail->AddAddress($email,'Alteração da senha');

						$mail ->MsgHTML('<p>Recebemos uma tentativa de recuperação de senha para este e-mail, caso não tenha sido você, desconsidere este e-mail, caso contrário clique no link abaixo <br /> <a href="localhost/tcc/quati/src/recuperar.php?codigo='.$codigo.'">Link</a> </p>');

						$email_enviado= $mail ->Send();

						if ($email_enviado) {
							echo "sucesso";
							$sql2 = "INSERT INTO recuperacao_senha SET codigo_re = '$codigo', data = '$data_expirar'";
							$conexao->query($sql2);
							?>
							<script type="text/javascript">
							alert( "Link enviado para o email com sucesso" );
							</script>
							<?php
							header("Refresh: 0; url=login.php");
							exit(0);
						}else {
							?>
							<script type="text/javascript">
								alert("erro ao tentar enviar, tente novamente");
							</script>
							<?php

							header("Refresh: 0; url=login.php");
							exit(0);
						}


				}catch (phpmailerException $e) {
					echo $e->errorMessage();
				}


			}else {
				?>
				<script type="text/javascript">
					alert("Não tem esse email cadastrado");
				</script>
				<?php

				}
			}
		endif;

		?>


    <?php
    if (isset($_GET['recuperar']) && $_GET['recuperar'] == 'sim') {
    ?>


    <div class="container mt-4 row m-0" >
      <div class="col-2">        </div>
      <div class="col-3 h3">
        Digite ao lado um email para a recuperação da sua senha
      </div>
      <div class="jumbotron px-6 pt-4 pb-2 justify-content-center mt-2 bg-dark text-center">
        <div class="">


    <form class="" action="" method="post" enctype="multipart/form-data"  name="dados" onSubmit="return enviardados_user();">
      <div class="form-row text-white">
      <div class="form-group col-md-12">
      <label for="nome">
                  E-mail:
</label>

              <input type="text" name="emailRecupera" placeholder="	">

              <input  type="hidden" name="acao" value="recuperar">

      </div>

      <input type="submit" class="btn btn-primary btn-outline-light mr-auto ">Enviar</input>
    </form>
</div>
</div>
</div>




    </div>
      </div>
      <script type="text/javascript">
      function enviardados_user(){

        var motivo;

        //verifica campos vazios
        if(document.dados.emailRecupera.value=="")
        {
          alert( "Preencha campo do EMAIL corretamente!" );
          document.dados.emailRecupera.focus();
          return false;
        }
      }
      </script>

    </form>
  <?php }else{ ?>
    <div class="container" >
      <h1 class="text-center text-white mb-4 pt-5">Login</h1>
      <div class="row d-flex" id="externa">
      <div class="col-sm-12 col-p-12 col-lg-6 col-md-12 m-4 bg-dark text-white p-4 rounded" >
        <form action="processa.php" method="post">
          <div class="form-group">
            <label for="perfil" class="texto">Entrar como: </label>
            <select class="form-control" id="perfil" name="perfil">
              <option value="">Selecione:</option>
              <option value="estudante">Aluno</option>
              <option value="professor">Professor</option>
              <option value="administrador">Administrador</option>
            </select>
          </div>
            <div class="form-group">
              <label for="email">Email Institucional:</label>
              <input type="email" class="form-control" id="email" name="email" placeholder="Email Institucional">
            </div>
            <div class="form-group">
              <label for="senha">Senha:</label>
              <input type="password" class="form-control" id="senha" name="senha" placeholder="Senha">
            </div>

            <button type="submit" class=" mr-auto  btn btn-primary btn-outline-light">Entrar</button>
            <br><a href="?recuperar=sim" style="text-align:right;color:white;">Esqueceu sua senha?</a>
        </form>
      </div>
    </div>
  </div>
<?php } ?>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
