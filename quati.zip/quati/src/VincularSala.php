<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">
          <h3 class="text-white">Vincular Salas</h3>

          <div class="row d-flex">

            <div class="col-sm-12 col-p-6 col-lg-12 col-md-12 mb-4" id="SalaDisciplina">

                  <div id="DivVinculoSala" class="jumbotron p-4 mt-2 bg-dark">
                      <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                          <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-cadastro-vinculo-sala" role="tab" aria-controls="nav-home" aria-selected="true">Vincular</a>
                        </div>
                      </nav>
                      <div class="tab-content" id="nav-tabContent">

                        <div class="tab-pane fade show active text-white" id="nav-cadastro-vinculo-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                          <form action="processa.php" class="form-group" method="POST">

                            <div class="row d-flex text-white">
                              <div class="form-group col-xl-3 col-lg-3 col-p-12 col-md-12 col-sm-12">
                                <label for="nome">Código da Sala:</label>
                                <div class="input select">
                                  <select name="cod_sala" class="form-control" id="cod_sala">
                                    <option value="">Selecione:</option>
                                    <<?php
                                    include_once "config.php";
                                    include_once "connection.php";

                                    session_start();

                                    $conexao = new Connection($host, $user, $password, $database);

                                    $sql ="SELECT cod_sala FROM sala ORDER BY cod_sala";
                                    $conexao->query($sql);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo"<option value='$tupla[cod_sala]'> $tupla[cod_sala]</option>";
                                    }
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <input type="hidden" name="semestre" value="<?php echo $_GET['semestre']; ?>">
                              <input type="hidden" name="curso" value="<?php echo $_GET['curso']; ?>">
                              <div class="form-group col-xl-9 col-lg-12 col-p-9 col-sm-12 col-md-12">
                                <label for="nome">Código da Disciplina:</label>
                                <div class="input select">
                                  <select name="cod_disciplina" class="form-control" id="cod_disciplina">
                                    <option value="">Selecione:</option>
                                    <?php
                                    include_once "config.php";
                                    include_once "connection.php";

                                    session_start();

                                    $semestre=$_GET['semestre'];

                                    $curso= $_GET['curso'];

                                    $comum="comum";

                                    $conexao = new Connection($host, $user, $password, $database);

                                    $sql ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina WHERE periodo_disciplina LIKE '%$semestre%' AND curso_disciplina LIKE '%$curso%' ORDER BY descricao_disciplina";
                                    $conexao->query($sql);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo"<option value='$tupla[cod_disciplina]'> $tupla[cod_disciplina] - $tupla[descricao_disciplina]</option>";
                                    }
                                    $sql2 ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina WHERE periodo_disciplina LIKE '%$semestre%' AND curso_disciplina LIKE '%$comum%'";
                                    $conexao->query($sql2);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo"<option value='$tupla[cod_disciplina]'> $tupla[cod_disciplina] - $tupla[descricao_disciplina]</option>";
                                    }
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12">
                                <label for="periodo" class="texto">Dia da semana:</label>
                                <div class="input select">
                                  <select name="diaSemana" class="form-control" id="diaSemana">
                                    <option value="">Selecione:</option>
                                    <option value="Segunda">Segunda Feira</option>
                                    <option value="Terca">Terça Feira</option>
                                    <option value="Quarta">Quarta Feira</option>
                                    <option value="Quinta">Quinta Feira</option>
                                    <option value="Sexta">Sexta Feira</option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12">
                                <label for="periodo" class="texto">Período:</label>
                                <div class="input select">
                                  <select name="periodo" class="form-control" id="periodo">
                                    <option value="">Selecione:</option>
                                    <option value="Matutino">Matutino</option>
                                    <option value="Vespertino">Vespertino</option>
                                    <option value="Noturno">Noturno</option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12">
                                <label class="texto">Horario da Aula:</label><br>
                                <div class="input select">
                                  <select name="horario" class="form-control" id="horario">
                                    <option value="">Selecione:</option>
                                    <option value="1">1° Tempo</option>
                                    <option value="2">2° Tempo</option>
                                    <option value="3">3° Tempo</option>
                                    <option value="4">4° Tempo</option>
                                    <option value="5">5° Tempo</option>
                                    <option value="6">6° Tempo</option>
                                    <option value="7">7° Tempo</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <input type="hidden" name="tipo" value="5">
                            <button type="submit" class="btn btn-primary btn-outline-light">Vincular</button>
                          </form>
                        </div>

                     </div>
                    </div>
            </div>

          </div>
        </div>
      </div>

    </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

  </body>
