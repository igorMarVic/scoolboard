<!doctype html>
<html lang="pt-br">
  <head>

    <script>
       function Mudarestado(el) {
        var display = document.getElementById(el).style.display;

          if(display == "none"){
            document.getElementById("DivAluno").style.display = 'none';
            document.getElementById("DivProfessor").style.display = 'none';
            document.getElementById("DivSala").style.display = 'none';
            document.getElementById("DivDisciplina").style.display = 'none';
            document.getElementById("DivVinculoSD").style.display = 'none';
            document.getElementById("DivDisciplinaAluno").style.display = 'none';
            document.getElementById(el).style.display = 'block';


         }else{
           document.getElementById(el).style.display = 'none';
         }
       }

     </script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="manifest" href="../manifest.json">

    <meta name="theme-color" content="#1B7A0C">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="InFo">
    <link rel="apple-touch-icon" href="../images/icons/icon-152x152.png">
    <meta name="msapplication-TileImage" content="../images/icons/icon-144x144.png">
    <meta name="msapplication-TileColor" content="#1B7A0C">
  </head>

  <body>
    <?php
		  session_start();
		  if(isset($_SESSION['RA_Aluno'])===FALSE){
        echo  "<div class='container mt-4'>";
          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
              echo  "<div class='row d-flex'>";
                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                  echo  "<a class='card-link'>";
                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                      echo  "<div class='card-body text-center'>";
                        echo  "<h4 class='card-tittle'>Você precisa estar logado para acessar o sistema !</h4>";
                      echo  "</div>";
                    echo  "</div>";
                  echo  "</a>";
                echo  "</div>";
              echo  "</div>";
            echo  "</div>";
          echo  "</div>";
        echo  "</div>";
        header("Refresh: 3; url='login.php'");
		    exit(0);
		  }
		?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <h4 class="text-white mb-4 "><b>Aluno: <?php echo $_SESSION['Nome']; ?></b></h4>

          <div class="jumbotron px-6 pt-4 pb-0 mt-2 bg-primary" id="Dados">
            <div class="row d-flex">

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4">
                      <a href="#Alunos" onclick="Mudarestado('DivAluno')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Meus dados</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivAluno" class="jumbotron p-4 mt-2 bg-dark">
                        <?php
                          include_once "config.php";
                          include_once "connection.php";
                          $RA=$_SESSION['RA_Aluno'];
                          $conexao = new Connection($host, $user, $password, $database);
                                    $sql ="SELECT u.RA AS RA,
                                    u.nome_aluno AS Nome,
                        						u.curso_aluno AS Curso,
                                    u.periodo_aluno AS Periodo,
                                    u.email_aluno AS Email FROM aluno u WHERE RA LIKE '%$RA%' ORDER BY u.nome_aluno";

                                    $conexao->query($sql);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {?>
                                    <form>
                                        <div class="form-row text-white">
                                              <div class="form-group col-md-12">
                                                <label for="nome">Nome Completo:</label>
                                                <input type="text" class="form-control" value="<?php echo $tupla['Nome'] ; ?>" disabled>
                                              </div>
                                              <div class="form-group col-md-12">
                                                <label for="email">Email Institucional:</label>
                                                <input type="email" class="form-control" value="<?php echo $tupla['Email'] ; ?>" disabled>
                                              </div>
                                              <div class="form-group col-lg-4 col-md-6">
                                                <label for="ra">RA:</label>
                                                <input class="form-control" value="<?php echo $tupla['RA'] ; ?>" disabled>
                                              </div>
                                              <div class="form-group col-lg-4 col-md-6">
                                                <label for="curso" class="texto">Curso:</label>
                                                    <input class="form-control" value="<?php echo $tupla['Curso'] ; ?>" disabled>
                                              </div>
                                              <div class="form-group col-lg-4 col-md-6">
                                                <label for="periodo" class="texto">Período Regular:</label>
                                                    <input class="form-control" value="<?php echo $tupla['Periodo'] ; ?>° Semestre" disabled>
                                                </div>
                                        </div>
                                    </form>
                                    <?php } ?>
                      </div>
              </div>

              <div class="col-sm-12 col-p-6 col-xl-6 col-lg-6 col-md-12 mb-4" id="HorarioAluno">
                      <a href="Resultados.php?acao=HorarioAluno" onclick="Mudarestado('DivHorarioAluno')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Meu Horário</h4>
                          </div>
                        </div>
                      </a>
              </div>

              <div class="col-sm-12 col-p-6 col-xl-6 col-lg-6 col-md-12 mb-4" id="VinculoDisciplinaAluno">
                      <a href="#VinculoDisciplinaAluno" onclick="Mudarestado('DivDisciplinaAluno')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Minhas Aulas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivDisciplinaAluno" class="jumbotron p-4 mt-2 bg-dark">
                        <?php
                        $RA=$_SESSION['RA_Aluno'];
                        $sql ="SELECT a.nome_aluno AS Aluno, va.cod_vinculo_aluno AS Codigo, d.descricao_disciplina AS Disciplina,  v.dia_semana AS Dia_Semana, v.horario AS Horario, v.periodo AS Periodo, v.cod_sala AS Sala
                        FROM vinculoaluno va, vinculo v, aluno a, disciplina d
                        WHERE va.RA LIKE a.RA AND a.RA LIKE '%$RA%' AND va.cod_vinculo LIKE v.cod_vinculo AND d.cod_disciplina like v.cod_disciplina ";
                        $conexao->query($sql);?>

                        <h6 class='text-white mb-4'>Você se encontra matriculado nas seguintes disciplinas:</h6>

                          <?php for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc()){?>
                            <div class="jumbotron p-1 pt-2 mt-0 mb-2 bg-primary">
                            <form>
                                <div class="form-row text-white">
                                      <div class="form-group col-md-12 col-lg-12 col-sm-12 mb-1">
                                        <input type="text" class="form-control" value="<?php echo $tupla['Disciplina'] ; ?>" disabled>
                                      </div>
                                      <div class="form-group col-md-6 col-lg-6 col-sm-6 mb-1">
                                        <input type="email" class="form-control" value="<?php echo $tupla['Sala'] ; ?>" disabled>
                                      </div>
                                      <div class="form-group col-md-6 col-lg-6 col-sm-6 mb-1">
                                        <input class="form-control" value="<?php echo $tupla['Dia_Semana'] ; ?> Feira" disabled>
                                      </div>
                                      <div class="form-group col-md-6 col-lg-6 col-sm-6 mb-1">
                                            <input class="form-control" value="<?php echo $tupla['Periodo'] ; ?>" disabled>
                                      </div>
                                      <div class="form-group col-md-6 col-lg-6 col-sm-6 mb-1">
                                            <input class="form-control" value="<?php echo $tupla['Horario'] ; ?>° Tempo" disabled>
                                        </div>
                                </div>
                            </form>
                          </div>
                        <?php } ?>


                      </div>
              </div>

              <div class="col-sm-12 col-p-6 col-xl-6 col-lg-6 col-md-12 mb-4" id="SalaDisciplina">
                      <a href="#SalaDisciplina" onclick="Mudarestado('DivVinculoSD')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Buscar Aulas</h4>
                          </div>
                        </div>
                       </a>
                      <div id="DivVinculoSD" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listar-vinculos-sala" role="tab" aria-controls="nav-listar-disciplina" aria-selected="true">Buscar</a>
                            <a class="nav-item nav-link text-white"  href="Resultados.php?acao=listarVinculos" aria-controls="nav-listar-disciplina" >Ver Todas</a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-listar-vinculos-sala" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <form action="Resultados.php" method="GET" name="f1" onsubmit="return verificaUsuario()">
                              <input type="hidden" name="acao" value="buscarVinculoSala">
                              <div class="form-row">
                                <div class="form-group col-xl-6 col-lg-6 col-p-12 col-md-12 col-sm-12 text-white">
                                  <label for="periodo" class="texto">Disciplina:</label>
                                  <div class="input select">
                                    <select name="cod_disciplina" class="form-control" id="cod_disciplina">
                                      <option value="">Selecione:</option>
                                      <?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $semestre=$_GET['semestre'];
                                      $curso= $_GET['curso'];
                                      $comum="comum";

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina WHERE periodo_disciplina LIKE '%$semestre%' AND curso_disciplina LIKE '%$curso%' ORDER BY descricao_disciplina";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_disciplina]'> $tupla[cod_disciplina] - $tupla[descricao_disciplina]</option>";
                                      }
                                      $sql2 ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina WHERE periodo_disciplina LIKE '%$semestre%' AND curso_disciplina LIKE '%$comum%'";
                                      $conexao->query($sql2);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_disciplina]'> $tupla[cod_disciplina] - $tupla[descricao_disciplina]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-6 col-lg-6 col-p-12 col-md-12 col-sm-12 text-white">
                                    <label for="nome">Professor:</label>
                                    <div class="input select">
                                      <select name="nome" class="form-control" id="nome">
                                        <option value="">Selecione:</option>
                                        <<?php
                                        include_once "config.php";
                                        include_once "connection.php";

                                        session_start();

                                        $conexao = new Connection($host, $user, $password, $database);

                                        $sql ="SELECT nome_professor FROM  professor ORDER BY nome_professor";
                                        $conexao->query($sql);
                                        for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                        {
                                          echo"<option value='$tupla[nome_professor]'>$tupla[nome_professor]</option>";
                                        }
                                        ?>
                                      </select>
                                    </div>
                                  </div>
                                <div class="form-group col-xl-6 col-lg-6 col-p-12 col-md-12 col-sm-12 text-white">
                                  <label for="periodo" class="texto">Sala:</label>
                                  <div class="input select">
                                    <select name="cod_sala" class="form-control" id="cod_sala">
                                      <option value="">Selecione:</option>
                                      <<?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT cod_sala FROM sala ORDER BY cod_sala";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_sala]'> $tupla[cod_sala]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-6 col-lg-6 col-p-12 col-md-12 col-sm-12 text-white">
                                  <label for="periodo" class="texto">Dia da semana:</label>
                                  <div class="input select">
                                    <select name="diaSemana" class="form-control" id="diaSemana">
                                      <option value="">Selecione:</option>
                                      <option value="Segunda">Segunda Feira</option>
                                      <option value="Terca">Terça Feira</option>
                                      <option value="Quarta">Quarta Feira</option>
                                      <option value="Quinta">Quinta Feira</option>
                                      <option value="Sexta">Sexta Feira</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                                <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                        </div>
                      </div>
              </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4 " id="professor">
                      <a href="#professor" onclick="Mudarestado('DivProfessor')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Professores</h4>
                          </div>
                        </div>
                      </a>

                      <div id="DivProfessor" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-buscar-professor" role="tab" aria-controls="nav-profile" aria-selected="true">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarProfessor" role="tab" aria-controls="nav-listar-professor" aria-selected="false">Listar</a></a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-buscar-professor" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="Resultados.php" method="get">
                              <input type="hidden" name="acao" value="buscarProfessor">
                              <div class="form-row">

                                <div class="form-group col-lg-12 col-sm-12 col-md-12">

                                  <label for="nome">Professor:</label>
                                  <div class="input select">
                                    <select name="nome" class="form-control" id="nome">
                                      <option value="">Selecione:</option>
                                      <<?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT nome_professor FROM  professor ORDER BY nome_professor";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[nome_professor]'>$tupla[nome_professor]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button></a>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarProfessor" role="tabpanel" aria-labelledby="nav-listar-tab">
                              <h5 class="text-white mt-2">Listagem de Professores:</h5>
                              <a href="Resultados.php?acao=listarProfessores"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todos</button></a>

                          </div>
                        </div>
                      </div>
                    </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4 " id="sala">
                      <a href="#sala" onclick="Mudarestado('DivSala')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Salas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivSala" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-buscar-sala" role="tab" aria-controls="nav-profile" aria-selected="true">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarSala" role="tab" aria-controls="nav-listar-sala" aria-selected="false">Listar</a></a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-buscar-sala" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="Resultados.php" method="get">
                              <div class="form-row">
                                <input type="hidden" name="acao" value="buscarSala">
                                <div class="form-group col-md-12 text-white">
                                  <label for="nome">Código da Sala:</label>
                                  <div class="input select">
                                    <select name="cod_sala" class="form-control" id="cod_sala">
                                      <option value="">Selecione:</option>
                                        <?php
                                        include_once "config.php";
                                        include_once "connection.php";



                                        $conexao = new Connection($host, $user, $password, $database);

                                        $sql ="SELECT cod_sala FROM sala ORDER BY cod_sala";
                                        $conexao->query($sql);
                                        for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                        {
                                          echo"<option value='$tupla[cod_sala]'> $tupla[cod_sala]</option>";
                                        }
                                        ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="bloco" class="text-white">Bloco: </label>
                                  <div class="input select">
                                    <select name="bloco" class="form-control" id="bloco">
                                      <option value="">Selecione:</option>
                                      <option value="a">Bloco A</option>
                                      <option value="b">Bloco B</option>
                                      <option value="c">Bloco C</option>
                                      <option value="d">Bloco D</option>
                                      <option value="e">Bloco E</option>
                                    </select>
                                  </div>
                               </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarSala" role="tabpanel" aria-labelledby="nav-listar-tab">
                              <h5 class="text-white mt-2">Listagem de Salas:</h5><a href="Resultados.php?acao=listarSalas"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>
                        </div>
                      </div>
                    </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4" id="disciplina">
                      <a href="#disciplina" onclick="Mudarestado('DivDisciplina')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Disciplinas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivDisciplina" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-buscar-disciplina" role="tab" aria-controls="nav-profile" aria-selected="true">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarDisciplina" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Listar</a></a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-buscar-disciplina" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="Resultados.php" method="get">
                              <input type="hidden" name="acao" value="buscarDisciplina">
                              <div class="form-row">
                                <div class="form-group col-md-12 text-white">
                                  <label for="periodo" class="texto">Período Padão:</label>
                                  <div class="input select">
                                    <select name="periodoDisciplina" class="form-control" id="periodoDisciplina">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-12 col-lg-12 col-p-12 col-md-12 col-sm-12 text-white">
                                  <label for="periodo" class="texto">Disciplina:</label>
                                  <div class="input select">
                                    <select name="descricaoDisciplina" class="form-control" id="descricaoDisciplina">
                                      <option value="">Selecione:</option>
                                      <?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina ORDER BY descricao_disciplina";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[descricao_disciplina]'> $tupla[descricao_disciplina]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-12 text-white">
                                  <label for="curso" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="cursoDisciplina" class="form-control" id="cursoDisciplina">
                                      <option value="">Selecione:</option>
                                      <option value="comum">Comum a todos</option>
                                      <option value="eletrotecnica">Eletrotécnica</option>
                                      <option value="informatica">Informática</option>
                                      <option value="mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                             </div>

                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button></a>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarDisciplina" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white mt-2">Listagem de Disciplinas:</h5><a href="Resultados.php?acao=listarDisciplinas"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>
                        </div>
                      </div>

              </div>

            </div>
          </div>

      <script>
         window.onload = function(){
         document.getElementById("DivAluno").style.display = 'none';
         document.getElementById("DivProfessor").style.display = 'none';
         document.getElementById("DivSala").style.display = 'none';
         document.getElementById("DivDisciplina").style.display = 'none';
         document.getElementById("DivVinculoSD").style.display = 'none';
         document.getElementById("DivDisciplinaAluno").style.display = 'none';
         }
      </script>
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
    </body>
</html>
