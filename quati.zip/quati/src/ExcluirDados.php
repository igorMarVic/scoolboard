<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <h3 class="text-white">Exclusão de Dados: </h3>
        <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">

          <?php
          include_once "config.php";
          include_once "connection.php";
          session_start();
          if(isset($_GET['acao']))
          {
            if($_GET['acao'] === 'excluirAluno')
            {
              $id=$_GET['RA'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql = "SELECT u.RA AS RA, u.nome_aluno AS Nome,
              u.curso_aluno AS Curso,
              u.periodo_aluno AS Periodo,
              u.email_aluno AS Email FROM aluno u  WHERE RA LIKE '%$id%'";

              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $RA = $tupla['RA'];
                $nome= $tupla['Nome'];
                $curso= $tupla['Curso'];
                $periodo=$tupla['Periodo'];
                $email=$tupla['Email'];
              }
               ?>
              <form action="processa.php?acao=excluirAluno&RA=<?php echo $RA ?>" method="POST">
                <div class="form-row">
                  <div class="form-group col-md-12 text-white">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" class="form-control" name="nome" value='<?php echo $nome; ?>' id="nome" disabled>
                  </div>
                  <div class="form-group col-md-12 text-white">
                    <label for="email">Email Institucional:</label>
                    <input type="email" class="form-control" name="email" value='<?php echo $email; ?>' id="email" disabled>
                  </div>
                  <div class="form-group col-lg-4 col-md-6 text-white">
                    <label for="ra">RA:</label>
                    <input type="number" class="form-control" name="ra" value='<?php echo $RA; ?>' id="ra" disabled >
                  </div>
                  <div class="form-group col-lg-4 col-md-6 text-white">
                    <label for="curso" class="texto">Curso:</label>
                    <div class="input select">
                      <select name="curso" class="form-control" id="curso" disabled>
                        <option value='<?php echo $curso; ?>'><?php echo $curso; ?></option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group col-lg-4 col-md-6 text-white">
                    <label for="periodo" class="texto">Período Regular:</label>
                    <div class="input select">
                      <select name="periodo" class="form-control" id="periodo" disabled>
                        <option value='<?php echo $periodo; ?>'><?php echo $periodo; ?>° Semestre</option>
                      </select>
                    </div>
                  </div>
                </div>


                <button type="submit" class="btn btn-primary btn-outline-light">Remover Aluno</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirSala')
            {
              $id=$_GET['CodSala'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql ="SELECT u.cod_sala AS Codigo,
              u.descricao_sala AS Descricao,
              u.bloco_sala AS Bloco FROM sala u WHERE cod_sala LIKE '%$id%' ORDER BY u.cod_sala";
              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $codSala = $tupla['Codigo'];
                $descricaoSala= $tupla['Descricao'];
                $blocoSala= $tupla['Bloco'];

              }
               ?>
              <form action="processa.php?acao=excluirSala&CodSala=<?php echo $id ?>" method="POST">
                <div class="form-row">
                  <div class="form-group text-white col-md-4 mt-3">
                    <label for="inputName">Codigo:</label>
                    <input type="text" class="form-control" id="codSala" name="codSala" value="<?php echo $codSala; ?>" disabled>
                  </div>
                  <div class="form-group col-md-8 mt-3">
                    <label for="bloco" class="text-white">Bloco: </label>
                    <div class="input select">
                      <select name="bloco" class="form-control" id="bloco" disabled>
                        <option value="<?php echo $blocoSala; ?>">Bloco <?php echo $blocoSala; ?></option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group col-md-12 mt-3">
                    <label for="imputDescricao" class="texto text-white">Descrição:</label>
                    <div class="input select">
                      <select name="descricao" class="form-control" id="descricao" disabled>
                        <option value="<?php echo $descricaoSala; ?>"><?php echo $descricaoSala; ?></option>
                      </select>
                    </div>
                  </div>
                </div>

                <button type="submit" class="btn btn-primary btn-outline-light">Remover Sala</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirProfessor')
            {
              $id=$_GET['SIAPE'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql ="SELECT u.SIAPE AS SIAPE,
              u.nome_professor AS Nome,
              u.email_professor AS Email,
              u.area_professor AS Area FROM professor u WHERE SIAPE = $id ORDER BY u.nome_professor";
              $conexao->query($sql);


              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $SIAPE = $tupla['SIAPE'];
                $nome= $tupla['Nome'];
                $email=$tupla['Email'];
                $area= $tupla['Area'];

              }
               ?>
              <form action="processa.php?acao=excluirProfessor&SIAPE=<?php echo $id; ?>" method="POST">
                <div class="form-row">
                  <div class="form-group col-md-12 text-white">
                    <label for="inputName">Nome Completo:</label>
                    <input type="text" class="form-control" id="nome" name="nome" value="<?php echo $nome; ?>" disabled>
                  </div>
                  <div class="form-group col-md-12 text-white">
                    <label for="inputEmail">Email Institucional:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $email;?>" disabled>
                  </div>
                  <div class="form-group col-md-4 text-white">
                    <label for="inputCurso">SIAPE:</label>
                    <input type="number" class="form-control" id="siape" name="siape" value="<?php echo $SIAPE;?>" disabled>
                  </div>
                  <div class="form-group col-md-8 text-white">
                    <label for="inputCurso">Area de Docência:</label>
                    <input type="text" class="form-control" id="area" name="area" value="<?php echo $area;?>" disabled>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-outline-light">Remover Professor</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirDisciplina')
            {
              $id=$_GET['codDisciplina'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql ="SELECT u.cod_disciplina AS Codigo,
              u.descricao_disciplina AS Descricao,
              u.periodo_disciplina AS Periodo, u.curso_disciplina AS Curso FROM disciplina u WHERE cod_disciplina = $id ORDER BY descricao_disciplina";
              $conexao->query($sql);


              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $codDisciplina = $tupla['Codigo'];
                $descricaoDisciplina= $tupla['Descricao'];
                $periodoDisciplina=$tupla['Periodo'];
                $cursoDisciplina = $tupla['Curso'];

              }
               ?>
              <form action="processa.php?acao=excluirDisciplina&codDisciplina=<?php echo $id; ?>" method="POST">
                <div class="form-row">
                  <div class="form-group col-md-12 text-white">
                    <label for="nome">Código:</label>
                    <input type="number" class="form-control" name="codDisciplina" id="codDisciplina" value="<?php echo $codDisciplina; ?>" disabled>
                  </div>
                  <div class="form-group col-md-12 text-white">
                    <label for="nome">Descrição:</label>
                    <input type="text" class="form-control" name="descricaoDisciplina" id="descricaoDisciplina" value="<?php echo $descricaoDisciplina;?>" disabled>
                  </div>
                  <div class="form-group col-md-12 text-white">
                    <label for="periodo" class="texto">Período Padão:</label>
                    <div class="input select">
                      <select name="periodoDisciplina" class="form-control" id="periodoDisciplina" disabled>
                        <option value="<?php echo $periodoDisciplina; ?>"><?php echo $periodoDisciplina; ?>° Semestre</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group col-md-12 text-white">
                    <label for="curso" class="texto">Curso:</label>
                    <div class="input select">
                      <select name="cursoDisciplina" class="form-control" id="cursoDisciplina" disabled>
                        <option value="<?php echo $cursoDisciplina; ?>"><?php echo $cursoDisciplina; ?></option>
                      </select>
                    </div>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-outline-light">Remover Disciplina</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirTurma')
            {
              $id=$_GET['CodTurma'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql ="SELECT t.cod_turma AS Turma,
              t.curso_turma AS Curso,
              t.periodo_turma AS Periodo, t.turno_turma AS Turno FROM turma t WHERE cod_turma = $id";
              $conexao->query($sql);


              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $turma = $tupla['Turma'];
                $curso= $tupla['Curso'];
                $periodo=$tupla['Periodo'];
                $turno = $tupla['Turno'];

              }
               ?>
              <form action="processa.php?acao=excluirTurma&CodTurma=<?php echo $id; ?>" method="POST">
                <div class="form-row text-white">
                  <div class="form-group col-md-6">
                    <label for="nome">Código da Turma:</label>
                    <input type="text" class="form-control" name="cod_turma" id="cod_turma" value="<?php echo $turma; ?>" disabled>
                  </div>
                  <div class="form-group col-md-6">
                    <label>Turno:</label>
                    <div class="input select">
                      <select name="turno_turma" class="form-control" id="turno_turma" disabled>
                        <option value="<?php echo $turno; ?>"><?php echo $turno; ?>:</option>
                        <option value="Matutino">Matutino</option>
                        <option value="Vespertino">Vespertino</option>
                        <option value="Noturno">Noturno</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group col-lg-6 col-md-6">
                    <label for="curso" class="texto">Curso:</label>
                    <div class="input select">
                      <select name="curso_turma" class="form-control" id="curso_turma" disabled>
                        <option value="<?php echo $curso; ?>"><?php echo $curso; ?></option>
                        <option value="Eletrotecnica">Eletrotécnica</option>
                        <option value="Informatica">Informática</option>
                        <option value="Mecanica">Mecânica</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group col-lg-6 col-md-6">
                    <label for="periodo" class="texto">Período:</label>
                    <div class="input select">
                      <select name="periodo_turma" class="form-control" id="periodo_turma" disabled>
                        <option value="<?php echo $periodo; ?>"><?php echo $periodo; ?>° Semestre</option>
                        <option value="1">1° Semestre</option>
                        <option value="2">2° Semestre</option>
                        <option value="3">3° Semestre</option>
                        <option value="4">4° Semestre</option>
                        <option value="5">5° Semestre</option>
                        <option value="6">6° Semestre</option>
                        <option value="7">7° Semestre</option>
                      </select>
                    </div>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-outline-light">Remover Turma</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirAdmin')
            {
              $id=$_GET['CodAdmin'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql = "SELECT a.id_admin AS ID,
               a.nome_admin AS Nome,
               a.email_Admin AS email
               FROM administracao a WHERE id_admin = $id";
              $conexao->query($sql);


              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $id=$tupla['ID'];
                $nome = $tupla['Nome'];
                $email= $tupla['email'];

              }
               ?>
              <form action="processa.php?acao=excluirAdmin&CodAdmin=<?php echo $id; ?>" method="POST">
                <div class="form-row text-white">
                  <div class="form-group col-md-6">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" class="form-control" name="nome_admin" id="nome_admin" value="<?php echo $nome; ?>" disabled>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="nome">E-mail:</label>
                    <input type="email" class="form-control" name="email_admin" id="email_admin" value="<?php echo $email; ?>" disabled>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-outline-light">Remover Turma</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirVinculoSala')
            {
              $id=$_GET['CodVinculo'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql ="SELECT u.cod_sala AS Sala, u.cod_disciplina AS cod_disciplina,
              d.descricao_disciplina AS Disciplina,
              u.dia_semana AS Dia_da_Semana, u.periodo AS Periodo, u.horario AS Horario FROM vinculo u, disciplina d WHERE U.cod_vinculo = $id AND d.cod_disciplina LIKE u.cod_disciplina ORDER BY u.cod_sala";
              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $disciplina= $tupla['Disciplina'];
                $cod_disciplina=$tupla['cod_disciplina'];
                $sala= $tupla['Sala'];
                $diaSemana= $tupla['Dia_da_Semana'];
                $periodo = $tupla['Periodo'];
                $horario = $tupla['Horario'];

              }
               ?>
              <form action="processa.php?acao=excluirVinculoSala&codVinculo=<?php echo $id; ?>" class="form-group" method="POST">

                            <div class="row d-flex text-white">
                              <div class="form-group col-xl-3 col-lg-3 col-p-12 col-md-12 col-sm-12">
                                <label for="nome">Código da Sala:</label>
                                <div class="input select">
                                  <select name="cod_sala" class="form-control" id="cod_sala" disabled>
                                    <option value='<?php echo $sala; ?>'><?php echo $sala; ?></option>";
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-9 col-lg-12 col-p-9 col-sm-12 col-md-12">
                                <label for="nome">Código da Disciplina:</label>
                                <div class="input select">
                                  <select name="cod_disciplina" class="form-control" id="cod_disciplina" disabled>
                                    <option value='<?php echo $cod_disciplina; ?>'> <?php echo $cod_disciplina." - ".$disciplina; ?></option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12">
                                <label for="periodo" class="texto">Dia da semana:</label>
                                <div class="input select">
                                  <select name="diaSemana" class="form-control" id="diaSemana" disabled>
                                    <option value="<?php echo $diaSemana; ?>"><?php echo $diaSemana; ?> Feira</option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12">
                                <label for="periodo" class="texto">Período:</label>
                                <div class="input select">
                                  <select name="periodo" class="form-control" id="periodo" disabled>
                                    <option value="<?php echo $periodo; ?>"><?php echo $periodo; ?></option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12">
                                <label class="texto">Horario da Aula:</label><br>
                                <div class="input select">
                                  <select name="horario" class="form-control" id="horario" disabled>
                                    <option value="<?php echo $horario; ?>"><?php echo $horario; ?>° Tempo</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-outline-light">Remover Vinculo</button>
                          </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirVinculoAluno')
            {
              $id=$_GET['codVinculo'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql = "SELECT a.nome_aluno AS Aluno, va.RA AS RA, va.cod_vinculo AS CodVinculo, d.curso_disciplina AS Curso, d.periodo_disciplina AS Periodo,
              d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala, v.dia_semana AS diaSemana, v.horario AS Horario, v.periodo AS Turno
              FROM aluno a, vinculoaluno va, vinculo v, disciplina d
              WHERE va.cod_vinculo_aluno = $id AND a.RA LIKE va.RA AND va.cod_vinculo LIKE v.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina";
              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $codVinculo=$tupla['CodVinculo'];
                $aluno= $tupla['Aluno'];
                $RA=$tupla['RA'];
                $curso= $tupla['Curso'];
                $periodo=$tupla['Periodo'];
                $disciplina=$tupla['Disciplina'];
                $sala=$tupla['Sala'];
                $diaSemana=$tupla['diaSemana'];
                $horario=$tupla['Horario'];
                $turno=$tupla['Turno'];              }
               ?>
               <?php echo "<h2 class='text-white'>Exclusão de vinculo do(a) aluno(a) ".$aluno.":</h2>"; ?>
              <form action="processa.php?acao=excluirVinculoAluno&codVinculo=<?php echo $id ?>" method="POST">
                <div class="form-row">
                  <input type="hidden" name="RA" id="RA" value="<?php echo $RA; ?>">
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <div class="input select">
                      <select name="vinculo" class="form-control" id="vinculo" disabled>
                        <option value="<?php echo $codVinculo; ?>"><?php echo $curso." - ".$periodo."° Semestre - ".$disciplina." - ".$sala." - ".$diaSemana." - ".$horario."° Tempo - ".$turno; ?></option>
                      </select>
                    </div>
                  </div>
                </div>
                <input type="hidden" name="tipo" value="7">
                <button type="submit" class="btn btn-primary btn-outline-light">Desvincular</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirVinculoProfessor')
            {
              $id=$_GET['codVinculo'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql = "SELECT p.nome_professor AS Professor, vp.SIAPE AS SIAPE, vp.cod_vinculo AS CodVinculo, d.curso_disciplina AS Curso, d.periodo_disciplina AS Periodo,
              d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala, v.dia_semana AS diaSemana, v.horario AS Horario, v.periodo AS Turno
              FROM professor p, vinculoprofessor vp, vinculo v, disciplina d
              WHERE vp.cod_vinculo_professor = $id AND p.SIAPE LIKE vp.SIAPE AND vp.cod_vinculo LIKE v.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina";
              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $codVinculo=$tupla['CodVinculo'];
                $professor= $tupla['Professor'];
                $SIAPE=$tupla['SIAPE'];
                $curso= $tupla['Curso'];
                $periodo=$tupla['Periodo'];
                $disciplina=$tupla['Disciplina'];
                $sala=$tupla['Sala'];
                $diaSemana=$tupla['diaSemana'];
                $horario=$tupla['Horario'];
                $turno=$tupla['Turno'];              }
               ?>
               <?php echo "<h4 class='text-white'>Exclusão de Vinculo do(a) Professor(a) ".$professor."</h4>";  ?>
              <form action="processa.php?acao=excluirVinculoProfessor&codVinculo=<?php echo $id; ?>" method="POST">
                <div class="form-row">
                  <input type="hidden" name="siape" value="<?php echo $SIAPE;  ?>">
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <div class="input select">
                      <select name="vinculo" class="form-control" id="vinculo" disabled>
                        <option value="<?php echo $codVinculo; ?>"><?php echo $curso." - ".$periodo."° Semestre - ".$disciplina." - ".$sala." - ".$diaSemana." - ".$horario."° Tempo - ".$turno; ?></option>

                      </select>
                    </div>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-outline-light">Remover Vinculo</button>
              </form>
            <?php } ?>

            <?php
            if($_GET['acao'] === 'excluirVinculoTurma')
            {
              $id=$_GET['codVinculo'];
              $conexao = new Connection($host, $user, $password, $database);
              $sql ="SELECT t.cod_turma AS Turma, vt.cod_vinculo_turma AS CodigoT, v.cod_vinculo AS Codigo, d.descricao_disciplina AS Disciplina,
              v.cod_sala AS Sala, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, v.horario AS Horario, d.periodo_disciplina AS Semestre, d.curso_disciplina AS Curso
              FROM vinculo v, vinculoturma vt, turma t, disciplina d
              WHERE v.cod_vinculo LIKE vt.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina AND t.cod_turma LIKE vt.cod_turma AND vt.cod_vinculo_turma LIKE '%$id%'
              ORDER BY t.cod_turma, v.horario";
              $conexao->query($sql);
              for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
              {
                $turma=$tupla['Turma'];
                $codVinculo=$tupla['Codigo'];
                $VinculoTurma=$tupla['CodigoT'];
                $curso= $tupla['Curso'];
                $turno=$tupla['Periodo'];
                $disciplina=$tupla['Disciplina'];
                $sala=$tupla['Sala'];
                $diaSemana=$tupla['Dia_Semana'];
                $horario=$tupla['Horario'];
                $semestre=$tupla['Semestre'];              }
               ?>
               <?php echo "<h4 class='text-white'>Editação de Vinculo da Turma ".$turma."</h4>";  ?>
              <form action="processa.php?acao=excluirVinculoTurma&codVinculoTurma=<?php echo $id; ?>" method="POST">
                <div class="form-row">
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <div class="input select">
                      <select name="vinculo" class="form-control" id="vinculo" disabled>
                        <option value="<?php echo $codVinculo; ?>"><?php echo $curso." - ".$semestre."° Semestre - ".$disciplina." - ".$sala." - ".$diaSemana."-feira - ".$horario."° Tempo - ".$turno; ?></option>
                      </select>
                    </div>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary btn-outline-light">Remover Vinculo</button>
              </form>

            <?php } ?>
        <?php } ?>
        </div>
      </div>
    </div>


  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
