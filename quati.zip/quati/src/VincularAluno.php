<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">
          <h3 class="text-white">Vincular Aluno</h3>

          <div class="row d-flex">

            <div class="col-sm-12 col-p-6 col-lg-12 col-md-12 mb-4" id="SalaDisciplina">

                  <div id="DivVinculoSala" class="jumbotron p-4 mt-2 bg-dark">
                      <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                          <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-cadastro-vinculo-sala" role="tab" aria-controls="nav-home" aria-selected="true">Vincular</a>
                        </div>
                      </nav>
                      <div class="tab-content" id="nav-tabContent">

                        <div class="tab-pane fade show active text-white" id="nav-cadastro-vinculo-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                          <form action="processa.php" method="POST">
                            <div class="form-row">
                              <input type="hidden" name="semestre" value="<?php echo $_GET['semestre']; ?>">
                              <input type="hidden" name="curso" value="<?php echo $_GET['curso']; ?>">
                              <div class="form-group col-lg-12 col-sm-12 col-md-12">
                                <label for="nome">RA - Aluno:</label>
                                <div class="input select">
                                  <select name="RA" class="form-control" id="RA">
                                    <option value="">Selecione:</option>
                                    <<?php
                                    include_once "config.php";
                                    include_once "connection.php";

                                    session_start();
                                    $semestre=$_GET['semestre'];

                                    $curso= $_GET['curso'];

                                    $comum='comum';
                                    $conexao = new Connection($host, $user, $password, $database);

                                    $sql ="SELECT RA, nome_aluno FROM aluno WHERE periodo_aluno LIKE '%$semestre%' AND curso_aluno LIKE '%$curso%' ORDER BY nome_aluno";
                                    $conexao->query($sql);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo"<option value='$tupla[RA]'> $tupla[RA] - $tupla[nome_aluno]</option>";
                                    }
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group col-lg-12 col-sm-12 col-md-12">
                                <label for="nome">Vinculo:</label>
                                <div style="overflow:scroll; height: 500px" class="form-check bg-white text-dark">

                                    <?php
                                    include_once "config.php";
                                    include_once "connection.php";


                                    $semestre=$_GET['semestre'];

                                    $curso= $_GET['curso'];

                                    $comum="comum";
                                    $conexao = new Connection($host, $user, $password, $database);
                                    $sql ="SELECT d.descricao_disciplina AS Disciplina, d.curso_disciplina AS Curso, d.periodo_disciplina AS Periodo, v.cod_vinculo AS Vinculo, v.dia_semana AS DiaSemana, v.cod_sala AS Sala, v.periodo AS Turno, v.horario AS Horario FROM disciplina d, vinculo v
                                    WHERE v.cod_disciplina LIKE d.cod_disciplina AND d.periodo_disciplina LIKE '%$semestre%' AND d.curso_disciplina LIKE '%$curso%' ORDER BY d.curso_disciplina, d.descricao_disciplina";
                                    $conexao->query($sql);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo "<div class='py-3 px-4'>";
                                      echo "<input type='checkbox' class='form-check-input' name='vinculo[]' value='$tupla[Vinculo]'>";
                                      echo "<label class='form-check-label'>$tupla[Curso] - $tupla[Periodo]° Semestre - $tupla[Turno] - $tupla[Horario]° Tempo - $tupla[Disciplina] - $tupla[Sala] - $tupla[DiaSemana]</label><br>";
                                      echo "</div>";
                                    }
                                    $sql2 ="SELECT d.descricao_disciplina AS Disciplina, d.curso_disciplina AS Curso, d.periodo_disciplina AS Periodo, v.cod_vinculo AS Vinculo, v.dia_semana AS DiaSemana, v.cod_sala AS Sala, v.periodo AS Turno, v.horario AS Horario FROM disciplina d, vinculo v WHERE v.cod_disciplina LIKE d.cod_disciplina AND d.periodo_disciplina LIKE '%$semestre%' AND d.curso_disciplina LIKE '%$comum%' ORDER BY d.curso_disciplina, d.descricao_disciplina";
                                    $conexao->query($sql2);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo "<div class='py-3 px-4'>";
                                      echo "<input type='checkbox' class='form-check-input' name='vinculo[]' value='$tupla[Vinculo]'>";
                                      echo "<label class='form-check-label'>$tupla[Curso] - $tupla[Periodo]° Semestre - $tupla[Turno] - $tupla[Horario]° Tempo - $tupla[Disciplina] - $tupla[Sala] - $tupla[DiaSemana]</label><br>";
                                      echo "</div>";
                                    }
                                    $sql3 ="SELECT d.descricao_disciplina AS Disciplina, d.curso_disciplina AS Curso, d.periodo_disciplina AS Periodo, v.cod_vinculo AS Vinculo,  v.dia_semana AS DiaSemana, v.cod_sala AS Sala, v.periodo AS Turno, v.horario AS Horario FROM disciplina d, vinculo v WHERE v.cod_disciplina LIKE d.cod_disciplina AND d.curso_disciplina LIKE '%$comum%' ORDER BY d.curso_disciplina, d.descricao_disciplina";
                                    $conexao->query($sql3);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo "<div class='py-3 px-4'>";
                                      echo "<input type='checkbox' class='form-check-input' name='vinculo[]' value='$tupla[Vinculo]'>";
                                      echo "<label class='form-check-label'>$tupla[Curso] - $tupla[Periodo]° Semestre - $tupla[Turno] - $tupla[Horario]° Tempo - $tupla[Disciplina] - $tupla[Sala] - $tupla[DiaSemana]</label><br>";
                                      echo "</div>";
                                    $sql4 ="SELECT d.descricao_disciplina AS Disciplina, d.curso_disciplina AS Curso, d.periodo_disciplina AS Periodo, v.cod_vinculo AS Vinculo, v.dia_semana AS DiaSemana, v.cod_sala AS Sala, v.periodo AS Turno, v.horario AS Horario FROM disciplina d, vinculo v WHERE v.cod_disciplina LIKE d.cod_disciplina ORDER BY d.curso_disciplina, d.descricao_disciplina";
                                    }
                                    $conexao->query($sql4);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo "<div class='py-3 px-4'>";
                                      echo "<input type='checkbox' class='form-check-input' name='vinculo[]' value='$tupla[Vinculo]'>";
                                      echo "<label class='form-check-label'>$tupla[Curso] - $tupla[Periodo]° Semestre - $tupla[Turno] - $tupla[Horario]° Tempo - $tupla[Disciplina] - $tupla[Sala] - $tupla[DiaSemana]</label><br>";
                                      echo "</div>";
                                    }
                                    ?>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <input type="hidden" name="tipo" value="7">
                            <button type="submit" class="btn btn-primary btn-outline-light">Vincular</button>
                          </form>
                        </div>

                      </div>
                    </div>
            </div>

          </div>
        </div>
      </div>

    </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

  </body>
