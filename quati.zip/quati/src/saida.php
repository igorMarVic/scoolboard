<?php
	session_start();

	if(isset($_SESSION['id_admin']))
	{
		session_destroy();
		header("Refresh:0; url=login.php");
	}
	if(isset($_SESSION['RA_Aluno']))
	{
		session_destroy();
		header("Refresh:0; url=login.php");
	}
	if(isset($_SESSION['SIAPE']))
	{
		session_destroy();
		header("Refresh:0; url=login.php");
	}
?>
