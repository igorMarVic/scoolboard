<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">

          <?php
          include_once "config.php";
          include_once "connection.php";

          $conexao = new Connection($host, $user, $password, $database);
          session_start();
          if(isset($_GET['acao']))
          {
            if($_GET['acao'] === 'listarAlunos')
            {
                $sql ="SELECT u.RA AS RA,
                u.nome_aluno AS Nome,
                u.curso_aluno AS Curso,
                u.periodo_aluno AS Periodo,
                u.email_aluno AS Email FROM aluno u ORDER BY u.nome_aluno";

                $conexao->query($sql);
                    echo"<h3 class='text-white mb-4'>LISTAGEM DE ALUNOS:</h3>";
                    echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                    echo "<tr class='thead-dark'>";

                        echo "<th>RA</th>";
                        echo "<th>Nome</th>";
                        echo "<th>Curso</th>";
                        echo "<th>Período</th>";
                        echo "<th>E-mail</th>";
                        echo "<th> </th>";
                        echo "<th> </th>";

                    echo "</tr>";
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {

                      echo "<tr>";

                        $ra = $tupla['RA'];
                        echo "<td>$ra</td>";
                        echo "<td>$tupla[Nome]</td>";
                        echo "<td>$tupla[Curso]</td>";
                        echo "<td>$tupla[Periodo]</td>";
                        echo "<td>$tupla[Email]</td>";

                        echo "<td style='width:10%'><a href='EditarDados.php?acao=editarAluno&RA=$ra'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                        echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirAluno&RA=$ra'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                      echo "</tr>";
                    }
                    echo "</table>";
                    }

            if($_GET['acao'] === 'listarProfessores')
            {
                  $sql ="SELECT u.SIAPE AS SIAPE,
                  u.nome_professor AS Nome,
                  u.email_professor AS Email,
                  u.area_professor AS Area FROM professor u ORDER BY u.nome_professor";
                  $conexao->query($sql);

                  echo"<h2 class='text-white mb-4'>LISTAGEM DE PROFESSORES:</h2>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>SIAPE</th>";
                      echo "<th>Nome</th>";
                      echo "<th>E-mail Institucional</th>";
                      echo "<th>Área de Docência</th>";
                      echo "<th></th>";
                      echo "<th></th>";

                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $siape = $tupla['SIAPE'];
                      echo "<td>$siape</td>";
                      echo "<td>$tupla[Nome]</td>";
                      echo "<td>$tupla[Email]</td>";
                      echo "<td>$tupla[Area]</td>";


                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarProfessor&SIAPE=$siape'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirProfessor&SIAPE=$siape'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }

            if($_GET['acao'] === 'listarSalas')
            {
                  $sql ="SELECT u.cod_sala AS Codigo,
                  u.descricao_sala AS Descricao,
                  u.bloco_sala AS Bloco FROM sala u ORDER BY u.cod_sala";
                  $conexao->query($sql);
                  echo"<h2 class='text-white mb-4'>LISTAGEM DE SALAS:</h2>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Sala</th>";
                      echo "<th>Descrição</th>";
                      echo "<th>Bloco</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_sala = $tupla['Codigo'];
                      echo "<td>$cod_sala</td>";
                      echo "<td>$tupla[Descricao]</td>";
                      echo "<td>$tupla[Bloco]</td>";

                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarSala&CodSala=$cod_sala'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirSala&CodSala=$cod_sala'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";


                    echo "</tr>";
                  }
                  echo "</table>";
                  }

            if($_GET['acao'] === 'listarDisciplinas')
            {
                  $sql ="SELECT u.cod_disciplina AS Codigo,
                  u.descricao_disciplina AS Descricao,
                  u.periodo_disciplina AS Periodo, u.curso_disciplina AS Curso FROM disciplina u ORDER BY u.descricao_disciplina";
                  $conexao->query($sql);
                  echo"<h2 class='text-white mb-4'>LISTAGEM DE DISCIPLINAS:</h2>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Código</th>";
                      echo "<th>Descrição</th>";
                      echo "<th>Período Padrão</th>";
                      echo "<th>Curso</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_disciplina = $tupla['Codigo'];
                      echo "<td>$cod_disciplina</td>";
                      echo "<td>$tupla[Descricao]</td>";
                      echo "<td>$tupla[Periodo]° Semestre</td>";
                      echo "<td>$tupla[Curso]</td>";

                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarDisciplina&codDisciplina=$cod_disciplina'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirDisciplina&codDisciplina=$cod_disciplina'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";


                    echo "</tr>";
                  }
                  echo "</table>";
                  }

            if($_GET['acao'] === 'listarTurma')
            {

                $sql = "SELECT t.cod_turma AS Turma,
                t.turno_turma AS Turno,
                t.curso_turma AS Curso, t.periodo_turma AS Periodo FROM turma t WHERE cod_null = 0";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {
                    echo "Nenhuma Turma Encontrada!";
                }else{
                  echo"<h3 class='text-white'>BUSCA POR TURMAS:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios turma(s) encontrada(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Turma</th>";
                      echo "<th>Turno</th>";
                      echo "<th>Curso</th>";
                      echo "<th>Periodo</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_turma = $tupla['Turma'];
                      echo "<td>$cod_turma</td>";
                      echo "<td>$tupla[Turno]</td>";
                      echo "<td>$tupla[Curso]</td>";
                      echo "<td>$tupla[Periodo]° Semestre</td>";

                      echo "<td style='width: 10%'><a href='EditarDados.php?acao=editarTurma&CodTurma=$cod_turma'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirTurma&CodTurma=$cod_turma'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }
                }

            if($_GET['acao'] === 'listarAdmin')
            {

                $sql = "SELECT a.id_admin AS ID,
                 a.nome_admin AS Nome,
                 a.email_Admin AS email
                 FROM administracao a";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {
                    echo "Nenhuma Turma Encontrada!";
                }else{
                  echo"<h3 class='text-white'>BUSCA POR TURMAS:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios Administrador(s) encontrada(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Administrador</th>";
                      echo "<th>E-mail</th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_admin = $tupla['ID'];
                      echo "<td>$tupla[Nome]</td>";
                      echo "<td>$tupla[email]</td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirAdmin&CodAdmin=$cod_admin'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }
                }

            if($_GET['acao'] === 'listarVinculos')
            {

                  $sql ="SELECT u.cod_sala AS Sala, u.cod_vinculo AS Codigo, d.descricao_disciplina AS Disciplina, u.dia_semana AS Dia_da_Semana, u.periodo AS Periodo, u.horario AS Horario FROM vinculo u, disciplina d WHERE u.cod_disciplina LIKE d.cod_disciplina ORDER BY u.cod_sala, d.descricao_disciplina,u.periodo, u.horario";
                  $conexao->query($sql);
                  echo"<h2 class='text-white mb-4'>Vinculo de Disciplinas com Salas:</h2>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Sala</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo </th>";
                      echo "<th>Horario</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_vinculo = $tupla['Codigo'];
                      echo "<td>$tupla[Sala]</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td style='text-align:center'>$tupla[Dia_da_Semana] Feira</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td>$tupla[Horario]° Tempo</td>";

                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoSala&CodVinculo=$cod_vinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoSala&CodVinculo=$cod_vinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }

            if($_GET['acao'] === 'listarVinculosProfessores')
            {
                  $sql ="SELECT p.nome_professor AS Professor, vp.cod_vinculo_professor AS Codigo, d.descricao_disciplina AS Disciplina,  v.dia_semana AS Dia_Semana, v.horario AS Horario, v.cod_sala AS Sala, v.periodo AS Periodo
                  FROM vinculoprofessor vp, vinculo v, professor p, disciplina d WHERE vp.SIAPE LIKE p.SIAPE AND vp.cod_vinculo LIKE v.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina ";
                  $conexao->query($sql);
                  echo"<h2 class='text-white mb-4'>Vinculo de Disciplinas com Professores:</h2>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Professor</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Sala</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo</th>";
                      echo "<th>Horário </th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $codVinculo = $tupla['Codigo'];
                      echo "<td style='width:20%'>$tupla[Professor]</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td>$tupla[Sala]</td>";
                      echo "<td>$tupla[Dia_Semana]</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td style='width:10%'>$tupla[Horario]° Tempo</td>";


                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoProfessor&codVinculo=$codVinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoProfessor&codVinculo=$codVinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }

            if($_GET['acao'] === 'listarVinculosAlunos')
            {
                  $sql ="SELECT a.nome_aluno AS Aluno, va.cod_vinculo_aluno AS Codigo, d.descricao_disciplina AS Disciplina,  v.dia_semana AS Dia_Semana, v.horario AS Horario, v.periodo AS Periodo, v.cod_sala AS Sala FROM vinculoaluno va, vinculo v, aluno a, disciplina d
                  WHERE va.RA LIKE a.RA AND va.cod_vinculo LIKE v.cod_vinculo AND d.cod_disciplina like v.cod_disciplina ";
                  $conexao->query($sql);
                  echo"<h2 class='text-white mb-4'>Vinculo de Disciplinas com Alunos:</h2>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Aluno</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Sala</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo</th>";
                      echo "<th>Horário </th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $codVinculo = $tupla['Codigo'];
                      echo "<td style='width:20%'>$tupla[Aluno]</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td>$tupla[Sala]</td>";
                      echo "<td style='width:15%'>$tupla[Dia_Semana] Feira</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td style='width:10%'>$tupla[Horario]° Tempo</td>";


                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoAluno&codVinculo=$codVinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoAluno&codVinculo=$codVinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }

            if($_GET['acao'] === 'listarVinculosTurmas')
            {

                $sql ="SELECT t.cod_turma AS Turma, vt.cod_vinculo_turma AS Codigo, d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, v.horario AS Horario
                FROM vinculo v, vinculoturma vt, turma t, disciplina d WHERE v.cod_vinculo LIKE vt.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina AND t.cod_turma LIKE vt.cod_turma ORDER BY t.cod_turma, v.horario";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {

                    echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark' >";
                      echo  "<div class='jumbotron px-6 pt-5 pb-0 mt-2 bg-primary'>";
                        echo  "<div class='row d-flex'>";
                          echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                            echo  "<a class='card-link'>";
                              echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                                echo  "<div class='card-body text-center'>";
                                  echo  "<h4 class='card-tittle'>Aluno não encontrado</h4>";
                                echo  "</div>";
                              echo  "</div>";
                            echo  "</a>";
                          echo  "</div>";
                        echo  "</div>";
                      echo  "</div>";
                    echo  "</div>";

                }else{
                  echo"<h3 class='text-white'>Vinculos de Turmas:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios Vinculo(s) encontrado(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Turma</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Sala</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo</th>";
                      echo "<th>Horário </th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $codVinculo = $tupla['Codigo'];
                      echo "<td style='width:20%'>$tupla[Turma]</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td>$tupla[Sala]</td>";
                      echo "<td>$tupla[Dia_Semana]</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td style='width:10%'>$tupla[Horario]° Tempo</td>";


                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoTurma&codVinculo=$codVinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoTurma&codVinculo=$codVinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                }
                }

            if($_GET['acao'] === 'buscarAluno')
            {
                $nome = $_GET['nome'];
                $ra = $_GET['ra'];
                $sql = "SELECT u.RA AS RA, u.nome_aluno AS Nome,
                u.curso_aluno AS Curso,
                u.periodo_aluno AS Periodo,
                u.email_aluno AS Email FROM aluno u ";
                $where = "";
                $and = "";
                if(empty($nome) === FALSE){
                  $where = "WHERE u.nome_aluno LIKE '%$nome%'";
                  $and = " 1 ";
                }
                if(empty($ra) === FALSE){
                      if($and === "1")
                      {
                        $where = $where."AND u.RA lIKE '%$ra%'";
                      }else
                      {
                        $where = "WHERE u.RA lIKE '%$ra%'";
                      }
                }
                if(empty($ra) === TRUE && empty($nome) === TRUE){
                  echo "Nenhum Valor foi Digitado, Tente Novamente!";
                    header("Refresh: 2; url=index.php");
                    exit(0);
                }
                $sql = $sql.$where." ORDER BY u.nome_aluno ";
                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {
                     echo "Nenhum Aluno Encontrado!";
                      header("Refresh: 2; url=index.php");
                      exit(0);
                }else{
                  echo"<h3 class='text-white'>BUSCA POR ALUNOS:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios usuário(s) encontrado(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";
                  echo "<tr class='thead-dark'>";
                  echo "<th>RA</th>";
                  echo "<th>Nome</th>";
                  echo "<th>Curso</th>";
                  echo "<th>Período</th>";
                  echo "<th>E-mail</th>";
                  echo "<th> </th>";
                  echo "<th> </th>";
                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {
                      echo "<tr>";
                      $ra = $tupla['RA'];
                      echo "<td>$ra</td>";
                      echo "<td>$tupla[Nome]</td>";
                      echo "<td>$tupla[Curso]</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td>$tupla[Email]</td>";
                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarAluno&RA=$ra'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirAluno&RA=$ra'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";                        echo "</tr>";
                      }
                  echo "</table>";
                   }
                  }

            if($_GET['acao'] === 'buscarProfesor')
            {
              $nome = $_GET['nome'];
              $siape = $_GET['siape'];
              if(empty($siape) === TRUE && empty($nome) === TRUE){
                echo "Nenhum Valor foi Digitado, Tente Novamente!";
                header("Refresh: 2; url= index.php");
                exit(0);
                }
                  $sql = "SELECT u.SIAPE AS SIAPE,
                  u.nome_professor AS Nome,
                  u.email_professor AS Email,
                  u.area_professor AS Area FROM professor u ";
                  $where = "";
                  $and = "";
              if(empty($nome) === FALSE)
              {
                $where = "WHERE u.nome_professor LIKE '%$nome%'";
                $and = " 1 ";
                }
              if(empty($siape) === FALSE)
              {
              if($and === "1")
              {
                  $where = $where."AND u.SIAPE lIKE '%$siape%'";
                  }
                  else
                  {
                    $where = "WHERE u.SIAPE lIKE '%$siape%'";
                    }
                  }

                  $sql = $sql.$where." ORDER BY u.SIAPE DESC";

                  $conexao->query($sql);
                  $numeroDeUsuarios = $conexao->num_rows();
              if ($numeroDeUsuarios==0)
              {
                echo "Nenhum Professor Encontrado!";
                header("Refresh: 2; url=index.php");
                exit(0);
                }else
                {
                  echo"<h3 class='text-white'>BUSCA POR PROFESSORES:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios professor(es) encontrado(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";
                  echo "<tr class='thead-dark'>";
                  echo "<th>SIAPE</th>";
                  echo "<th>Nome</th>";
                  echo "<th>E-mail Institucional</th>";
                  echo "<th>Área de Docência</th>";
                  echo "<th></th>";
                  echo "<th></th>";
                  echo "</tr>";
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {
                      echo "<tr>";
                      $siape = $tupla['SIAPE'];
                      echo "<td>$siape</td>";
                      echo "<td>$tupla[Nome]</td>";
                      echo "<td>$tupla[Email]</td>";
                      echo "<td>$tupla[Area]</td>";
                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarProfessor&SIAPE=$siape'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirProfessor&SIAPE=$siape'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";
                      echo "</tr>";
                      }
                    echo "</table>";
                    }
                    }

            if($_GET['acao'] === 'buscarSala')
            {
                $cod_sala = $_GET['cod_sala'];
                $bloco = $_GET['bloco'];

                $sql = "SELECT u.cod_sala AS Codigo,
                u.descricao_sala AS Descricao,
                u.bloco_sala AS Bloco FROM sala u ";

                $where = "";
                $and = "";

                if(empty($cod_sala) === FALSE)
                {
                  $where = "WHERE u.cod_sala LIKE '%$cod_sala%'";
                  $and = " 1 ";
                }

                if(empty($bloco) === FALSE)
                  {
                    if($and === "1")
                    {
                      $where = $where."AND u.bloco_sala lIKE '%$bloco%'";
                    }
                    else
                    {
                      $where = "WHERE u.bloco_sala LIKE '%$bloco%'";
                    }
                  }
                  if(empty($cod_sala) === TRUE && empty($bloco) === TRUE){
                    echo "Nenhum valor foi digitado. Tente Novamente!";
                      header("Refresh: 2; url=index.php");
                      exit(0);
                  }


                $sql = $sql.$where." ORDER BY u.cod_sala";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {
                    echo "Nenhuma Sala Encontrada!";
                      header("Refresh: 2; url=index.php");
                      exit(0);
                }else{
                  echo"<h3 class='text-white'>BUSCA POR SALAS:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios sala(s) encontrada(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Sala</th>";
                      echo "<th>Descrição</th>";
                      echo "<th>Bloco</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_sala = $tupla['Codigo'];
                      echo "<td>$cod_sala</td>";
                      echo "<td>$tupla[Descricao]</td>";
                      echo "<td>$tupla[Bloco]</td>";

                      echo "<td style='width: 10%'><a href='EditarDados.php?acao=editarSala&CodSala=$cod_sala'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirSala&CodSala=$cod_sala'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }
                }

            if($_GET['acao'] === 'buscarTurma')
            {
              $cod_turma = $_GET['cod_turma'];
              $turno_turma = $_GET['turno_turma'];
              $curso_turma=$_GET['curso_turma'];
              $periodo_turma=$_GET['periodo_turma'];

                $sql = "SELECT t.cod_turma AS Turma,
                t.turno_turma AS Turno,
                t.curso_turma AS Curso, t.periodo_turma AS Periodo FROM turma t WHERE cod_null = 0";
                $where1="";
                $where2="";
                $where3="";
                $where4="";

                if(empty($cod_turma) === FALSE)
                {
                  $where1 = " AND t.cod_turma LIKE '%$cod_turma%'";

                }
                if(empty($turno_turma) === FALSE)
                {
                  $where2 = " AND t.turno_turma LIKE '%$turno_turma%'";

                }
                if(empty($curso_turma) === FALSE)
                {
                  $where3 = " AND t.curso_turma LIKE '%$curso_turma%'";

                }
                if(empty($periodo_turma) === FALSE)
                {
                  $where4 = " AND t.periodo_turma LIKE '%$periodo_turma%'";

                }


                $sql = $sql.$where1.$where2.$where3.$where4." ORDER BY t.cod_turma";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {
                    echo "Nenhuma Turma Encontrada!";
                }else{
                  echo"<h3 class='text-white'>BUSCA POR TURMAS:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios turma(s) encontrada(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Turma</th>";
                      echo "<th>Turno</th>";
                      echo "<th>Curso</th>";
                      echo "<th>Periodo</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $cod_turma = $tupla['Turma'];
                      echo "<td>$cod_turma</td>";
                      echo "<td>$tupla[Turno]</td>";
                      echo "<td>$tupla[Curso]</td>";
                      echo "<td>$tupla[Periodo]° Semestre</td>";

                      echo "<td style='width: 10%'><a href='EditarDados.php?acao=editarTurma&CodTurma=$cod_turma'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirTurma&CodTurma=$cod_turma'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                  }
                }

            if($_GET['acao'] === 'buscarDisciplina')
            {
              $periodoDisciplina = $_GET['periodoDisciplina'];
              $descricaoDisciplina = $_GET['descricaoDisciplina'];
              $cursoDisciplina= $_GET['cursoDisciplina'];
              $sql ="SELECT u.cod_disciplina AS Codigo,
              u.descricao_disciplina AS Descricao,
              u.periodo_disciplina AS Periodo, u.curso_disciplina AS Curso FROM disciplina u ";
              $where="";
              $where1 ="";
              $where2 ="";
              $where3 ="";
              $cont =0;
              $and=" AND ";
              $and1="";
              $and2="";
              $and3="";


              if(empty($periodoDisciplina) === FALSE)
              {
                $where = "u.periodo_disciplina LIKE '%$periodoDisciplina%'";
                $where1 = "u.periodo_disciplina LIKE '%$periodoDisciplina%'";
                $and1 = " AND ";
                $cont = $cont+1;
              }
              if(empty($descricaoDisciplina) === FALSE)
              {
                $where = "U.descricao_disciplina LIKE '%$descricaoDisciplina%'";
                $where2 = "u.descricao_disciplina LIKE '%$descricaoDisciplina%'";
                $and2 = " AND ";
                $cont = $cont+1;
              }
              if(empty($cursoDisciplina) === FALSE)
              {
                $where = "u.curso_disciplina LIKE '%$cursoDisciplina%'";
                $where3 = "u.curso_disciplina LIKE '%$cursoDisciplina%'";
                $and3 = " AND ";
                $cont = $cont+1;
              }

              if ($cont==3) {
                $sql = $sql.'WHERE '.$where1.$and.$where2.$and.$where3;
              }
              if ($cont==2 && empty($where1) === FALSE) {
                $sql = $sql.'WHERE '.$where1.$and2.$where2.$and3.$where3;
              }
              if ($cont==2 && empty($where2) === FALSE && empty($where3) === FALSE) {
                $sql = $sql.'WHERE '.$where2.$and.$where3;
              }
              if ($cont==1) {
                $sql = $sql.'WHERE '.$where;
              }


                if(empty($periodoDisciplina) === TRUE && empty($descricaoDisciplina) === TRUE && empty($cursoDisciplina) === TRUE){
                  echo "Nenhum valor foi digitado. Tente Novamente!";
                    header("Refresh: 2; url=index.php");
                    exit(0);
                }
              $conexao->query($sql);
              $numeroDeUsuarios = $conexao->num_rows();
              if ($numeroDeUsuarios==0) {
                  echo "Nenhuma Sala Encontrada!";
              }else{
                echo"<h3 class='text-white'>BUSCA POR DISCIPLINAS:</h3>";
                echo "<h6 class='text-white'>$numeroDeUsuarios Disciplina(s) encontrada(s)</h6>";
                echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                echo "<tr class='thead-dark'>";

                    echo "<th>Código</th>";
                    echo "<th>Descrição</th>";
                    echo "<th>Período Padão</th>";
                    echo "<th>Curso</th>";
                    echo "<th> </th>";
                    echo "<th> </th>";


                echo "</tr>";
                for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                {

                  echo "<tr>";

                    $cod_disciplina = $tupla['Codigo'];
                    echo "<td>$cod_disciplina</td>";
                    echo "<td>$tupla[Descricao]</td>";
                    echo "<td>$tupla[Periodo]° Semestre</td>";
                    echo "<td>$tupla[Curso]</td>";

                    echo "<td style='width:10%'><a href='EditarDados.php?acao=editarDisciplina&codDisciplina=$cod_disciplina'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                    echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirDisciplina&codDisciplina=$cod_disciplina'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                  echo "</tr>";
                }
                echo "</table>";
                }
              }

            if($_GET['acao'] === 'buscarVinculoSala')
            {
              $cod_disciplina = $_GET['cod_disciplina'];
              $cod_sala = $_GET['cod_sala'];
              $diaSemana = $_GET['diaSemana'];

              $sql ="SELECT d.descricao_disciplina AS Disciplina, v.cod_vinculo AS Codigo, v.cod_sala AS Sala,v.dia_semana AS Dia_da_Semana, v.periodo AS Periodo, v.horario AS Horario FROM vinculo v, disciplina d WHERE d.cod_disciplina LIKE v.cod_disciplina ";



              $where1 = "";
              $where2 = "";
              $where3 = "";
              $and = "";

              if(empty($cod_disciplina) === FALSE)
              {
                $where1 = "AND v.cod_disciplina LIKE '%$cod_disciplina%'";
              }
              if(empty($cod_sala) === FALSE)
              {
                $where2 = "AND v.cod_sala LIKE '%$cod_sala%'";
              }
              if(empty($diaSemana) === FALSE)
              {
                $where3 = "AND v.dia_semana LIKE '%$diaSemana%'";
              }

              if(empty($cod_sala) === TRUE && empty($cod_disciplina) === TRUE && empty($diaSemana) === TRUE){
                  echo "Nenhum valor foi digitado. Tente Novamente!";
              }

              $sql = $sql.$where1.$where2.$where3." ORDER BY v.periodo, v.horario";

              $conexao->query($sql);
              $numeroDeUsuarios = $conexao->num_rows();
              if ($numeroDeUsuarios==0) {
                  echo "Nenhuma Sala Encontrada!";
                    header("Refresh: 2; url=index.php");
                    exit(0);
              }else{
                echo"<h3 class='text-white'>BUSCA POR DISCIPLINAS:</h3>";
                echo "<h6 class='text-white'>$numeroDeUsuarios Disciplina(s) encontrada(s)</h6>";
                echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Sala</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo </th>";
                      echo "<th>Horario</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";
                      $cod_vinculo = $tupla['Codigo'];
                      $cod_sala = $tupla['Sala'];
                      echo "<td>$cod_sala</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td style='text-align:center'>$tupla[Dia_da_Semana] Feira</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td>$tupla[Horario]° Tempo</td>";

                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoSala&CodVinculo=$cod_vinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoSala&CodVinculo=$cod_vinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
              }
              }

            if($_GET['acao'] === 'buscarVinculoProfessor')
            {
              $siape_professor = $_GET['siape'];


              $sql ="SELECT p.nome_professor AS Professor, vp.cod_vinculo_professor AS Codigo, d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, v.horario AS Horario
              FROM vinculo v, vinculoprofessor vp, professor p, disciplina d WHERE v.cod_vinculo LIKE vp.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina AND p.SIAPE LIKE vp.SIAPE ";

              $where = "";

              if(empty($siape_professor) === FALSE)
              {
                $where = "AND vp.siape LIKE '%$siape_professor%'";
              }

              if(empty($nome_professor) === TRUE && empty($siape_professor) === TRUE){
                echo "Nenhum valor foi digitado. Veja todos:";
              }


              $sql = $sql.$where." ORDER BY nome_professor, horario";

              $conexao->query($sql);
              $numeroDeUsuarios = $conexao->num_rows();
              if ($numeroDeUsuarios==0) {

                  echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark' >";
                    echo  "<div class='jumbotron px-6 pt-5 pb-0 mt-2 bg-primary'>";
                      echo  "<div class='row d-flex'>";
                        echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                          echo  "<a class='card-link'>";
                            echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                              echo  "<div class='card-body text-center'>";
                                echo  "<h4 class='card-tittle'>Professor não encontrado</h4>";
                              echo  "</div>";
                            echo  "</div>";
                          echo  "</a>";
                        echo  "</div>";
                      echo  "</div>";
                    echo  "</div>";
                  echo  "</div>";

              }else{
                echo"<h3 class='text-white'>Vinculos de Professores:</h3>";
                echo "<h6 class='text-white'>$numeroDeUsuarios Vinculo(s) encontrado(s)</h6>";
                echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                echo "<tr class='thead-dark'>";

                    echo "<th>Professor</th>";
                    echo "<th>Disciplina</th>";
                    echo "<th>Sala</th>";
                    echo "<th>Dia da Semana</th>";
                    echo "<th>Periodo</th>";
                    echo "<th>Horário </th>";
                    echo "<th> </th>";
                    echo "<th> </th>";


                echo "</tr>";
                for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                {

                  echo "<tr>";

                    $codVinculo = $tupla['Codigo'];
                    echo "<td style='width:20%'>$tupla[Professor]</td>";
                    echo "<td>$tupla[Disciplina]</td>";
                    echo "<td>$tupla[Sala]</td>";
                    echo "<td>$tupla[Dia_Semana]</td>";
                    echo "<td>$tupla[Periodo]</td>";
                    echo "<td style='width:10%'>$tupla[Horario]° Tempo</td>";


                    echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoProfessor&codVinculo=$codVinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                    echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoProfessor&codVinculo=$codVinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                  echo "</tr>";
                }
                echo "</table>";
              }
              }

            if($_GET['acao'] === 'buscarVinculoAluno')
            {
                $ra_aluno = $_GET['ra'];
                $nome_aluno = $_GET['nome'];


                $sql ="SELECT a.nome_aluno AS Aluno, va.cod_vinculo_aluno AS Codigo, d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, v.horario AS Horario
                FROM vinculo v, vinculoaluno va, aluno a, disciplina d WHERE v.cod_vinculo LIKE va.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina AND a.RA LIKE va.RA ";

                $where1 = "";
                $where2 = "";


                if(empty($nome_aluno) === FALSE)
                {
                  $where1 = "AND nome_aluno LIKE '%$nome_aluno%'";
                }
                if(empty($ra_aluno) === FALSE)
                {
                  $where2 = "AND va.RA LIKE '%$ra_aluno%'";
                }

                if(empty($nome_aluno) === TRUE && empty($ra_aluno) === TRUE){
                  echo "Nenhum valor foi digitado. Veja abaixo todos os vinculos:";
                }


                $sql = $sql.$where1.$where2." ORDER BY a.nome_aluno, v.horario";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {

                    echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark' >";
                      echo  "<div class='jumbotron px-6 pt-5 pb-0 mt-2 bg-primary'>";
                        echo  "<div class='row d-flex'>";
                          echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                            echo  "<a class='card-link'>";
                              echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                                echo  "<div class='card-body text-center'>";
                                  echo  "<h4 class='card-tittle'>Aluno não encontrado</h4>";
                                echo  "</div>";
                              echo  "</div>";
                            echo  "</a>";
                          echo  "</div>";
                        echo  "</div>";
                      echo  "</div>";
                    echo  "</div>";

                }else{
                  echo"<h3 class='text-white'>Vinculos de Alunos:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios Vinculo(s) encontrado(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Aluno</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Sala</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo</th>";
                      echo "<th>Horário </th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $codVinculo = $tupla['Codigo'];
                      echo "<td style='width:20%'>$tupla[Aluno]</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td>$tupla[Sala]</td>";
                      echo "<td>$tupla[Dia_Semana]</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td style='width:10%'>$tupla[Horario]° Tempo</td>";


                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoAluno&codVinculo=$codVinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoAluno&codVinculo=$codVinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                }
                }

            if($_GET['acao'] === 'buscarVinculoTurma')
            {
                $cod_turma = $_GET['cod_turma'];


                $sql ="SELECT t.cod_turma AS Turma, vt.cod_vinculo_turma AS Codigo, d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, v.horario AS Horario
                FROM vinculo v, vinculoturma vt, turma t, disciplina d WHERE v.cod_vinculo LIKE vt.cod_vinculo AND d.cod_disciplina LIKE v.cod_disciplina AND t.cod_turma LIKE vt.cod_turma ";

                $where = "";


                if(empty($cod_turma) === FALSE)
                {
                  $where = "AND t.cod_turma LIKE '%$cod_turma%'";
                }


                $sql = $sql.$where." ORDER BY t.cod_turma, v.horario";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {

                    echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark' >";
                      echo  "<div class='jumbotron px-6 pt-5 pb-0 mt-2 bg-primary'>";
                        echo  "<div class='row d-flex'>";
                          echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                            echo  "<a class='card-link'>";
                              echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                                echo  "<div class='card-body text-center'>";
                                  echo  "<h4 class='card-tittle'>Aluno não encontrado</h4>";
                                echo  "</div>";
                              echo  "</div>";
                            echo  "</a>";
                          echo  "</div>";
                        echo  "</div>";
                      echo  "</div>";
                    echo  "</div>";

                }else{
                  echo"<h3 class='text-white'>Vinculos de Turmas:</h3>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios Vinculo(s) encontrado(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";

                      echo "<th>Turma</th>";
                      echo "<th>Disciplina</th>";
                      echo "<th>Sala</th>";
                      echo "<th>Dia da Semana</th>";
                      echo "<th>Periodo</th>";
                      echo "<th>Horário </th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {

                    echo "<tr>";

                      $codVinculo = $tupla['Codigo'];
                      echo "<td style='width:20%'>$tupla[Turma]</td>";
                      echo "<td>$tupla[Disciplina]</td>";
                      echo "<td>$tupla[Sala]</td>";
                      echo "<td>$tupla[Dia_Semana]</td>";
                      echo "<td>$tupla[Periodo]</td>";
                      echo "<td style='width:10%'>$tupla[Horario]° Tempo</td>";


                      echo "<td style='width:10%'><a href='EditarDados.php?acao=editarVinculoTurma&codVinculo=$codVinculo'<button type='submit' class='btn btn-primary btn-outline-light'>Editar</button></a></td>";
                      echo "<td style='width:10%'><a href='ExcluirDados.php?acao=excluirVinculoTurma&codVinculo=$codVinculo'<button type='submit'style='background-color:#cc0000' class='btn btn-outline-light'>Excluir</button></a></td>";

                    echo "</tr>";
                  }
                  echo "</table>";
                }
                }

            if($_GET['acao'] === 'horarioSala')
            {
                $cod_sala = $_GET['cod_sala'];
                  if(empty($cod_sala) === TRUE){
                    echo "Nenhum valor foi digitado. Tente Novamente!";
                      header("Refresh: 2; url=index.php");
                      exit(0);
                  }

                  echo"<h3 class='text-white'>Horario da sala $cod_sala:</h3>";

                  echo "<table style='text-align: center' class='table table-light table-hover table-responsive-sm  table-responsive-md table-responsive-lg table-responsive-p table-responsive-xl'>";
                  echo "<tr class='thead-dark text_center'>";
                      echo "<th >Tempo</th>";
                      echo "<th >Segunda</th>";
                      echo "<th >Terça</th>";
                      echo "<th >Quarta</th>";
                      echo "<th >Quinta</th>";
                      echo "<th >Sexta</th>";
                  echo "</tr>";
                  echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                  echo "<th colspan= '7'>Periodo Matutino</th>";
                  echo "</tr>";

                  for ($i=1; $i <=7 ; $i++) {
                    if ($i==4) {
                      echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                      echo "<th colspan= '7'>Intervalo</th>";
                      echo "</tr>";
                    }
                    echo "<tr>";
                    $periodo ="";
                    $horario ="";
                    $valor1="";
                    $valor2="";
                    $valor3="";
                    $valor4="";
                    $valor5="";
                    $prof1="";
                    $prof2="";
                    $prof3="";
                    $prof4="";
                    $prof5="";

                    $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo
                    FROM vinculo v, disciplina d, professor p, vinculoprofessor vp where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND v.cod_sala LIKE '%$cod_sala%' AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                    $conexao->query($sql);
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {
                      if ($tupla['Horario']==$i && $tupla['Periodo']=="Matutino") {

                        if($tupla['Dia_Semana']=="Segunda") {
                          $valor1=$tupla['Disciplina'];
                          $prof1=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Terca") {
                          $valor2=$tupla['Disciplina'];
                          $prof2=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Quarta") {
                          $valor3=$tupla['Disciplina'];
                          $prof3=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Quinta") {
                          $valor4=$tupla['Disciplina'];
                          $prof4=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Sexta") {
                          $valor5=$tupla['Disciplina'];
                          $prof5=$tupla['Professor'];}
                          $periodo =$tupla['Periodo'];
                          $horario =$tupla['Horario'];
                      }
                    }
                    if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                    echo "<td style=';width:10%'>";echo $i."° tempo";echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3;;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4;;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5;;echo "</td>";
                    echo "</tr>";}
                  }
                  echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                  echo "<th colspan= '7'>Periodo Vespertino</th>";
                  echo "</tr>";
                  for ($i=1; $i <=7 ; $i++) {
                    if ($i==4) {
                      echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                      echo "<th colspan= '7'>Intervalo</th>";
                      echo "</tr>";
                    }
                    echo "<tr>";
                    $periodo ="";
                    $horario ="";
                    $valor1="";
                    $valor2="";
                    $valor3="";
                    $valor4="";
                    $valor5="";
                    $prof1="";
                    $prof2="";
                    $prof3="";
                    $prof4="";
                    $prof5="";

                    $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo
                    FROM vinculo v, disciplina d, professor p, vinculoprofessor vp where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND v.cod_sala LIKE '%$cod_sala%' AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                    $conexao->query($sql);
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {
                      if ($tupla['Horario']==$i && $tupla['Periodo']=="Vespertino") {

                        if($tupla['Dia_Semana']=="Segunda") {
                          $valor1=$tupla['Disciplina'];
                          $prof1=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Terca") {
                          $valor2=$tupla['Disciplina'];
                          $prof2=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Quarta") {
                          $valor3=$tupla['Disciplina'];
                          $prof3=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Quinta") {
                          $valor4=$tupla['Disciplina'];
                          $prof4=$tupla['Professor'];}

                        if($tupla['Dia_Semana']=="Sexta") {
                          $valor5=$tupla['Disciplina'];
                          $prof5=$tupla['Professor'];}
                          $periodo =$tupla['Periodo'];
                          $horario =$tupla['Horario'];
                      }
                    }
                    if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                    echo "<td style=';width:10%'>";echo $i."° tempo";echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3;;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4;;echo "</td>";
                    echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5;;echo "</td>";
                    echo "</tr>";}
                  }
                  echo "</tbody>";
                  echo "</table>";

                }

            if($_GET['acao'] === 'horarioProfessor')
            {
                 $SIAPE = $_GET['SIAPE'];
                   if(empty($SIAPE) === TRUE){
                     echo "Nenhum valor foi digitado. Tente Novamente!";

                   }

                 $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                 FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, sala s where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND vp.SIAPE LIKE '%$SIAPE%' AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                 $conexao->query($sql);
                 $numeroDeUsuarios = $conexao->num_rows();
                 if ($numeroDeUsuarios==0) {
                   echo "<div style='text-align: center' class='jumbotron px-6 pt-4 pb-2 mt-2 bg-primary'>";
                     echo "<h4 class='text-white'>Nenhum Professor Encontrado!</h4>";
                     echo "</div>";

                 }else{
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {$nome_professor=$tupla['Professor'];}
                   echo"<h3 class='text-white'>Horario do(a) professor(a) $nome_professor :</h3>";

                   echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-md table-responsive-lg table-responsive-p table-responsive-xl'>";
                   echo "<tr class='thead-dark'>";
                       echo "<th >Tempo</th>";
                       echo "<th style='text-align: center'  >Segunda</th>";
                       echo "<th style='text-align: center' >Terça</th>";
                       echo "<th style='text-align: center' >Quarta</th>";
                       echo "<th style='text-align: center' >Quinta</th>";
                       echo "<th style='text-align: center' >Sexta</th>";
                   echo "</tr>";
                   echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                   echo "<th colspan= '7'>Periodo Matutino</th>";
                   echo "</tr>";
                   for ($i=1; $i <=7 ; $i++) {
                     if ($i==4) {
                       echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                       echo "<th colspan= '7'>Intervalo</th>";
                       echo "</tr>";
                     }

                     $periodo ="";
                     $horario ="";
                     $valor1="";
                     $valor2="";
                     $valor3="";
                     $valor4="";
                     $valor5="";
                     $sala1="";
                     $sala2="";
                     $sala3="";
                     $sala4="";
                     $sala5="";

                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, sala s where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND vp.SIAPE LIKE '%$SIAPE%' AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                     $conexao->query($sql);
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {

                       if ($tupla['Horario']==$i && $tupla['Periodo']=="Matutino") {

                         if($tupla['Dia_Semana']=="Segunda") {
                           $valor1=$tupla['Disciplina'];
                           $sala1=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Terca") {
                           $valor2=$tupla['Disciplina'];
                           $sala2=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Quarta") {
                           $valor3=$tupla['Disciplina'];
                           $sala3=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Quinta") {
                           $valor4=$tupla['Disciplina'];
                           $sala4=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Sexta") {
                           $valor5=$tupla['Disciplina'];
                           $sala5=$tupla['Sala'];}
                           $periodo =$tupla['Periodo'];
                           $horario =$tupla['Horario'];
                       }

                     }
                     if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE) {

                       echo "<tr style='width:10%'>";
                       echo "<td>";echo $i."° tempo";echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$sala1;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$sala2;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$sala3;;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$sala4;;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$sala5;;echo "</td>";
                       echo "</tr>";
                     }

                   }
                   echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                   echo "<th colspan= '7'>Periodo Vespertino</th>";
                   echo "</tr>";
                   for ($i=1; $i <=7 ; $i++) {
                     if ($i==4) {
                       echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                       echo "<th colspan= '7'>Intervalo</th>";
                       echo "</tr>";
                     }
                     echo "<tr>";
                     $periodo ="";
                     $horario ="";
                     $valor1="";
                     $valor2="";
                     $valor3="";
                     $valor4="";
                     $valor5="";
                     $sala1="";
                     $sala2="";
                     $sala3="";
                     $sala4="";
                     $sala5="";

                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, sala s where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND vp.SIAPE LIKE '%$SIAPE%' AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                     $conexao->query($sql);
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {

                       if ($tupla['Horario']==$i && $tupla['Periodo']=="Vespertino") {

                         if($tupla['Dia_Semana']=="Segunda") {
                           $valor1=$tupla['Disciplina'];
                           $sala1=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Terca") {
                           $valor2=$tupla['Disciplina'];
                           $sala2=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Quarta") {
                           $valor3=$tupla['Disciplina'];
                           $sala3=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Quinta") {
                           $valor4=$tupla['Disciplina'];
                           $sala4=$tupla['Sala'];}

                         if($tupla['Dia_Semana']=="Sexta") {
                           $valor5=$tupla['Disciplina'];
                           $sala5=$tupla['Sala'];}
                           $periodo =$tupla['Periodo'];
                           $horario =$tupla['Horario'];
                       }

                     }
                     if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE) {

                       echo "<tr>";
                       echo "<td style='width:10%'>";echo $i."° tempo";echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$sala1;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$sala2;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$sala3;;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$sala4;;echo "</td>";
                       echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$sala5;;echo "</td>";
                       echo "</tr>";
                     }
                   }
                   echo "</tbody>";
                   echo "</table>";
                  }
                  }

            if($_GET['acao'] === 'horarioTurma')
            {
                 $cod_turma = $_GET['cod_turma'];
                   if(empty($cod_turma) === TRUE){
                     echo "Nenhum valor foi digitado. Tente Novamente!";

                   }

                   $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, t.cod_turma AS Turma, v.horario AS Horario,
                   v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                   FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, vinculoturma vt, turma t, sala s, aluno a
                   WHERE vp.cod_vinculo LIKE v.cod_vinculo
                   AND vp.SIAPE LIKE p.SIAPE
                   AND vt.cod_turma = $cod_turma
                   AND t.cod_turma = $cod_turma
                   AND vt.cod_vinculo LIKE v.cod_vinculo
                   AND v.cod_sala LIKE s.cod_sala
                   AND v.cod_disciplina LIKE d.cod_disciplina
                   ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                   $conexao->query($sql);
                 $numeroDeUsuarios = $conexao->num_rows();
                 if ($numeroDeUsuarios==0) {
                   echo "<div style='text-align: center' class='jumbotron px-6 pt-4 pb-2 mt-2 bg-primary'>";
                     echo "<h4 class='text-white'>Nenhuma Turma Encontrada!</h4>";
                     echo "</div>";

                 }else{
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {$turma=$tupla['Turma'];}
                   echo"<h3 class='text-white'>Horario da turma $turma :</h3>";

                   echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-md table-responsive-lg table-responsive-p table-responsive-xl'>";
                   echo "<tr class='thead-dark'>";
                       echo "<th >Tempo</th>";
                       echo "<th style='text-align: center'  >Segunda</th>";
                       echo "<th style='text-align: center' >Terça</th>";
                       echo "<th style='text-align: center' >Quarta</th>";
                       echo "<th style='text-align: center' >Quinta</th>";
                       echo "<th style='text-align: center' >Sexta</th>";
                   echo "</tr>";
                   echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                   echo "<th colspan= '7'>Periodo Matutino</th>";
                   echo "</tr>";
                   for ($i=1; $i <=7 ; $i++) {
                     if ($i==4) {
                       echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                       echo "<th colspan= '7'>Intervalo</th>";
                       echo "</tr>";
                     }
                     $periodo ="";
                     $horario ="";
                     $valor1="";
                     $valor2="";
                     $valor3="";
                     $valor4="";
                     $valor5="";
                     $sala1="";
                     $sala2="";
                     $sala3="";
                     $sala4="";
                     $sala5="";
                     $prof1="";
                     $prof2="";
                     $prof3="";
                     $prof4="";
                     $prof5="";

                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario,
                     v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, vinculoturma vt, turma t, sala s
                     WHERE vp.cod_vinculo LIKE v.cod_vinculo
                     AND vp.SIAPE LIKE p.SIAPE
                     AND vt.cod_turma = $cod_turma
                     AND t.cod_turma = $cod_turma
                     AND vt.cod_vinculo LIKE v.cod_vinculo
                     AND v.cod_sala LIKE s.cod_sala
                     AND v.cod_disciplina LIKE d.cod_disciplina
                     ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                     $conexao->query($sql);
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {
                       if ($tupla['Horario']==$i && $tupla['Periodo']=="Matutino") {

                         if($tupla['Dia_Semana']=="Segunda") {
                           $valor1=$tupla['Disciplina'];
                           $sala1=$tupla['Sala'];
                           $prof1=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Terca") {
                           $valor2=$tupla['Disciplina'];
                           $sala2=$tupla['Sala'];
                           $prof2=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quarta") {
                           $valor3=$tupla['Disciplina'];
                           $sala3=$tupla['Sala'];
                           $prof3=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quinta") {
                           $valor4=$tupla['Disciplina'];
                           $sala4=$tupla['Sala'];
                           $prof4=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Sexta") {
                           $valor5=$tupla['Disciplina'];
                           $sala5=$tupla['Sala'];
                           $prof5=$tupla['Professor'];}
                           $periodo =$tupla['Periodo'];
                           $horario =$tupla['Horario'];
                       }

                     }
                     if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                     echo "<td style='width:10%'>";echo $i."° tempo";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1."<br><b>".$sala1."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2."<br><b>".$sala2."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3."<br><b>".$sala3."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4."<br><b>".$sala4."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5."<br><b>".$sala5."</b>";echo "</td>";
                     echo "</tr>";}

                   }
                   echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                   echo "<th colspan= '7'>Periodo Vespertino</th>";
                   echo "</tr>";
                   for ($i=1; $i <=7 ; $i++) {
                     if ($i==4) {
                       echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                       echo "<th colspan= '7'>Intervalo</th>";
                       echo "</tr>";
                     }
                     echo "<tr>";
                     $periodo ="";
                     $horario ="";
                     $valor1="";
                     $valor2="";
                     $valor3="";
                     $valor4="";
                     $valor5="";
                     $sala1="";
                     $sala2="";
                     $sala3="";
                     $sala4="";
                     $sala5="";

                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario,
                     v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, vinculoturma vt, turma t, sala s
                     WHERE vp.cod_vinculo LIKE v.cod_vinculo
                     AND vp.SIAPE LIKE p.SIAPE
                     AND vt.cod_turma = $cod_turma
                     AND t.cod_turma = $cod_turma
                     AND vt.cod_vinculo LIKE v.cod_vinculo
                     AND v.cod_sala LIKE s.cod_sala
                     AND v.cod_disciplina LIKE d.cod_disciplina
                     ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                     $conexao->query($sql);
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {
                       if ($tupla['Horario']==$i && $tupla['Periodo']=="Vespertino") {

                         if($tupla['Dia_Semana']=="Segunda") {
                           $valor1=$tupla['Disciplina'];
                           $sala1=$tupla['Sala'];
                           $prof1=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Terca") {
                           $valor2=$tupla['Disciplina'];
                           $sala2=$tupla['Sala'];
                           $prof2=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quarta") {
                           $valor3=$tupla['Disciplina'];
                           $sala3=$tupla['Sala'];
                           $prof3=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quinta") {
                           $valor4=$tupla['Disciplina'];
                           $sala4=$tupla['Sala'];
                           $prof4=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Sexta") {
                           $valor5=$tupla['Disciplina'];
                           $sala5=$tupla['Sala'];
                           $prof5=$tupla['Professor'];}
                           $periodo =$tupla['Periodo'];
                           $horario =$tupla['Horario'];
                       }

                     }
                     if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                     echo "<td style='width:10%'>";echo $i."° tempo";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1."<br><b>".$sala1."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2."<br><b>".$sala2."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3."<br><b>".$sala3."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4."<br><b>".$sala4."</b>";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5."<br><b>".$sala5."</b>";echo "</td>";
                     echo "</tr>";}
                   }
                   echo "</tbody>";
                   echo "</table>";
                  }
                  }

          }

         ?>
        </div>
      </div>
    </div>


  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
