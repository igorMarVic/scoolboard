<?php
include_once "config.php";
include_once "connection.php";

$conexao = new Connection($host, $user, $password, $database);

if (isset($_GET['codigo'])) {
  $codigo = $_GET['codigo'];
  $email_codigo = base64_decode($codigo);

  $sql = "SELECT * FROM recuperacao_senha WHERE codigo_re = '$codigo' AND data>NOW()";
  $conexao->query($sql);

  if ($conexao->num_rows() >= 1) {
    ?>
    <!DOCTYPE html>
    <html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width-device-width, initial-scale=1, shrink-to-fit=no">

          <link rel="stylesheet" href="css/bootstrap.css">
          <link rel="stylesheet" href="css/styles.css">
      <link href="https://fonts.googleapis.com/css?family=Cute+Font|Staatliches&display=swap" rel="stylesheet">
      <style media="screen">
      @font-face{
        src: url(Modeka.otf);
        font-family: 'Modeka';
        font-weight: normal;
      }
      .esse{
        font-family: 'Modeka';
        font-size: 25px;
      }
      .dropdown-item:hover{
        background: inherit;
      }

      </style>
      <title>Recuperar senha</title>
    </head>
    <body  style="background-color:#313438;">

      <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSite">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
            <div class="dropdown-divider"></div>
            <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
            <div class="dropdown-divider"></div>
            <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
            <div class="dropdown-divider"></div>
            <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
            <div class="dropdown-divider"></div>
            <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

          </ul>
        </div>
      </nav>
            <div class="mb-sm-5 mb-5 display-4 text-center font-weight-bolder" style="text-shadow: 3px 3px black; color:white;font-family: 'Staatliches', cursive;">
              Recuperação de senha
            </div>


            <br><br>
            <form action="" method="post" enctype="multipart/form-data" name="dados" onSubmit="return enviardados_user();">

              <div class="row mb-sm-3">
                <div class="col-sm-3 col-3">

                </div>
                <div class="col-sm-6 col-6" style="background:#343a40 linear-gradient(180deg, #52585d, #343a40) repeat-x !important ">
                  <div class="row">
                    <div class="col-sm-4 col-4 mt-sm-4 mt-4 h1 mr-sm-3 mr-3 esse"  style="color:white;">
                      Digite a nova senha:
                    </div>
                    <div class="col-sm-7 col-7">
                      <div class="card-body text-center">

                        <input class=" form-control" type="password" name="novasenha" placeholder="	" style="text-align: center;background-color:#313438;border-style:none; width:100%;">
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="row mb-sm-3">
                <div class="col-sm-3 col-3">

                </div>
                <div class="col-sm-6 col-6" style="background:#343a40 linear-gradient(180deg, #52585d, #343a40) repeat-x !important ">
                  <div class="row">
                    <div class="col-sm-4 col-4 mt-sm-4 mt-4 h1 mr-sm-3 mr-3 esse"  style="color:white;">
                      Digite novamente a nova senha:
                    </div>
                    <div class="col-sm-7 col-7">
                      <div class="card-body text-center">

                        <input class=" form-control" type="password" name="novasenha2" placeholder="	" style="text-align: center;background-color:#313438;border-style:none; width:100%;">
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <input type="hidden" name="acao" value="mudar"><br>

              <div class="row">
                <div class="col-sm-8 col-8">

                </div>
                <input class="btn btn-dark" type="submit" name="" value="Mudar">
              </div>

              <script>
              function enviardados_user(){

                var nome, senha;

                //verifica campos vazios
                if(document.dados.novasenha.value==""|| document.dados.novasenha.value.length <= 5)
                {
                  alert( "Preencha campo SENHA corretamente!, ela deve conter no minimo 6 caracteres" );
                  document.dados.novasenha.focus();
                  return false;
                }

                if(document.dados.novasenha2.value==""|| document.dados.novasenha2.value.length <= 5)
                {
                  alert( "Preencha campo SENHA corretamente!, ela deve conter no minimo 6 caracteres" );
                  document.dados.novasenha2.focus();
                  return false;
                }
              }
              </script>


            </form>


            <script src="curso/node_modules/jquery/dist/jquery.js"></script>
            <script src="curso/node_modules/popper.js/dist/umd/popper.js"></script>
            <script src="curso/node_modules/bootstrap/dist/js/bootstrap.js"></script>
          </body>
          </html>



          <?php
          if (isset($_POST['acao']) && $_POST['acao'] == 'mudar') {
            $nova_senha = $_POST['novasenha'];
            $nova_senha2 = $_POST['novasenha2'];
            $nova_senha = sha1($nova_senha);
            $nova_senha2 = sha1($nova_senha2);

            if ($nova_senha == $nova_senha2) {
              $sql ="SELECT * FROM aluno WHERE email_aluno ='$email_codigo'";
              $conexao->query($sql);
              if ($conexao->num_rows() >= 1) {
                $sql = "UPDATE aluno SET senha ='$nova_senha' WHERE email_aluno ='$email_codigo'";
                $conexao->query($sql);
                $sql = "DELETE FROM recuperacao_senha WHERE codigo_re = '$codigo'";
                $conexao->query($sql);
                ?>
                <script type="text/javascript">
                alert( "Senha modificada" );
                </script>
                <?php

                header("Refresh: 0; url=login.php");
                exit(0);
              }

              $sql ="SELECT * FROM professor WHERE email_professor ='$email_codigo'";
              $conexao->query($sql);

              if ($conexao->num_rows() >= 1) {
                $sql = "UPDATE professor SET senha_professor ='$nova_senha' WHERE email_professor ='$email_codigo'";
                $conexao->query($sql);
                $sql = "DELETE FROM recuperacao_senha WHERE codigo_re = '$codigo'";
                $conexao->query($sql);
                ?>
                <script type="text/javascript">
                alert( "Senha modificada ad" );
                </script>
                <?php

                header("Refresh: 0; url=login.php");
                exit(0);
              }



            }else {
              echo "senhas diferentes";
              header("Refresh: 0; url=recuperar.php");
              exit(0);
            }
          }
        }else {
          header("Refresh: 0; url=login.php");
        }
      }else {
        echo "Desculpe mas este link já expirou!!";
      }
      ?>
