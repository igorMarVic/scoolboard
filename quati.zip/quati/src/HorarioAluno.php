<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <!--<div class="container mt-4">-->
      <div class="jumbotron px-1 pt-4 pb-2 mt-2 bg-primary">
        <!--<div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">-->


          <?php
            include_once "config.php";
            include_once "connection.php";

            $conexao = new Connection($host, $user, $password, $database);

            if(isset($_GET['acao']))
            {
              if($_GET['acao'] === 'HorarioAluno')
              {
                   $RA = $_GET['RA'];

                     if(empty($RA) === TRUE){
                       echo "Nenhum valor foi digitado. Tente Novamente!";
                         header("Refresh: 2; url=index.php");
                         exit(0);
                     }
                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, a.nome_aluno AS Aluno, v.horario AS Horario,
                     v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, vinculoaluno va, sala s, aluno a
                     WHERE vp.cod_vinculo LIKE v.cod_vinculo
                     AND vp.SIAPE LIKE p.SIAPE
                     AND va.RA = $RA
                     AND a.RA = $RA
                     AND va.cod_vinculo LIKE v.cod_vinculo
                     AND v.cod_sala LIKE s.cod_sala
                     AND v.cod_disciplina LIKE d.cod_disciplina
                     ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                   $conexao->query($sql);
                   $numeroDeUsuarios = $conexao->num_rows();
                   if ($numeroDeUsuarios==0) {
                        echo "<h3 class='text-white'>Nenhum Horario foi Encontrado!<h3>";
                         header("Refresh: 2; url=index.php");
                         exit(0);
                   }else{
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {$nome_aluno=$tupla['Aluno'];}
                       echo "<h3 class='text-white'>Horario do(a) aluno(a) $nome_aluno </h3>";
                       echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-md table-responsive-lg table-responsive-p table-responsive-xl'>";
                       echo "<thead>";
                       echo "<tr class='thead-dark'>";
                       echo "<th >Tempo</th>";
                       echo "<th >Segunda</th>";
                       echo "<th >Terça</th>";
                       echo "<th >Quarta</th>";
                       echo "<th >Quinta</th>";
                       echo "<th >Sexta</th>";
                       echo "</tr>";
                       echo "</thead>";
                       echo "<tbody>";
                       echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                       echo "<th colspan= '7'>Periodo Matutino</th>";
                       echo "</tr>";
                       for ($i=1; $i <=7 ; $i++) {

                         echo "<tr>";
                         $periodo ="";
                         $horario ="";
                         $valor1="";
                         $valor2="";
                         $valor3="";
                         $valor4="";
                         $valor5="";
                         $sala1="";
                         $sala2="";
                         $sala3="";
                         $sala4="";
                         $sala5="";
                         $prof1="";
                         $prof2="";
                         $prof3="";
                         $prof4="";
                         $prof5="";

                         $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                         FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, vinculoaluno va, sala s
                         WHERE vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND va.RA = $RA AND va.cod_vinculo LIKE v.cod_vinculo AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina
                         ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                         $conexao->query($sql);
                         for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                         {
                           if ($tupla['Horario']==$i && $tupla['Periodo']=="Matutino") {

                             if($tupla['Dia_Semana']=="Segunda") {
                               $valor1=$tupla['Disciplina'];
                               $sala1=$tupla['Sala'];
                               $prof1=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Terca") {
                               $valor2=$tupla['Disciplina'];
                               $sala2=$tupla['Sala'];
                               $prof2=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Quarta") {
                               $valor3=$tupla['Disciplina'];
                               $sala3=$tupla['Sala'];
                               $prof3=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Quinta") {
                               $valor4=$tupla['Disciplina'];
                               $sala4=$tupla['Sala'];
                               $prof4=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Sexta") {
                               $valor5=$tupla['Disciplina'];
                               $sala5=$tupla['Sala'];
                               $prof5=$tupla['Professor'];}
                               $periodo =$tupla['Periodo'];
                               $horario =$tupla['Horario'];
                           }

                         }
                         if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                         echo "<td style='width:10%'>";echo $i."° tempo";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1."<br><b>".$sala1."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2."<br><b>".$sala2."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3."<br><b>".$sala3."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4."<br><b>".$sala4."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5."<br><b>".$sala5."</b>";echo "</td>";
                         echo "</tr>";}
                       }
                       echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                       echo "<th colspan= '7'>Periodo Vespertino</th>";
                       echo "</tr>";
                       for ($i=1; $i <=7 ; $i++) {

                         echo "<tr>";
                         $periodo ="";
                         $horario ="";
                         $valor1="";
                         $valor2="";
                         $valor3="";
                         $valor4="";
                         $valor5="";
                         $sala1="";
                         $sala2="";
                         $sala3="";
                         $sala4="";
                         $sala5="";
                         $prof1="";
                         $prof2="";
                         $prof3="";
                         $prof4="";
                         $prof5="";

                         $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                         FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, vinculoaluno va, sala s
                         WHERE vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND va.RA = $RA AND va.cod_vinculo LIKE v.cod_vinculo AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina
                         ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                         $conexao->query($sql);
                         for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                         {
                           if ($tupla['Horario']==$i && $tupla['Periodo']=="Vespertino") {

                             if($tupla['Dia_Semana']=="Segunda") {
                               $valor1=$tupla['Disciplina'];
                               $sala1=$tupla['Sala'];
                               $prof1=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Terca") {
                               $valor2=$tupla['Disciplina'];
                               $sala2=$tupla['Sala'];
                               $prof2=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Quarta") {
                               $valor3=$tupla['Disciplina'];
                               $sala3=$tupla['Sala'];
                               $prof3=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Quinta") {
                               $valor4=$tupla['Disciplina'];
                               $sala4=$tupla['Sala'];
                               $prof4=$tupla['Professor'];}

                             if($tupla['Dia_Semana']=="Sexta") {
                               $valor5=$tupla['Disciplina'];
                               $sala5=$tupla['Sala'];
                               $prof5=$tupla['Professor'];}
                               $periodo =$tupla['Periodo'];
                               $horario =$tupla['Horario'];
                           }

                         }
                         if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {
                         echo "<td style='width:10%'>";echo $i."° tempo";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1."<br><b>".$sala1."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2."<br><b>".$sala2."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3."<br><b>".$sala3."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4."<br><b>".$sala4."</b>";echo "</td>";
                         echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5."<br><b>".$sala5."</b>";echo "</td>";
                         echo "</tr>";}
                       }


                     echo "</tbody>";
                     echo "</table>";
                     //echo "</div>";
                     echo "</div>";
                     //echo "</div>";

                }
              }
            }
            ?>

        </div>
      </div>

    </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

  </body>
