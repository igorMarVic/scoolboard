<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
require 'PHPMailer/PHPMailer/src/OAuth.php';
if (isset($_POST['emailton'])) {

    $destino= $_POST['emailton'];
		if (isset($_POST['acao']) && $_POST['acao'] == 'recuperar'){
      $destino= $_POST['emailton'];
      $assunto = $_POST['assunto'];
      $mensa = $_POST['mensa'];

				try {
					$mail = new PHPMailer;
					$mail->CharSet = "UTF-8";
					$mail->IsSMTP();
					$mail->SMPTSecure = 'starttls';

					$mail->Host = 'smtp-mail.outlook.com';
					$mail->SMTPAuth = true;
					$mail->Port = 587;
					$mail->Username ='scooboard@outlook.com';
					$mail->Password ='boardscool2019';

					$mail->SetFrom('scooboard@outlook.com','Escola');
					$mail->AddReplyTo('scooboard@outlook.com','Escola');
					$mail->Subject= $assunto;

					//EMAIL DO USUARIO
					$mail->AddAddress($destino,$assunto);

					$mail ->MsgHTML($mensa.'<a href="http://academico.ifms.edu.br/">Link</a>');

					$enviado = $mail->Send();

					//ISSO VERIFICA SE O EMAIL FOI ENVIADO TAOQUEI

					if ($enviado) {

						?>
						<script type="text/javascript">
						alert( "Enviado" );
						</script>
						<?php
						header("Refresh: 0; url=indexprofessor.php");
						exit(0);
					}else {
						echo "erro tentar novamente";
						header("Refresh: 2; url=indexprofessor.php");
						exit(0);
					}



				} catch (phpmailerException $e) {
					echo $e->errorMessage();
				}
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="manifest" href="../manifest.json">
  </head>
  <body>
    <?php
		  session_start();
		  if(isset($_SESSION['SIAPE'])===FALSE){
        echo  "<div class='container mt-4'>";
          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
              echo  "<div class='row d-flex'>";
                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                  echo  "<a class='card-link'>";
                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                      echo  "<div class='card-body text-center'>";
                        echo  "<h4 class='card-tittle'>Você precisa estar logado para acessar o sistema !</h4>";
                      echo  "</div>";
                    echo  "</div>";
                  echo  "</a>";
                echo  "</div>";
              echo  "</div>";
            echo  "</div>";
          echo  "</div>";
        echo  "</div>";
        header("Refresh: 3; url='login.php'");
		    exit(0);
		  }
		?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4 row m-0" >
      <div class="col-4">

      </div>
      <div class="jumbotron px-6 pt-4 pb-2 justify-content-center mt-2 bg-dark text-center">
        <div class="">


    <form class="" action="" method="post">
      <div class="form-row text-white">
      <div class="form-group col-md-12">
      <label for="nome">Assuto:</label>
      <input type="text" name="assunto" value=""><br>
      </div>
      <div class="form-group col-md-12">
      <label for="nome">Mensagem:</label>
      <textarea type="text" name="mensa" value="" col="40"></textarea>
      </div>
      </div>
      <input type="hidden" name="acao" value="recuperar">
      <input type="hidden" name="emailton" value="<?php echo $destino; ?>">
      <button type="submit" class="btn btn-primary btn-outline-light">Enviar</button>
    </form>
</div>
</div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
  </body>
</html>

<?php

exit(0);

}
?>
