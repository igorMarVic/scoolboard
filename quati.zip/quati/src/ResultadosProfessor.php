<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';
require 'PHPMailer/PHPMailer/src/OAuth.php';


 ?>
<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">

          <?php
          include_once "config.php";
          include_once "connection.php";

          $conexao = new Connection($host, $user, $password, $database);
          session_start();
          if(isset($_GET['acao']))
          {
             if($_GET['acao'] === 'buscarProfessor')
             {
              $nome = $_GET['nome'];
                  $sql = "SELECT u.SIAPE AS SIAPE,
                  u.nome_professor AS Nome,
                  u.email_professor AS Email,
                  u.area_professor AS Area FROM professor u ";
                  $where = "";
                if(empty($nome) === FALSE)
                {
                  $where = "WHERE u.nome_professor LIKE '%$nome%'";
                }
                    $sql = $sql.$where." ORDER BY u.nome_professor";
                    $conexao->query($sql);
                    $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0)
                {
                echo "Nenhum Professor Encontrado!";
                }else
                {
                  echo"<h4 class='text-white'>BUSCA POR PROFESSORES:</h4>";
                  echo "<h6 class='text-white'>$numeroDeUsuarios professor(es) encontrado(s)</h6>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";
                  echo "<tr class='thead-dark'>";
                  echo "<th></th>";
                  echo "<th>Nome</th>";
                  echo "<th>E-mail Institucional</th>";
                  echo "<th>Área de Docência</th>";
                  echo "</tr>";
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {
                      echo "<tr>";
                      $SIAPE=$tupla['SIAPE'];
                      echo "<td style='width:10%'><a href='ResultadosProfessor.php?acao=horarioProfessor&SIAPE=$SIAPE'<button type='submit'style='background-color:#0080ff' class='btn btn-outline-light'>Horário</button></a></td>";
                      echo "<td >$tupla[Nome]</td>";
                      echo "<td >$tupla[Email]</td>";
                      echo "<td>$tupla[Area]</td>";
                      echo "</tr>";
                      }
                      echo "</table>";

                 }
             }

             if($_GET['acao'] === 'listarProfessores')
             {
                 $sql ="SELECT u.SIAPE AS SIAPE,
                 u.nome_professor AS Nome,
                 u.email_professor AS Email,
                 u.area_professor AS Area FROM professor u ORDER BY u.nome_professor";
                 $conexao->query($sql);
                 echo"<h5 class='text-white mb-4'>LISTAGEM DE PROFESSORES:</h5>";
                 echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";
                 echo "<tr class='thead-dark'>";
                 echo "<th></th>";
                 echo "<th>Nome</th>";
                 echo "<th>E-mail Institucional</th>";
                 echo "<th>Área de Docência</th>";
                 echo "</tr>";
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {
                     echo "<tr>";
                     $SIAPE=$tupla['SIAPE'];
                     echo "<td style='width:10%'><a href='ResultadosProfessor.php?acao=horarioProfessor&SIAPE=$SIAPE'<button type='submit'style='background-color:#0080ff' class='btn btn-outline-light'>Horário</button></a></td>";
                     echo "<td >$tupla[Nome]</td>";
                     echo "<td >$tupla[Email]</td>";
                     echo "<td>$tupla[Area]</td>";
                     echo "</tr>";
                     }
                     echo "</table>";
                 }

             if($_GET['acao'] === 'buscarSala')
             {
                 $cod_sala = $_GET['cod_sala'];
                 $bloco = $_GET['bloco'];

                 $sql = "SELECT u.cod_sala AS Codigo,
                 u.descricao_sala AS Descricao,
                 u.bloco_sala AS Bloco FROM sala u ";


                 $where = "";
                 $and = "";

                 if(empty($cod_sala) === FALSE)
                 {
                   $where = "WHERE u.cod_sala LIKE '%$cod_sala%'";
                   $and = " 1 ";
                 }

                 if(empty($bloco) === FALSE)
                   {
                     if($and === "1")
                     {
                       $where = $where."AND u.bloco_sala lIKE '%$bloco%'";
                     }
                     else
                     {
                       $where = "WHERE u.bloco_sala LIKE '%$bloco%'";
                     }
                   }

                 $sql = $sql.$where." ORDER BY u.cod_sala";

                 $conexao->query($sql);
                 $numeroDeUsuarios = $conexao->num_rows();
                 if ($numeroDeUsuarios==0) {
                     echo "Nenhuma Sala Encontrada!";

                 }else{
                   echo"<h3 class='text-white'>BUSCA POR SALAS:</h3>";
                   echo "<h6 class='text-white'>$numeroDeUsuarios sala(s) encontrada(s)</h6>";
                   echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                   echo "<tr class='thead-dark'>";
                      echo "<th></th>";
                       echo "<th>Sala</th>";
                       echo "<th>Descrição</th>";
                       echo "<th>Bloco</th>";

                   echo "</tr>";

                   echo "<tbody>";
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {
                     $sala=$tupla['Codigo'];
                     echo "<tr>";
                       echo "<td style='width:10%'><a href='ResultadosProfessor.php?acao=horarioSala&cod_sala=$sala'<button type='submit'style='background-color:#0080ff' class='btn btn-outline-light'>Horário</button></a></td>";
                       echo "<td style='width:30%'>$tupla[Codigo]</td>";
                       echo "<td style='width:50%'>$tupla[Descricao]</td>";
                       echo "<td style='width:100%'>$tupla[Bloco]</td>";

                     echo "</tr>";
                   }
                   echo "</tbody>";
                   echo "</table>";
                   echo "</div>";
                   echo "</div>";
                   }
                 }

             if($_GET['acao'] === 'listarSalas')
             {
                   $sql ="SELECT u.cod_sala AS Codigo,
                   u.descricao_sala AS Descricao,
                   u.bloco_sala AS Bloco FROM sala u ORDER BY u.cod_sala";
                   $conexao->query($sql);
                   echo"<h2 class='text-white mb-4'>LISTAGEM DE SALAS:</h2>";
                   echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                   echo "<tr class='thead-dark'>";
                      echo "<th></th>";
                       echo "<th>Sala</th>";
                       echo "<th>Descrição</th>";
                       echo "<th>Bloco</th>";

                   echo "</tr>";

                   echo "<tbody>";
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {
                     $sala=$tupla['Codigo'];
                     echo "<tr>";
                       echo "<td style='width:10%'><a href='ResultadosProfessor.php?acao=horarioSala&cod_sala=$sala'<button type='submit'style='background-color:#0080ff' class='btn btn-outline-light'>Horário</button></a></td>";
                       echo "<td style='width:30%'>$tupla[Codigo]</td>";
                       echo "<td style='width:50%'>$tupla[Descricao]</td>";
                       echo "<td style='width:100%'>$tupla[Bloco]</td>";

                     echo "</tr>";
                   }
                   echo "</tbody>";
                   echo "</table>";
                   echo "</div>";
                   echo "</div>";
                   }

             if($_GET['acao'] === 'buscarDisciplina')
             {
               $periodoDisciplina = $_GET['periodoDisciplina'];
               $descricaoDisciplina = $_GET['descricaoDisciplina'];
               $cursoDisciplina= $_GET['cursoDisciplina'];
               $sql ="SELECT u.cod_disciplina AS Codigo,
               u.descricao_disciplina AS Descricao,
               u.periodo_disciplina AS Periodo, u.curso_disciplina AS Curso FROM disciplina u ";
               $where="";
               $where1 ="";
               $where2 ="";
               $where3 ="";
               $cont =0;
               $and=" AND ";
               $and1="";
               $and2="";
               $and3="";


               if(empty($periodoDisciplina) === FALSE)
               {
                 $where = "u.periodo_disciplina LIKE '%$periodoDisciplina%'";
                 $where1 = "u.periodo_disciplina LIKE '%$periodoDisciplina%'";
                 $and1 = " AND ";
                 $cont = $cont+1;
               }
               if(empty($descricaoDisciplina) === FALSE)
               {
                 $where = "U.descricao_disciplina LIKE '%$descricaoDisciplina%'";
                 $where2 = "u.descricao_disciplina LIKE '%$descricaoDisciplina%'";
                 $and2 = " AND ";
                 $cont = $cont+1;
               }
               if(empty($cursoDisciplina) === FALSE)
               {
                 $where = "u.curso_disciplina LIKE '%$cursoDisciplina%'";
                 $where3 = "u.curso_disciplina LIKE '%$cursoDisciplina%'";
                 $and3 = " AND ";
                 $cont = $cont+1;
               }

               if ($cont==3) {
                 $sql = $sql.'WHERE '.$where1.$and.$where2.$and.$where3;
               }
               if ($cont==2 && empty($where1) === FALSE) {
                 $sql = $sql.'WHERE '.$where1.$and2.$where2.$and3.$where3;
               }
               if ($cont==2 && empty($where2) === FALSE && empty($where3) === FALSE) {
                 $sql = $sql.'WHERE '.$where2.$and.$where3;
               }
               if ($cont==1) {
                 $sql = $sql.'WHERE '.$where;
               }
               $conexao->query($sql);
               $numeroDeUsuarios = $conexao->num_rows();
               if ($numeroDeUsuarios==0) {
                   echo "Nenhuma Sala Encontrada!";
               }else{
                 echo"<h3 class='text-white'>BUSCA POR DISCIPLINAS:</h3>";
                 echo "<h6 class='text-white'>$numeroDeUsuarios Disciplina(s) encontrada(s)</h6>";
                 echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                 echo "<tr class='thead-dark'>";

                     echo "<th>Código</th>";
                     echo "<th>Descrição</th>";
                     echo "<th>Período Padrão</th>";
                     echo "<th>Curso</th>";


                 echo "</tr>";
                 for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                 {

                   echo "<tr>";

                     $cod_disciplina = $tupla['Codigo'];
                     echo "<td>$cod_disciplina</td>";
                     echo "<td>$tupla[Descricao]</td>";
                     echo "<td>$tupla[Periodo]° Semestre</td>";
                     echo "<td>$tupla[Curso]</td>";

                   echo "</tr>";
                 }
                 echo "</table>";
                 }
               }

             if($_GET['acao'] === 'listarDisciplinas')
             {
                   $sql ="SELECT u.cod_disciplina AS Codigo,
                   u.descricao_disciplina AS Descricao,
                   u.periodo_disciplina AS Periodo, u.curso_disciplina AS Curso FROM disciplina u ORDER BY u.descricao_disciplina";
                   $conexao->query($sql);
                   echo"<h2 class='text-white mb-4'>LISTAGEM DE DISCIPLINAS:</h2>";
                   echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                   echo "<tr class='thead-dark'>";

                       echo "<th>Código</th>";
                       echo "<th>Descrição</th>";
                       echo "<th>Período Padrão</th>";
                       echo "<th>Curso</th>";


                   echo "</tr>";
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {

                     echo "<tr>";

                       $cod_disciplina = $tupla['Codigo'];
                       echo "<td>$cod_disciplina</td>";
                       echo "<td>$tupla[Descricao]</td>";
                       echo "<td>$tupla[Periodo]° Semestre</td>";
                       echo "<td>$tupla[Curso]</td>";

                     echo "</tr>";
                   }
                   echo "</table>";
                   }

             if($_GET['acao'] === 'buscarVinculoSala')
             {
               $cod_disciplina = $_GET['cod_disciplina'];
               $cod_sala = $_GET['cod_sala'];
               $diaSemana = $_GET['diaSemana'];
               $nome_professor = $_GET['nome'];

               $sql ="SELECT p.nome_professor AS Professor, d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala,v.dia_semana AS Dia_da_Semana, v.periodo AS Periodo, v.horario AS Horario
               FROM vinculo v, disciplina d, professor p, vinculoprofessor vp WHERE v.cod_vinculo LIKE vp.cod_vinculo AND p.SIAPE LIKE vp.SIAPE AND d.cod_disciplina LIKE v.cod_disciplina ";

               $where1 = "";
               $where2 = "";
               $where3 = "";
               $where4 = "";
               $and = "";

               if(empty($cod_disciplina) === FALSE)
               {
                 $where1 = "AND v.cod_disciplina LIKE '%$cod_disciplina%'";
               }
               if(empty($cod_sala) === FALSE)
               {
                 $where2 = "AND v.cod_sala LIKE '%$cod_sala%'";
               }
               if(empty($diaSemana) === FALSE)
               {
                 $where3 = "AND v.dia_semana LIKE '%$diaSemana%'";
               }
               if(empty($nome_professor) === FALSE)
               {
                 $where4 = "AND p.nome_professor LIKE '%$nome_professor%'";
               }

               $sql = $sql.$where1.$where2.$where3.$where4." ORDER BY v.periodo, v.horario, v.cod_sala, p.nome_professor";

               $conexao->query($sql);
               $numeroDeUsuarios = $conexao->num_rows();
               if ($numeroDeUsuarios==0) {
                   echo "<h1 class='text-white' text-align-enter>Nenhuma Aula Encontrada!</h1>";
                     header("Refresh: 3; url=indexProfessor.php");
                     exit(0);
               }else{
                 echo"<h3 class='text-white'>BUSCA:</h3>";
                 echo "<h6 class='text-white'>$numeroDeUsuarios Disciplina(s) encontrada(s)</h6>";
                 echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                   echo "<tr class='thead-dark'>";

                       echo "<th>Sala</th>";
                       echo "<th>Professor</th>";
                       echo "<th>Disciplina</th>";
                       echo "<th>Dia da Semana</th>";
                       echo "<th>Periodo </th>";
                       echo "<th>Horario</th>";


                   echo "</tr>";
                   for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                   {

                     echo "<tr>";
                       echo "<td>$tupla[Sala]</td>";
                       echo "<td>$tupla[Professor]</td>";
                       echo "<td>$tupla[Disciplina]</td>";
                       echo "<td style='text-align:center'>$tupla[Dia_da_Semana] Feira</td>";
                       echo "<td>$tupla[Periodo]</td>";
                       echo "<td>$tupla[Horario]° Tempo</td>";
                     echo "</tr>";
                   }
                   echo "</table>";
                 echo "</div>";
                 echo "</div>";
               }
               }

             if($_GET['acao'] === 'listarVinculos')
             {

               $sql ="SELECT p.nome_professor AS Professor, d.descricao_disciplina AS Disciplina, v.cod_sala AS Sala,v.dia_semana AS Dia_da_Semana, v.periodo AS Periodo, v.horario AS Horario
               FROM vinculo v, disciplina d, professor p, vinculoprofessor vp WHERE v.cod_vinculo LIKE vp.cod_vinculo AND p.SIAPE LIKE vp.SIAPE AND d.cod_disciplina LIKE v.cod_disciplina ORDER BY v.periodo, v.horario, v.cod_sala, p.nome_professor ";
                  $conexao->query($sql);
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                    echo "<tr class='thead-dark'>";

                        echo "<th>Sala</th>";
                        echo "<th>Professor</th>";
                        echo "<th>Disciplina</th>";
                        echo "<th>Dia da Semana</th>";
                        echo "<th>Periodo </th>";
                        echo "<th>Horario</th>";


                    echo "</tr>";
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {

                      echo "<tr>";
                        echo "<td>$tupla[Sala]</td>";
                        echo "<td>$tupla[Professor]</td>";
                        echo "<td>$tupla[Disciplina]</td>";
                        echo "<td style='text-align:center'>$tupla[Dia_da_Semana] Feira</td>";
                        echo "<td>$tupla[Periodo]</td>";
                        echo "<td>$tupla[Horario]° Tempo</td>";
                      echo "</tr>";
                    }
                    echo "</table>";
                   echo "</div>";
                   echo "</div>";
                   }

             if($_GET['acao'] === 'horarioSala')
             {
                 $cod_sala = $_GET['cod_sala'];
                   if(empty($cod_sala) === TRUE){
                     echo "Nenhum valor foi digitado. Tente Novamente!";
                       header("Refresh: 2; url=indexProfessor.php");
                       exit(0);
                   }

                   echo"<h3 class='text-white'>Horario da sala $cod_sala:</h3>";

                   echo "<table style='text-align: center' class='table table-light table-hover table-responsive-sm  table-responsive-md table-responsive-lg table-responsive-p table-responsive-xl'>";
                   echo "<tr class='thead-dark text_center'>";
                       echo "<th >Tempo</th>";
                       echo "<th >Segunda</th>";
                       echo "<th >Terça</th>";
                       echo "<th >Quarta</th>";
                       echo "<th >Quinta</th>";
                       echo "<th >Sexta</th>";
                   echo "</tr>";
                   echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                   echo "<th colspan= '7'>Periodo Matutino</th>";
                   echo "</tr>";

                   for ($i=1; $i <=7 ; $i++) {
                     echo "<tr>";
                     $periodo ="";
                     $horario ="";
                     $valor1="";
                     $valor2="";
                     $valor3="";
                     $valor4="";
                     $valor5="";
                     $prof1="";
                     $prof2="";
                     $prof3="";
                     $prof4="";
                     $prof5="";

                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND v.cod_sala LIKE '%$cod_sala%' AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                     $conexao->query($sql);
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {
                       if ($tupla['Horario']==$i && $tupla['Periodo']=="Matutino") {

                         if($tupla['Dia_Semana']=="Segunda") {
                           $valor1=$tupla['Disciplina'];
                           $prof1=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Terca") {
                           $valor2=$tupla['Disciplina'];
                           $prof2=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quarta") {
                           $valor3=$tupla['Disciplina'];
                           $prof3=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quinta") {
                           $valor4=$tupla['Disciplina'];
                           $prof4=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Sexta") {
                           $valor5=$tupla['Disciplina'];
                           $prof5=$tupla['Professor'];}
                           $periodo =$tupla['Periodo'];
                           $horario =$tupla['Horario'];
                       }
                     }
                     if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                     echo "<td style=';width:10%'>";echo $i."° tempo";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3;;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4;;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5;;echo "</td>";
                     echo "</tr>";}
                   }
                   echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                   echo "<th colspan= '7'>Periodo Vespertino</th>";
                   echo "</tr>";
                   for ($i=1; $i <=7 ; $i++) {
                     echo "<tr>";
                     $periodo ="";
                     $horario ="";
                     $valor1="";
                     $valor2="";
                     $valor3="";
                     $valor4="";
                     $valor5="";
                     $prof1="";
                     $prof2="";
                     $prof3="";
                     $prof4="";
                     $prof5="";

                     $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo
                     FROM vinculo v, disciplina d, professor p, vinculoprofessor vp where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND v.cod_sala LIKE '%$cod_sala%' AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                     $conexao->query($sql);
                     for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                     {
                       if ($tupla['Horario']==$i && $tupla['Periodo']=="Vespertino") {

                         if($tupla['Dia_Semana']=="Segunda") {
                           $valor1=$tupla['Disciplina'];
                           $prof1=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Terca") {
                           $valor2=$tupla['Disciplina'];
                           $prof2=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quarta") {
                           $valor3=$tupla['Disciplina'];
                           $prof3=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Quinta") {
                           $valor4=$tupla['Disciplina'];
                           $prof4=$tupla['Professor'];}

                         if($tupla['Dia_Semana']=="Sexta") {
                           $valor5=$tupla['Disciplina'];
                           $prof5=$tupla['Professor'];}
                           $periodo =$tupla['Periodo'];
                           $horario =$tupla['Horario'];
                       }
                     }
                     if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($prof1)==FALSE || empty($prof2)==FALSE || empty($prof3)==FALSE || empty($prof4)==FALSE || empty($prof5)==FALSE) {

                     echo "<td style=';width:10%'>";echo $i."° tempo";echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$prof1;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$prof2;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$prof3;;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$prof4;;echo "</td>";
                     echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$prof5;;echo "</td>";
                     echo "</tr>";}
                   }
                   echo "</tbody>";
                   echo "</table>";


                 }

             if($_GET['acao'] === 'horarioProfessor')
             {
                  $SIAPE = $_SESSION['SIAPE'];
                    if(empty($SIAPE) === TRUE){
                      echo "Nenhum valor foi digitado. Tente Novamente!";

                    }

                  $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                  FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, sala s where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND vp.SIAPE LIKE '%$SIAPE%' AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                  $conexao->query($sql);
                  $numeroDeUsuarios = $conexao->num_rows();
                  if ($numeroDeUsuarios==0) {
                    echo "<div style='text-align: center' class='jumbotron px-6 pt-4 pb-2 mt-2 bg-primary'>";
                      echo "<h4 class='text-white'>Nenhum Professor Encontrado!</h4>";
                      echo "</div>";

                  }else{
                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                    {$nome_professor=$tupla['Professor'];}
                    echo"<h3 class='text-white'>Horario do(a) professor(a) $nome_professor :</h3>";

                    echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-md table-responsive-lg table-responsive-p table-responsive-xl'>";
                    echo "<tr class='thead-dark'>";
                        echo "<th >Tempo</th>";
                        echo "<th style='text-align: center'  >Segunda</th>";
                        echo "<th style='text-align: center' >Terça</th>";
                        echo "<th style='text-align: center' >Quarta</th>";
                        echo "<th style='text-align: center' >Quinta</th>";
                        echo "<th style='text-align: center' >Sexta</th>";
                    echo "</tr>";
                    echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                    echo "<th colspan= '7'>Periodo Matutino</th>";
                    echo "</tr>";
                    for ($i=1; $i <=7 ; $i++) {

                      $periodo ="";
                      $horario ="";
                      $valor1="";
                      $valor2="";
                      $valor3="";
                      $valor4="";
                      $valor5="";
                      $sala1="";
                      $sala2="";
                      $sala3="";
                      $sala4="";
                      $sala5="";

                      $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                      FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, sala s where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND vp.SIAPE LIKE '%$SIAPE%' AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                      $conexao->query($sql);
                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                      {

                        if ($tupla['Horario']==$i && $tupla['Periodo']=="Matutino") {

                          if($tupla['Dia_Semana']=="Segunda") {
                            $valor1=$tupla['Disciplina'];
                            $sala1=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Terca") {
                            $valor2=$tupla['Disciplina'];
                            $sala2=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Quarta") {
                            $valor3=$tupla['Disciplina'];
                            $sala3=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Quinta") {
                            $valor4=$tupla['Disciplina'];
                            $sala4=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Sexta") {
                            $valor5=$tupla['Disciplina'];
                            $sala5=$tupla['Sala'];}
                            $periodo =$tupla['Periodo'];
                            $horario =$tupla['Horario'];
                        }

                      }
                      if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE) {

                        echo "<tr style='width:10%'>";
                        echo "<td>";echo $i."° tempo";echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$sala1;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$sala2;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$sala3;;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$sala4;;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$sala5;;echo "</td>";
                        echo "</tr>";
                      }

                    }
                    echo "<tr style='text-align:center; background-color:gray' class='text-white'>";
                    echo "<th colspan= '7'>Periodo Vespertino</th>";
                    echo "</tr>";
                    for ($i=1; $i <=7 ; $i++) {
                      echo "<tr>";
                      $periodo ="";
                      $horario ="";
                      $valor1="";
                      $valor2="";
                      $valor3="";
                      $valor4="";
                      $valor5="";
                      $sala1="";
                      $sala2="";
                      $sala3="";
                      $sala4="";
                      $sala5="";

                      $sql = "SELECT d.descricao_disciplina AS Disciplina, p.nome_professor AS Professor, v.horario AS Horario, v.dia_semana AS Dia_Semana, v.periodo AS Periodo, s.cod_sala AS Sala
                      FROM vinculo v, disciplina d, professor p, vinculoprofessor vp, sala s where vp.cod_vinculo LIKE v.cod_vinculo AND vp.SIAPE LIKE p.SIAPE AND vp.SIAPE LIKE '%$SIAPE%' AND v.cod_sala LIKE s.cod_sala AND v.cod_disciplina LIKE d.cod_disciplina ORDER BY v.dia_semana, v.horario,v.periodo, v.cod_disciplina";
                      $conexao->query($sql);
                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                      {

                        if ($tupla['Horario']==$i && $tupla['Periodo']=="Vespertino") {

                          if($tupla['Dia_Semana']=="Segunda") {
                            $valor1=$tupla['Disciplina'];
                            $sala1=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Terca") {
                            $valor2=$tupla['Disciplina'];
                            $sala2=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Quarta") {
                            $valor3=$tupla['Disciplina'];
                            $sala3=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Quinta") {
                            $valor4=$tupla['Disciplina'];
                            $sala4=$tupla['Sala'];}

                          if($tupla['Dia_Semana']=="Sexta") {
                            $valor5=$tupla['Disciplina'];
                            $sala5=$tupla['Sala'];}
                            $periodo =$tupla['Periodo'];
                            $horario =$tupla['Horario'];
                        }

                      }
                      if (empty($valor1)==FALSE || empty($valor2)==FALSE || empty($valor3)==FALSE || empty($valor4)==FALSE || empty($valor5)==FALSE || empty($sala1)==FALSE || empty($sala2)==FALSE || empty($sala3)==FALSE || empty($sala4)==FALSE || empty($sala5)==FALSE) {

                        echo "<tr>";
                        echo "<td style='width:10%'>";echo $i."° tempo";echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor1."</b><br>".$sala1;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor2."</b><br>".$sala2;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor3."</b><br>".$sala3;;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor4."</b><br>".$sala4;;echo "</td>";
                        echo "<td style='text-align: center;width:18%'>";echo "<b>".$valor5."</b><br>".$sala5;;echo "</td>";
                        echo "</tr>";
                      }
                    }
                    echo "</tbody>";
                    echo "</table>";

                   }
                  }

             if($_GET['acao'] === 'aviso')
             {

                  ?>
                  <?php

              $cod_turma = $_GET['cod_turma'];
              $siape = $_SESSION['SIAPE'];

              $sql = "SELECT a.nome_aluno AS Aluno, a.email_responsavel AS Email
              FROM turma t, vinculoturma vt, vinculo v, vinculoaluno va, professor p, aluno a, vinculoprofessor vp
              WHERE cod_null = 0
              AND va.RA = a.RA
              AND vt.cod_turma LIKE '%$cod_turma%'
              AND vt.cod_vinculo = va.cod_vinculo
              AND vt.cod_vinculo = vp.cod_vinculo
              AND va.cod_vinculo = v.cod_vinculo
              AND vp.SIAPE LIKE '$siape' ORDER BY a.nome_aluno";
// AND vp.SIAPE LIKE '$SIAPE'
                // $sql = $sql."ORDER BY t.cod_turma";

                $conexao->query($sql);
                $numeroDeUsuarios = $conexao->num_rows();
                if ($numeroDeUsuarios==0) {
                    echo "Nenhum Aluno Encontrado!";
                }else{
                  echo"<h3 class='text-white'>Seus Alunos:</h3>";
                  echo "<table class='table table-light table-hover table-responsive-sm  table-responsive-p table-responsive-md table-responsive-lg table-responsive-xl'>";

                  echo "<tr class='thead-dark'>";


                      echo "<th>Aluno</th>";
                      echo "<th> </th>";
                      echo "<th> </th>";


                  echo "</tr>";
                  $cont = 1;
$repe1 ="viva";
                  for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                  {
                    $repe = $tupla['Aluno'];
                    if ($repe == $tupla['Aluno'] && $cont == 1 && $repe1 != $repe) {
                      $cont++;
                      echo "<tr>";

                      ?>
                        <td> <?php echo $tupla['Aluno']; ?>

                        </td>
                        <td> <form class="" action="notificar.php" method="post">
                          <input type="hidden" name="emailton" value="<?php echo $tupla['Email'] ?>">
                          <input type="submit" value="Notificar">
                        </form>

                        </td>

                         <?php
                        $cont++;
                      echo "</tr>";

                    }else {
                      $cont = 1;
                      $repe1 = $repe;
                    }

                  }
                  echo "</table>";
                  }
                }
          }



         ?>
        </div>
      </div>
    </div>


  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
