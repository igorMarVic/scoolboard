<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>

<?php
	include_once "config.php";
	include_once "connection.php";

	session_start();
	$conexao = new Connection($host, $user, $password, $database);
		if($_SERVER['HTTP_REFERER'] === $url.'login.php')
		{
			$email = $_POST['email'];
			$senha = $_POST['senha'];
			$peril= $_POST['perfil'];

			$senha = sha1($senha);

			if( (empty($email) == TRUE) || (empty($senha) == TRUE) || (empty($peril) == TRUE) )
			{

				echo  "<div class='container mt-4'>";
          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
              echo  "<div class='row d-flex'>";
                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
                  echo  "<a class='card-link'>";
                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
                      echo  "<div class='card-body text-center'>";
                        echo  "<h4 class='card-tittle'>Você deve preencher todos os dados corretamente !</h4>";
                      echo  "</div>";
                    echo  "</div>";
                  echo  "</a>";
                echo  "</div>";
              echo  "</div>";
            echo  "</div>";
          echo  "</div>";
        echo  "</div>";

				header("Refresh: 2; url=login.php");
				exit(0);
			}else{
				$professor= "professor";
				$estudante= "estudante";
				$administrador= "administrador";

				if($_POST['perfil']==$administrador)
				{
					$sql = "SELECT * FROM administracao WHERE email_admin = '$email'";
					$conexao->query($sql);

					if($conexao->num_rows() > 0)
					{
						$sql = "SELECT id_admin, nome_admin FROM administracao WHERE email_admin = '$email' AND
								senha_admin = '$senha'";

						$conexao->query($sql);

						if($conexao->num_rows() > 0)
						{
							$tupla = $conexao->fetch_assoc();
							$id_admin = $tupla['id_admin'];
							$nome = $tupla['nome_admin'];

							$_SESSION['id_admin'] = $id_admin;
							$_SESSION['nome'] = $nome;?>
							<?php header("Refresh: 0; url='index.php'");

						}else{
							echo  "<div class='container mt-4'>";
			          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
			            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
			              echo  "<div class='row d-flex'>";
			                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
			                  echo  "<a class='card-link'>";
			                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
			                      echo  "<div class='card-body text-center'>";
			                        echo  "<h4 class='card-tittle'>Login ou Senha Incorretos !</h4>";
			                      echo  "</div>";
			                    echo  "</div>";
			                  echo  "</a>";
			                echo  "</div>";
			              echo  "</div>";
			            echo  "</div>";
			          echo  "</div>";
			        echo  "</div>";
							header("Refresh: 3; url=login.php");
							exit(0);
					  }
				 }else {
					 echo  "<div class='container mt-4'>";
 	          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
 	            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
 	              echo  "<div class='row d-flex'>";
 	                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
 	                  echo  "<a class='card-link'>";
 	                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
 	                      echo  "<div class='card-body text-center'>";
 	                        echo  "<h4 class='card-tittle'>Perfil Não Encontrado !</h4>";
 	                      echo  "</div>";
 	                    echo  "</div>";
 	                  echo  "</a>";
 	                echo  "</div>";
 	              echo  "</div>";
 	            echo  "</div>";
 	          echo  "</div>";
 	         echo  "</div>";
					header("Refresh: 2; url=login.php");
					exit(0);
				 }}

				if($_POST['perfil']==$estudante)
				{
					$sql = "SELECT * FROM aluno WHERE email_aluno = '$email'";
					$conexao->query($sql);

					if($conexao->num_rows() > 0)
					{
						$sql = "SELECT RA AS ra, nome_aluno AS Nome FROM aluno WHERE email_aluno = '$email' AND senha_aluno = '$senha'";
						$conexao->query($sql);

						if($conexao->num_rows() > 0)
						{
								$tupla = $conexao->fetch_assoc();
								$RA = $tupla['ra'];
								$nome = $tupla['Nome'];

								$_SESSION['RA_Aluno'] = $RA;
								$_SESSION['Nome'] = $nome;
								echo  "<div class='container mt-4'>";
				          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
				            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
				              echo  "<div class='row d-flex'>";
				                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
				                  echo  "<a class='card-link'>";
				                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
				                      echo  "<div class='card-body text-center'>";
				                        echo  "<h4 class='card-tittle'>$nome Seja bem vindo ao InFo IF !</h4>";
				                      echo  "</div>";
				                    echo  "</div>";
				                  echo  "</a>";
				                echo  "</div>";
				              echo  "</div>";
				            echo  "</div>";
				          echo  "</div>";
				        echo  "</div>";
								header("Refresh: 3; url=indexAluno.php");

						}else{
							echo  "<div class='container mt-4'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
									echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
										echo  "<div class='row d-flex'>";
											echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
												echo  "<a class='card-link'>";
													echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
														echo  "<div class='card-body text-center'>";
															echo  "<h4 class='card-tittle'>Login ou Senha Incorretos !</h4>";
														echo  "</div>";
													echo  "</div>";
												echo  "</a>";
											echo  "</div>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
								header("Refresh: 3; url=login.php");
								exit(0);
						}
					}else {
						echo  "<div class='container mt-4'>";
		          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
		            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
		              echo  "<div class='row d-flex'>";
		                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
		                  echo  "<a class='card-link'>";
		                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
		                      echo  "<div class='card-body text-center'>";
		                        echo  "<h4 class='card-tittle'>Perfil Não Encontrado !</h4>";
		                      echo  "</div>";
		                    echo  "</div>";
		                  echo  "</a>";
		                echo  "</div>";
		              echo  "</div>";
		            echo  "</div>";
		          echo  "</div>";
		        echo  "</div>";
						header("Refresh: 2; url=login.php");
						exit(0);
					}}

				if($_POST['perfil']==$professor)
				{
					$sql = "SELECT * FROM professor WHERE email_professor = '$email'";
					$conexao->query($sql);

					if($conexao->num_rows() > 0)
					{
						$sql = "SELECT SIAPE, nome_professor FROM professor WHERE email_professor = '$email' AND senha_professor = '$senha'";
						$conexao->query($sql);

						if($conexao->num_rows() > 0)
						{
							$tupla = $conexao->fetch_assoc();
							$siape = $tupla['SIAPE'];
							$nome = $tupla['nome_professor'];
							$_SESSION['SIAPE'] = $siape;
							$_SESSION['nome'] = $nome;
							echo  "<div class='container mt-4'>";
	  	          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
	  	            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
	  	              echo  "<div class='row d-flex'>";
	  	                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
	  	                  echo  "<a class='card-link'>";
	  	                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
	  	                      echo  "<div class='card-body text-center'>";
	  	                        echo  "<h4 class='card-tittle'>Seja Bem Vindo ao InFo !</h4>";
	  	                      echo  "</div>";
	  	                    echo  "</div>";
	  	                  echo  "</a>";
	  	                echo  "</div>";
	  	              echo  "</div>";
	  	            echo  "</div>";
	  	          echo  "</div>";
	  	         echo  "</div>";
							header("Refresh: 3; url=indexProfessor.php");
						}else{
							echo  "<div class='container mt-4'>";
	  	          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
	  	            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
	  	              echo  "<div class='row d-flex'>";
	  	                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
	  	                  echo  "<a class='card-link'>";
	  	                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
	  	                      echo  "<div class='card-body text-center'>";
	  	                        echo  "<h4 class='card-tittle'>Login ou Senha Incorretos !</h4>";
	  	                      echo  "</div>";
	  	                    echo  "</div>";
	  	                  echo  "</a>";
	  	                echo  "</div>";
	  	              echo  "</div>";
	  	            echo  "</div>";
	  	          echo  "</div>";
	  	         echo  "</div>";
							header("Refresh: 3; url=login.php");
							exit(0);
						}
					}else{
						echo  "<div class='container mt-4'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Perfil Não Encontrado !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						 echo  "</div>";
						header("Refresh: 2; url=login.php");
							exit(0);
					}
				}

			}
		}

		$urlTokenized=strtok( $_SERVER['HTTP_REFERER'],"?");

		if($_SERVER['HTTP_REFERER'] === $url.'index.php' || $urlTokenized===$url.'VincularAluno.php' || $urlTokenized===$url.'VincularSala.php' || $urlTokenized===$url.'VincularTurma.php')
		{
		$tipo = $_POST['tipo'];
			if($tipo==1)
			{
					$nome = $_POST['nome'];
					$ra = $_POST['ra'];
					$curso = $_POST['curso'];
					$periodo = $_POST['periodo'];
					$email = $_POST['email'];
					$senha = $ra;
					$senha = sha1($senha);

					if( (empty($nome) == TRUE) || (empty($ra) == TRUE) || (empty($curso) == TRUE) || (empty($periodo) == TRUE) || (empty($email) == TRUE) )
						{
							echo "<div class='container mt-4'>";
			          echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
			            echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
			              echo "<div class='row d-flex'>";
			                echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
			                  echo "<a class='card-link'>";
			                    echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
			                      echo "<div class='card-body text-center'>";
			                        echo "Você deve preencher todos campos !";
			                      echo "</div>";
			                    echo "</div>";
			                  echo "</a>";
			                echo "</div>";
			              echo "</div>";
			            echo "</div>";
			          echo "</div>";
			        echo "</div>";

							header("Refresh: 2; url=index.php");
							exit(0);

							}else{


					$sql = "INSERT INTO aluno(RA,nome_aluno, email_aluno, senha_aluno, periodo_aluno, curso_aluno) VALUES
							('$ra', '$nome', '$email', '$senha', '$periodo', '$curso')";

					$status = $conexao->query($sql);

					if($status === TRUE)
					{
						echo  "<div class='container mt-4'>";
		          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
		            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
		              echo  "<div class='row d-flex'>";
		                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
		                  echo  "<a class='card-link'>";
		                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
		                      echo  "<div class='card-body text-center'>";
		                        echo  "<h4 class='card-tittle'>Casastro Concluido Com Sucesso !</h4>";
		                      echo  "</div>";
		                    echo  "</div>";
		                  echo  "</a>";
		                echo  "</div>";
		              echo  "</div>";
		            echo  "</div>";
		          echo  "</div>";
		        echo  "</div>";
						header("Refresh: 2; url=index.php");
						exit(0);
					}else{
						echo "Erro ao Cadastrar!";
						header("Refresh: 2; url=index.php");
						exit(0);}
					}
				}

			if($tipo==2)
			{
						$nome = $_POST['nome'];
						$siape = $_POST['siape'];
						$area = $_POST['area'];
						$email = $_POST['email'];
						$senha = $siape;

						$senha = sha1($senha);

						if( (empty($nome) == TRUE) || (empty($siape) == TRUE) || (empty($area) == TRUE) || (empty($email) == TRUE) )
							{
								echo  "<div class='container mt-4'>";
									echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
										echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
											echo  "<div class='row d-flex'>";
												echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
													echo  "<a class='card-link'>";
														echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
															echo  "<div class='card-body text-center'>";
																echo  "<h4 class='card-tittle'>Você precisa preencher todos os campos !</h4>";
															echo  "</div>";
														echo  "</div>";
													echo  "</a>";
												echo  "</div>";
											echo  "</div>";
										echo  "</div>";
									echo  "</div>";
								 echo  "</div>";
								header("Refresh: 2; url=index.php");
								exit(0);
							}else{

								$sql = "INSERT INTO professor(SIAPE,nome_professor, email_professor, senha_professor, area_professor) VALUES
								('$siape', '$nome', '$email', '$senha', '$area')";

						$status = $conexao->query($sql);

						if($status === TRUE)
						{

	  	       echo  "Cadastro Concluido Com Sucesso";

							header("Refresh: 2; url=index.php");
							exit(0);
						}else{
							echo  "<div class='container mt-4'>";
	  	          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
	  	            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
	  	              echo  "<div class='row d-flex'>";
	  	                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
	  	                  echo  "<a class='card-link'>";
	  	                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
	  	                      echo  "<div class='card-body text-center'>";
	  	                        echo  "<h4 class='card-tittle'>! Houve um Erro !</h4>";
	  	                      echo  "</div>";
	  	                    echo  "</div>";
	  	                  echo  "</a>";
	  	                echo  "</div>";
	  	              echo  "</div>";
	  	            echo  "</div>";
	  	          echo  "</div>";
	  	         echo  "</div>";
							header("Refresh: 15; url=index.php");
							exit(0);
						}
					}
				}

			if($tipo==3)
			{

					$cod = $_POST['codSala'];
					$descricao = $_POST['descricao'];
					$bloco = $_POST['bloco'];


					if( (empty($cod) == TRUE) || (empty($descricao) == TRUE) || (empty($bloco) == TRUE))
						{
							echo  "<div class='container mt-4'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
									echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
										echo  "<div class='row d-flex'>";
											echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
												echo  "<a class='card-link'>";
													echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
														echo  "<div class='card-body text-center'>";
															echo  "<h4 class='card-tittle'>Você deve preencher todos os campos !</h4>";
														echo  "</div>";
													echo  "</div>";
												echo  "</a>";
											echo  "</div>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							 echo  "</div>";
							header("Refresh: 2; url=index.php");
								exit(0);
							}else{


					$sql = "INSERT INTO sala(cod_sala,descricao_sala, bloco_sala) VALUES
							('$cod', '$descricao', '$bloco')";

					$status = $conexao->query($sql);

					if($status === TRUE)
					{
						echo  "<div class='container mt-4'>";
						 echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							 echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								 echo  "<div class='row d-flex'>";
									 echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										 echo  "<a class='card-link'>";
											 echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												 echo  "<div class='card-body text-center'>";
													 echo  "<h4 class='card-tittle'>Cadastro Concluido com Sucesso !</h4>";
												 echo  "</div>";
											 echo  "</div>";
										 echo  "</a>";
									 echo  "</div>";
								 echo  "</div>";
							 echo  "</div>";
						 echo  "</div>";
						echo  "</div>";
						header("Refresh: 2; url=index.php");
						exit(0);
					}else{
						echo  "<div class='container mt-4'>";
						 echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							 echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								 echo  "<div class='row d-flex'>";
									 echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										 echo  "<a class='card-link'>";
											 echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												 echo  "<div class='card-body text-center'>";
													 echo  "<h4 class='card-tittle'>Houve um erro !</h4>";
												 echo  "</div>";
											 echo  "</div>";
										 echo  "</a>";
									 echo  "</div>";
								 echo  "</div>";
							 echo  "</div>";
						 echo  "</div>";
						echo  "</div>";
						header("Refresh: 2; url=index.php");
						exit(0);}
					}
				}

			if($tipo==4)
			{
				$codDisciplina = $_POST['codDisciplina'];
				$descricaoDisciplina = $_POST['descricaoDisciplina'];
				$periodoDisciplina = $_POST['periodoDisciplina'];
				$cursoDisciplina = $_POST['cursoDisciplina'];


				if( (empty($codDisciplina) == TRUE) || (empty($descricaoDisciplina) == TRUE) || (empty($periodoDisciplina) == TRUE) || (empty($cursoDisciplina) == TRUE) )
					{
						echo  "<div class='container mt-4'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Você deve preencher todos os campos !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						 echo  "</div>";
						header("Refresh: 2; url=index.php");
							exit(0);
						}else{


				$sql = "INSERT INTO disciplina(cod_disciplina,descricao_disciplina, periodo_disciplina, curso_disciplina) VALUES
						('$codDisciplina', '$descricaoDisciplina', '$periodoDisciplina', '$cursoDisciplina')";

				$status = $conexao->query($sql);

				if($status === TRUE)
				{
					echo  "<div class='container mt-4'>";
					 echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						 echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							 echo  "<div class='row d-flex'>";
								 echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
									 echo  "<a class='card-link'>";
										 echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											 echo  "<div class='card-body text-center'>";
												 echo  "<h4 class='card-tittle'>Cadastro Concluido com Sucesso !</h4>";
											 echo  "</div>";
										 echo  "</div>";
									 echo  "</a>";
								 echo  "</div>";
							 echo  "</div>";
						 echo  "</div>";
					 echo  "</div>";
					echo  "</div>";
					header("Refresh: 2; url=index.php");
					exit(0);
				}else{
					echo  "<div class='container mt-4'>";
					 echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						 echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							 echo  "<div class='row d-flex'>";
								 echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
									 echo  "<a class='card-link'>";
										 echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											 echo  "<div class='card-body text-center'>";
												 echo  "<h4 class='card-tittle'>Houve um Erro!</h4>";
											 echo  "</div>";
										 echo  "</div>";
									 echo  "</a>";
								 echo  "</div>";
							 echo  "</div>";
						 echo  "</div>";
					 echo  "</div>";
					echo  "</div>";
					header("Refresh: 2; url=index.php");
					exit(0);}
				}
			}

			if($tipo==5)
			{
				$semestre=$_POST['semestre'];
				$curso=$_POST['curso'];
				$codDisciplina = $_POST['cod_disciplina'];
				$codSala = $_POST['cod_sala'];
				$diaSemana = $_POST['diaSemana'];
				$periodo  = $_POST['periodo'];
				$horario  = $_POST['horario'];


				if( (empty($codDisciplina) == TRUE) || (empty($codSala) == TRUE) || (empty($diaSemana) == TRUE) || (empty($periodo) == TRUE)|| (empty($horario) == TRUE) )
					{
						echo  "<div class='container mt-4'>";
						 echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							 echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								 echo  "<div class='row d-flex'>";
									 echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										 echo  "<a class='card-link'>";
											 echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												 echo  "<div class='card-body text-center'>";
													 echo  "<h4 class='card-tittle'>! Você deve preencher todos os campos !</h4>";
													 header("Refresh: 2; url=VincularSala.php?semestre=$semestre&curso=$curso");
														exit(0);
												 echo  "</div>";
											 echo  "</div>";
										 echo  "</a>";
									 echo  "</div>";
								 echo  "</div>";
							 echo  "</div>";
						 echo  "</div>";
						echo  "</div>";
						}else{



						$sql = "INSERT INTO vinculo(cod_disciplina,cod_sala, dia_semana, periodo, horario) VALUES
						('$codDisciplina', '$codSala', '$diaSemana', '$periodo', '$horario')";

						$status = $conexao->query($sql);

				if($status === TRUE)
				{
					echo  "Cadastro Concluido com Sucesso";
					header("Refresh: 1; url=VincularSala.php?semestre=$semestre&curso=$curso");
					exit(0);
				}else{
					echo  "<div class='container mt-4'>";
					 echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						 echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							 echo  "<div class='row d-flex'>";
								 echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
									 echo  "<a class='card-link'>";
										 echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											 echo  "<div class='card-body text-center'>";
												 echo  "<h4 class='card-tittle'>! Houve um Erro !</h4>";
											 echo  "</div>";
										 echo  "</div>";
									 echo  "</a>";
								 echo  "</div>";
							 echo  "</div>";
						 echo  "</div>";
					 echo  "</div>";
					echo  "</div>";
					header("Refresh: 2; url=index.php");
				exit(0);}}}

			if($tipo==6)
			{
				$siape = $_POST['SIAPE'];


				if( (empty($siape) == TRUE) || (empty($_POST['vinculo']) == TRUE) )
					{
						echo  "<div class='container mt-4'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Você deve preencher todos os campos !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						 echo  "</div>";
						header("Refresh: 2; url=index.php");
							exit(0);
						}else{

							foreach ($_POST['vinculo'] as $vinculo) {
								$sql = "INSERT INTO vinculoprofessor(cod_vinculo,SIAPE) VALUES
										('$vinculo', '$siape')";
										$status = $conexao->query($sql);}
						}

				if($status === False)
				{
					echo  "<h4 class='card-tittle'>Houve um Erro !</h4>";
					header("Refresh: 2; url=index.php");
					exit(0);

				}else{
					echo  "<h4 class='card-tittle'>Vinculo Cadastrado com Sucesso !</h4>";
					header("Refresh: 2; url=index.php");
					exit(0);}
				}

			if($tipo==7)
			{
				$ra = $_POST['RA'];
				$v = $_POST['vinculo'];
				$semestre=$_POST['semestre'];
				$curso=$_POST['curso'];


				if( (empty($ra) == TRUE) || (empty($v) == TRUE) )
					{
						echo  "<div class='container mt-4'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Você deve preencher todos os campos !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						 echo  "</div>";
						header("Refresh: 2; url=VincularAluno.php?semestre=$semestre&curso=$curso");
							exit(0);
						}else{
							foreach ($_POST['vinculo'] as $vinculo) {
								$sql = "INSERT INTO vinculoaluno(cod_vinculo,RA) VALUES
										('$vinculo', '$ra')";
										$status = $conexao->query($sql);

							}
					}

				if($status === TRUE)
				{
					echo  "<div class='container mt-4'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								echo  "<div class='row d-flex'>";
									echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										echo  "<a class='card-link'>";
											echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												echo  "<div class='card-body text-center'>";
													echo  "<h4 class='card-tittle'>Cadastro Concluido com Sucesso !</h4>";
												echo  "</div>";
											echo  "</div>";
										echo  "</a>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
					header("Refresh: 2; url=VincularAluno.php?semestre=$semestre&curso=$curso");
					exit(0);
				}else{
					echo  "<div class='container mt-4'>";
						echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								echo  "<div class='row d-flex'>";
									echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										echo  "<a class='card-link'>";
											echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												echo  "<div class='card-body text-center'>";
													echo  "<h4 class='card-tittle'>Houve um Erro !</h4>";
												echo  "</div>";
											echo  "</div>";
										echo  "</a>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						echo  "</div>";
					 echo  "</div>";
					header("Refresh: 2; url=index.php");
					exit(0);}
				}

			if($tipo==8)
			{
					$cod_turma = $_POST['cod_turma'];
					$turno_turma = $_POST['turno_turma'];
					$curso_turma=$_POST['curso_turma'];
					$periodo_turma=$_POST['periodo_turma'];


					if( (empty($cod_turma) == TRUE) || (empty($turno_turma) == TRUE) || (empty($curso_turma) == TRUE) || (empty($periodo_turma) == TRUE) )
						{
							echo  "<div class='container mt-4'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
									echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
										echo  "<div class='row d-flex'>";
											echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
												echo  "<a class='card-link'>";
													echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
														echo  "<div class='card-body text-center'>";
															echo  "<h4 class='card-tittle'>Você deve preencher todos os campos !</h4>";
														echo  "</div>";
													echo  "</div>";
												echo  "</a>";
											echo  "</div>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							 echo  "</div>";
							header("Refresh: 2; url=index.php");
								exit(0);
							}else{
									$sql = "INSERT INTO turma(cod_turma,curso_turma,periodo_turma,turno_turma) VALUES
											('$cod_turma', '$curso_turma','$periodo_turma','$turno_turma')";
											$status = $conexao->query($sql);



					if($status === TRUE)
					{
						echo  "<div class='container mt-4'>";
						echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Cadastro Concluido com Sucesso !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						echo  "</div>";
						header("Refresh: 2; url=index.php");
						exit(0);
					}else{
						echo  "<div class='container mt-4'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Houve um Erro !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						 echo  "</div>";
						header("Refresh: 2; url=index.php");
						exit(0);}}
			}

			if($tipo==9)
			{
				$cod_turma = $_POST['cod_turma'];
				$v = $_POST['vinculo'];
				$semestre=$_POST['semestre'];
				$curso=$_POST['curso'];


				if( (empty($cod_turma) == TRUE) || (empty($v) == TRUE) )
					{
						echo  "<div class='container mt-4'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
								echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
									echo  "<div class='row d-flex'>";
										echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
											echo  "<a class='card-link'>";
												echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
													echo  "<div class='card-body text-center'>";
														echo  "<h4 class='card-tittle'>Você deve preencher todos os campos !</h4>";
													echo  "</div>";
												echo  "</div>";
											echo  "</a>";
										echo  "</div>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						 echo  "</div>";
						header("Refresh: 2; url=VincularTurma.php?semestre=$semestre&curso=$curso");
							exit(0);
						}else{
							foreach ($_POST['vinculo'] as $vinculo) {
								$sql = "INSERT INTO vinculoturma(cod_turma,cod_vinculo) VALUES
										('$cod_turma','$vinculo')";
										$status = $conexao->query($sql);

							}
					}

				if($status === TRUE)
				{
					echo  "<div class='container mt-4'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								echo  "<div class='row d-flex'>";
									echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										echo  "<a class='card-link'>";
											echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												echo  "<div class='card-body text-center'>";
													echo  "<h4 class='card-tittle'>Cadastro Concluido com Sucesso !</h4>";
												echo  "</div>";
											echo  "</div>";
										echo  "</a>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
					header("Refresh: 2; url=VincularTurma.php?semestre=$semestre&curso=$curso");
					exit(0);
				}else{
					echo  "<div class='container mt-4'>";
						echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
							echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
								echo  "<div class='row d-flex'>";
									echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
										echo  "<a class='card-link'>";
											echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
												echo  "<div class='card-body text-center'>";
													echo  "<h4 class='card-tittle'>Houve um Erro !</h4>";
												echo  "</div>";
											echo  "</div>";
										echo  "</a>";
									echo  "</div>";
								echo  "</div>";
							echo  "</div>";
						echo  "</div>";
					 echo  "</div>";
					header("Refresh: 2; url=index.php");
					exit(0);}
				}

			if($tipo==10)
			{
					$nome = $_POST['nome_admin'];
					$email = $_POST['email_admin'];
					$senha = $_POST['senha_admin'];
					$csenha = $_POST['csenha_admin'];
					if ($senha != $csenha) {
						echo "Senhas Não Conferem!";
						header("Refresh: 2; url=index.php");
						exit(0);
					}else {
						$senha = sha1($senha);
					}


					if( (empty($nome) == TRUE) || (empty($email) == TRUE) || (empty($senha) == TRUE) || (empty($csenha) == TRUE))
						{
							echo "<div class='container mt-4'>";
			          echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
			            echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
			              echo "<div class='row d-flex'>";
			                echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
			                  echo "<a class='card-link'>";
			                    echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
			                      echo "<div class='card-body text-center'>";
			                        echo "Você deve preencher todos campos !";
			                      echo "</div>";
			                    echo "</div>";
			                  echo "</a>";
			                echo "</div>";
			              echo "</div>";
			            echo "</div>";
			          echo "</div>";
			        echo "</div>";

							header("Refresh: 2; url=index.php");
							exit(0);

							}else{


					$sql = "INSERT INTO administracao(nome_admin,email_admin, senha_admin) VALUES
							('$nome', '$email', '$senha')";

					$status = $conexao->query($sql);

					if($status === TRUE)
					{
						echo  "<div class='container mt-4'>";
		          echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
		            echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
		              echo  "<div class='row d-flex'>";
		                echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
		                  echo  "<a class='card-link'>";
		                    echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
		                      echo  "<div class='card-body text-center'>";
		                        echo  "<h4 class='card-tittle'>Casastro Concluido Com Sucesso !</h4>";
		                      echo  "</div>";
		                    echo  "</div>";
		                  echo  "</a>";
		                echo  "</div>";
		              echo  "</div>";
		            echo  "</div>";
		          echo  "</div>";
		        echo  "</div>";
						header("Refresh: 2; url=index.php");
						exit(0);
					}else{
						echo "Erro ao Cadastrar!";
						header("Refresh: 2; url=index.php");
						exit(0);}
					}
				}

		}

if(isset($_GET['acao']))
{
	if($_GET['acao'] == 'editarAluno')
	{
		$id=$_GET['RA'];
		$nome = $_POST['nome'];
		$ra = $_POST['ra'];
		$curso = $_POST['curso'];
		$periodo = $_POST['periodo'];
		$email = $_POST['email'];
		$senha = $ra;
		$senha = sha1($senha);

		if( (empty($nome) == TRUE) || (empty($ra) == TRUE) || (empty($curso) == TRUE) || (empty($periodo) == TRUE) || (empty($email) == TRUE) )
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `aluno` SET RA='$ra', nome_aluno='$nome',email_aluno='$email', senha_aluno='$senha',periodo_aluno='$periodo',curso_aluno='$curso' WHERE RA = '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 10; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirAluno')
	{
		$id=$_GET['RA'];

		$sql = "DELETE FROM `aluno` WHERE RA = '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Deletar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'editarSala')
	{
		$id=$_GET['CodSala'];
		$codSala = $_POST['codSala'];
		$descricaoSala= $_POST['descricao'];
		$blocoSala= $_POST['bloco'];
		if( (empty($codSala) == TRUE) || (empty($descricaoSala) == TRUE) || (empty($blocoSala) == TRUE) )
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `sala` SET cod_sala='$codSala', descricao_sala='$descricaoSala',bloco_sala='$blocoSala' WHERE cod_sala= '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirSala')
	{
		$id=$_GET['CodSala'];

		$sql = "DELETE FROM `sala` WHERE cod_sala= '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'editarProfessor')
	{
		$id=$_GET['SIAPE'];
		$nome = $_POST['nome'];
		$siape = $_POST['siape'];
		$email = $_POST['email'];
		$area = $_POST['area'];

		$senha = $siape;
		$senha = sha1($senha);

		if( (empty($nome) == TRUE) || (empty($siape) == TRUE) || (empty($email) == TRUE) || (empty($area) == TRUE))
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `professor` SET SIAPE='$siape', nome_professor='$nome',email_professor='$email', senha_professor='$senha',area_professor='$area' WHERE SIAPE = '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 10; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirProfessor')
	{
		$id=$_GET['SIAPE'];

		$sql = "DELETE FROM `professor` WHERE SIAPE = '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 10; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'editarDisciplina')
	{
		$id=$_GET['codDisciplina'];
		$codDisciplina = $_POST['codDisciplina'];
		$descricaoDisciplina= $_POST['descricaoDisciplina'];
		$periodoDisciplina=$_POST['periodoDisciplina'];
		$cursoDisciplina = $_POST['cursoDisciplina'];
		if( (empty($codDisciplina) == TRUE) || (empty($descricaoDisciplina) == TRUE) || (empty($periodoDisciplina) == TRUE) || (empty($cursoDisciplina) == TRUE) )
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `disciplina` SET cod_disciplina='$codDisciplina', descricao_disciplina='$descricaoDisciplina',curso_disciplina='$cursoDisciplina',periodo_disciplina='$periodoDisciplina' WHERE cod_disciplina= '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirDisciplina')
	{
		$id=$_GET['codDisciplina'];

		$sql = "DELETE FROM `disciplina` WHERE cod_disciplina= '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'editarTurma')
	{
		$id=$_GET['CodTurma'];
		$turma = $_POST['cod_turma'];
		$curso= $_POST['curso_turma'];
		$periodo=$_POST['periodo_turma'];
		$turno = $_POST['turno_turma'];
		if( (empty($turma) == TRUE) || (empty($curso) == TRUE) || (empty($periodo) == TRUE) || (empty($turno) == TRUE) )
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `turma` SET cod_turma='$turma', curso_turma='$curso',periodo_turma='$periodo',turno_turma='$turno' WHERE cod_turma=$id";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirTurma')
	{
		$id=$_GET['CodTurma'];

		$sql = "DELETE FROM `turma` WHERE cod_turma=$id";
		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
	}

	if($_GET['acao'] == 'editarVinculoSala')
	{
		$id=$_GET['codVinculo'];
		$codDisciplina = $_POST['cod_disciplina'];
		$codSala = $_POST['cod_sala'];
		$diaSemana = $_POST['diaSemana'];
		$periodo  = $_POST['periodo'];
		$horario  = $_POST['horario'];
		if( (empty($codDisciplina) == TRUE) || (empty($codSala) == TRUE) || (empty($diaSemana) == TRUE) || (empty($periodo) == TRUE) || (empty($horario) == TRUE) )
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `vinculo` SET cod_disciplina='$codDisciplina', cod_sala='$codSala',dia_semana='$diaSemana', periodo='$periodo', horario='$horario' WHERE cod_vinculo= '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirVinculoSala')
	{
		$id=$_GET['codVinculo'];

		$sql = "DELETE FROM `vinculo` WHERE cod_vinculo= '$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'editarVinculoAluno')
	{
		$id=$_GET['codVinculo'];
		$vinculoDisciplina = $_POST['vinculo'];
		$ra = $_POST['RA'];

		if( (empty($vinculoDisciplina) == TRUE) || (empty($ra) == TRUE) )
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{
						$sql = "UPDATE `vinculoaluno` SET cod_vinculo='$vinculoDisciplina', RA='$ra' WHERE cod_vinculo_aluno='$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirVinculoAluno')
	{
		$id=$_GET['codVinculo'];

		$sql = "DELETE FROM `vinculoaluno` WHERE cod_vinculo_aluno='$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'excluirVinculoProfessor')
	{
		$id=$_GET['codVinculo'];

		$sql = "DELETE FROM `vinculoprofessor` WHERE cod_vinculo_professor='$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'editarVinculoTurma')
	{
		$id=$_GET['codVinculoTurma'];
		$vinculo = $_POST['vinculo'];

		if( (empty($vinculo) == TRUE))
			{
				echo "<div class='container mt-4'>";
					echo "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
						echo "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
							echo "<div class='row d-flex'>";
								echo "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4'>";
									echo "<a class='card-link'>";
										echo "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
											echo "<div class='card-body text-center'>";
												echo "Você deve preencher todos campos !";
											echo "</div>";
										echo "</div>";
									echo "</a>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

				header("Refresh: 2; url=index.php");
				exit(0);

				}else{

						$sql = "UPDATE `vinculoturma` SET cod_vinculo='$vinculo' WHERE cod_vinculo_turma=$id";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Atualização Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Cadastrar!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	}

	if($_GET['acao'] == 'excluirVinculoTurma')
	{
		$id=$_GET['codVinculoTurma'];

		$sql = "DELETE FROM `vinculoturma` WHERE cod_vinculo_turma='$id'";

		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
		}

	if($_GET['acao'] == 'excluirAdmin')
	{
		$id=$_GET['CodAdmin'];

		$sql = "DELETE FROM `administracao` WHERE id_admin=$id";
		$status = $conexao->query($sql);

		if($status === TRUE)
		{
			echo  "<div class='container mt-4'>";
				echo  "<div class='jumbotron px-6 pt-4 pb-2 mt-2 bg-dark'>";
					echo  "<div class='jumbotron px-6 pt-4 pb-0 mt-2 bg-primary'>";
						echo  "<div class='row d-flex'>";
							echo  "<div class='col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 ''>";
								echo  "<a class='card-link'>";
									echo  "<div class='card col-sm-12 col-p-12 col-lg-12 col-md-12 mb-4 py-4'>";
										echo  "<div class='card-body text-center'>";
											echo  "<h4 class='card-tittle'>Remoção Concluida Com Sucesso !</h4>";
										echo  "</div>";
									echo  "</div>";
								echo  "</a>";
							echo  "</div>";
						echo  "</div>";
					echo  "</div>";
				echo  "</div>";
			echo  "</div>";
			header("Refresh: 2; url=index.php");
			exit(0);
		}else{
			echo "Erro ao Remover!";
			header("Refresh: 2; url=index.php");
			exit(0);}
	}

}


?>

</body>
</html>
