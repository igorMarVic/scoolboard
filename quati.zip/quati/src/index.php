<!doctype html>
<html lang="pt-br">
  <head>


    <script>
       function Mudarestado(el) {
        var display = document.getElementById(el).style.display;

          if(display == "none"){
            document.getElementById("DivAluno").style.display = 'none';
            document.getElementById("DivProfessor").style.display = 'none';
            document.getElementById("DivSala").style.display = 'none';
            document.getElementById("DivDisciplina").style.display = 'none';
            document.getElementById("DivTurma").style.display = 'none';
            document.getElementById("DivVinculoSD").style.display = 'none';
            document.getElementById("DivDisciplinaProfessor").style.display = 'none';
            document.getElementById("DivDisciplinaAluno").style.display = 'none';
            document.getElementById("DivHorarioSala").style.display = 'none';
            document.getElementById("DivHorarioProfessor").style.display = 'none';
            document.getElementById("DivHorarioAluno").style.display = 'none';
            document.getElementById("DivDisciplinaTurma").style.display = 'none';
            document.getElementById("DivHorarioTurma").style.display = 'none';
            document.getElementById("DivAdmin").style.display = 'none';


            document.getElementById(el).style.display = 'block';


         }else{
           document.getElementById(el).style.display = 'none';
         }
       }

     </script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="manifest" href="/manifest.json">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#1B7A0C">

    <link rel="apple-touch-icon" sizes="57x57" href="/images/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/images/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/images/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/images/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/images/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/images/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/images/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/images/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-icon-180x180.png">
    <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="/images/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="192x192"  href="images/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="images/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">

    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="InFo">
    <link rel="apple-touch-icon" href="/images/icons/icon-152x152.png">
    <meta name="msapplication-TileImage" content="/images/icons/icon-144x144.png">
    <meta name="msapplication-TileColor" content="#1B7A0C">
  </head>

  <body>
      <?php
		  session_start();
		  if(isset($_SESSION['id_admin'])===FALSE){
        header("Refresh: 0; url='login.php'");
		    exit(0);
		  }
		?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <h1 class="text-white mb-4 "><b>Seção Administrativa</b></h1>

          <div class="jumbotron px-6 pt-4 pb-0 mt-2 bg-primary" id="Cadastros">
            <h3 class="text-white">Cadastros:</h3>
            <div class="row d-flex">

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4 ">
                      <a href="#aluno" onclick="Mudarestado('DivAluno')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Alunos</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivAluno" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-cadastrar-tab" data-toggle="tab" href="#nav-cadastrarAluno" role="tab" aria-controls="nav-cadastrar-aluno" aria-selected="true">Cadastrar</a>
                            <a class="nav-item nav-link text-white" id="nav-buscar-tab" data-toggle="tab" href="#nav-buscarAluno" role="tab" aria-controls="nav-buscar-aluno" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarAluno" role="tab" aria-controls="nav-listar-aluno" aria-selected="false">Listar</a></a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-cadastrarAluno" role="tabpanel" aria-labelledby="nav-cadastrar-tab">
                            <form action="processa.php" method="POST">
                              <div class="form-row">
                                <div class="form-group col-md-12">
                                  <label for="nome">Nome Completo:</label>
                                  <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome Completo">
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="email">Email Institucional:</label>
                                  <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                                </div>
                                <div class="form-group col-lg-4 col-md-6">
                                  <label for="ra">RA:</label>
                                  <input type="number" class="form-control" name="ra" id="ra" placeholder="R. Acadêmico">
                                </div>
                                <div class="form-group col-lg-4 col-md-6">
                                  <label for="curso" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="curso" class="form-control" id="curso">
                                      <option value="">Selecione:</option>
                                      <option value="eletrotecnica">Eletrotécnica</option>
                                      <option value="informatica">Informática</option>
                                      <option value="mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-lg-4 col-md-6">
                                  <label for="periodo" class="texto">Período Regular:</label>
                                  <div class="input select">
                                    <select name="periodo" class="form-control" id="periodo">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <input type="hidden" name="tipo" value="1">
                              <button type="submit" class="btn btn-primary btn-outline-light">Cadastrar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-buscarAluno" role="tabpanel" aria-labelledby="nav-buscar-tab">
                            <form action="ResultadosAdm.php" method="get">
                              <div class="form-row">
                                <div class="form-group col-md-12">
                                  <input type="hidden" name="acao" value="buscarAluno">
                                  <label for="nome" class="text-white">Nome:</label>
                      				    <input type="text" class="form-control" name="nome" id="nome">
                      				  </div>
                                <div class="form-group col-md-12">
                                  <label for="ra" class="text-white">RA: </label>
                      				    <input type="number" class="form-control" name="ra" id="ra">
                      				 </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                      			</form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarAluno" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white mt-2">Listagem de Alunos:</h5><a href="ResultadosAdm.php?acao=listarAlunos"><button type="submit" class="btn btn-primary btn-outline-light mt-3">Listar Todos</button></a>
                          </div>
                        </div>
                      </div>
                    </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4 " id="professor">
                      <a href="#professor" onclick="Mudarestado('DivProfessor')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Professores</h4>
                          </div>
                        </div>
                      </a>

                      <div id="DivProfessor" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-cadastrar-professor" role="tab" aria-controls="nav-home" aria-selected="true">Cadastrar</a>
                            <a class="nav-item nav-link text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-buscar-professor" role="tab" aria-controls="nav-profile" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarProfessor" role="tab" aria-controls="nav-listar-professor" aria-selected="false">Listar</a></a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-cadastrar-professor" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="processa.php" method="POST" name="f1" onsubmit="return verificaUsuario()">
                              <div class="form-row">
                                <div class="form-group col-md-12">
                                  <label for="inputName">Nome Completo:</label>
                                  <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome Completo">
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="inputEmail4">Email Institucional:</label>
                                  <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                                </div>
                                <div class="form-group col-md-4">
                                  <label for="inputCurso">SIAPE:</label>
                                  <input type="number" class="form-control" id="siape" name="siape" placeholder="SIAPE">
                                </div>
                                <div class="form-group col-md-8">
                                  <label for="inputCurso">Area de Docência:</label>
                                  <input type="text" class="form-control" id="area" name="area" placeholder="Area de Docência">
                                </div>
                              </div>
                              <input type="hidden" name="tipo" value="2">
                              <button type="submit" class="btn btn-primary btn-outline-light">Cadastrar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-buscar-professor" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="ResultadosAdm.php" method="get">
                              <div class="form-row">
                                <div class="form-group col-md-12">
                                  <input type="hidden" name="acao" value="buscarProfesor">
                                  <label for="nome" class="text-white">Nome:</label>
                                  <input type="text" class="form-control" name="nome" id="nome">
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="siape" class="text-white">SIAPE: </label>
                                  <input type="number" class="form-control" name="siape" id="siape">
                               </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button></a>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarProfessor" role="tabpanel" aria-labelledby="nav-listar-tab">
                              <h5 class="text-white mt-2">Listagem de Professores:</h5>
                              <a href="ResultadosAdm.php?acao=listarProfessores"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todos</button></a>

                          </div>
                        </div>
                      </div>
                    </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4 " id="sala">
                      <a href="#sala" onclick="Mudarestado('DivSala')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Salas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivSala" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-cadastrar-sala" role="tab" aria-controls="nav-home" aria-selected="true">Cadastrar</a>
                            <a class="nav-item nav-link text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-buscar-sala" role="tab" aria-controls="nav-profile" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarSala" role="tab" aria-controls="nav-listar-sala" aria-selected="false">Listar</a></a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-cadastrar-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="processa.php" method="POST">
                              <div class="form-row">
                                <div class="form-group col-md-4 mt-3">
                                  <label for="inputName">Codigo:</label>
                                  <input type="text" class="form-control" id="codSala" name="codSala" placeholder="Ex.: B201">
                                </div>
                                <div class="form-group col-md-8 mt-3">
                                  <label for="bloco" class="text-white">Bloco: </label>
                                  <div class="input select">
                                    <select name="bloco" class="form-control" id="bloco">
                                      <option value="">Selecione:</option>
                                      <option value="A">Bloco A</option>
                                      <option value="B">Bloco B</option>
                                      <option value="C">Bloco C</option>
                                      <option value="D">Bloco D</option>
                                      <option value="E">Bloco E</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-12 mt-3">
                                  <label for="imputDescricao" class="texto">Descrição:</label>
                                  <div class="input select">
                                    <select name="descricao" class="form-control" id="descricao">
                                      <option value="sala">Sala de Aula</option>
                            					<option value="sala">Sala dos Professores</option>
                            					<option value="labInfo">Laboratorio de Informatica</option>
                            	        <option value="labMec">Laboratorio de Mecânica</option>
                            					<option value="labEle">Laboratorio de Elerotecnica</option>
                            					<option value="labQui">Laboratorio de Quimica</option>
                            					<option value="labFis">Laboratorio de Fisica</option>
                            					<option value="coord">Coordenação de Curso</option>
                            					<option value="diren">Direcao de Ensino</option>
                            					<option value="estagio">Setor de estagio</option>
                            					<option value="cerel">CEREL</option>
                            					<option value="nuged">NUGED</option>
                            					<option value="biblioteca">Biblioteca</option>
                            					<option value="cantina">Cantina</option>
                            					<option value="setor">Outro Setor</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <input type="hidden" name="tipo" value="3">
                              <button type="submit" class="btn btn-primary btn-outline-light">Cadastrar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-buscar-sala" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="ResultadosAdm.php" method="get">
                              <div class="form-row">
                                <input type="hidden" name="acao" value="buscarSala">
                                <div class="form-group col-md-12 text-white">
                                  <label for="nome">Código da Sala:</label>
                                  <div class="input select">
                                    <select name="cod_sala" class="form-control" id="cod_sala">
                                      <option value="">Selecione:</option>
                                        <?php
                                        include_once "config.php";
                                        include_once "connection.php";



                                        $conexao = new Connection($host, $user, $password, $database);

                                        $sql ="SELECT cod_sala FROM sala ORDER BY cod_sala";
                                        $conexao->query($sql);
                                        for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                        {
                                          echo"<option value='$tupla[cod_sala]'> $tupla[cod_sala]</option>";
                                        }
                                        ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="bloco" class="text-white">Bloco: </label>
                                  <div class="input select">
                                    <select name="bloco" class="form-control" id="bloco">
                                      <option value="">Selecione:</option>
                                      <option value="a">Bloco A</option>
                                      <option value="b">Bloco B</option>
                                      <option value="c">Bloco C</option>
                                      <option value="d">Bloco D</option>
                                      <option value="e">Bloco E</option>
                                    </select>
                                  </div>
                               </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarSala" role="tabpanel" aria-labelledby="nav-listar-tab">
                              <h5 class="text-white mt-2">Listagem de Salas:</h5><a href="ResultadosAdm.php?acao=listarSalas"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>
                        </div>
                      </div>
                    </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4" id="disciplina">
                      <a href="#disciplina" onclick="Mudarestado('DivDisciplina')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Disciplinas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivDisciplina" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-cadastrar-disciplina" role="tab" aria-controls="nav-home" aria-selected="true">Cadastrar</a>
                            <a class="nav-item nav-link text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-buscar-disciplina" role="tab" aria-controls="nav-profile" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarDisciplina" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Listar</a></a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-cadastrar-disciplina" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="processa.php" method="POST">
                              <div class="form-row">
                                <input type="hidden" name="tipo" value="4">
                                <div class="form-group col-md-12">
                                  <label for="nome">Código:</label>
                        				  <input type="number" class="form-control" name="codDisciplina" id="codDisciplina" placeholder="Código da Disciplina">
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="nome">Descrição:</label>
                        				  <input type="text" class="form-control" name="descricaoDisciplina" id="descricaoDisciplina" placeholder="Nome da Disciplina">
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="periodo" class="texto">Período Padão:</label>
                                  <div class="input select">
                                    <select name="periodoDisciplina" class="form-control" id="periodoDisciplina">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-12">
                                  <label for="curso" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="cursoDisciplina" class="form-control" id="cursoDisciplina">
                                      <option value="">Selecione:</option>
                                      <option value="comum">Comum a todos</option>
                                      <option value="eletrotecnica">Eletrotécnica</option>
                                      <option value="informatica">Informática</option>
                                      <option value="mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <button type="submit" class="btn btn-primary btn-outline-light">Cadastrar</button>
                      			</form>
                          </div>
                          <div class="tab-pane fade" id="nav-buscar-disciplina" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="ResultadosAdm.php" method="get">
                              <input type="hidden" name="acao" value="buscarDisciplina">
                              <div class="form-row">
                                <div class="form-group col-md-12 text-white">
                                  <label for="periodo" class="texto">Período Padão:</label>
                                  <div class="input select">
                                    <select name="periodoDisciplina" class="form-control" id="periodoDisciplina">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-md-12 text-white">
                                  <label for="descricaoDisciplina" class="text-white">Descrição: </label>
                                  <input type="text" class="form-control" name="descricaoDisciplina" id="descricaoDisciplina" placeholder="Nome da Disciplina">
                                </div>
                                <div class="form-group col-md-12 text-white">
                                  <label for="curso" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="cursoDisciplina" class="form-control" id="cursoDisciplina">
                                      <option value="">Selecione:</option>
                                      <option value="comum">Comum a todos</option>
                                      <option value="eletrotecnica">Eletrotécnica</option>
                                      <option value="informatica">Informática</option>
                                      <option value="mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                             </div>

                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button></a>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarDisciplina" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white mt-2">Listagem de Disciplinas:</h5><a href="ResultadosAdm.php?acao=listarDisciplinas"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>
                        </div>
                      </div>

              </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4" id="turma">
                      <a href="#turma" onclick="Mudarestado('DivTurma')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Turmas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivTurma" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-cadastrar-tab" data-toggle="tab" href="#nav-cadastrarTurma" role="tab" aria-controls="nav-cadastrar-aluno" aria-selected="true">Cadastrar</a>
                            <a class="nav-item nav-link text-white" id="nav-buscar-tab" data-toggle="tab" href="#nav-buscarTurma" role="tab" aria-controls="nav-buscar-aluno" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarTurma" role="tab" aria-controls="nav-listar-aluno" aria-selected="false">Listar</a></a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-cadastrarTurma" role="tabpanel" aria-labelledby="nav-cadastrar-tab">
                            <form action="processa.php" method="POST">
                              <div class="form-row">
                                <div class="form-group col-md-6">
                                  <label for="nome">Código da Turma:</label>
                                  <input type="text" class="form-control" name="cod_turma" id="cod_turma" placeholder="Ex: 124">
                                </div>
                                <div class="form-group col-md-6">
                                  <label>Turno:</label>
                                  <div class="input select">
                                    <select name="turno_turma" class="form-control" id="turno_turma">
                                      <option value="">Selecione:</option>
                                      <option value="Matutino">Matutino</option>
                                      <option value="Vespertino">Vespertino</option>
                                      <option value="Noturno">Noturno</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6">
                                  <label for="curso" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="curso_turma" class="form-control" id="curso_turma">
                                      <option value="">Selecione:</option>
                                      <option value="Eletrotecnica">Eletrotécnica</option>
                                      <option value="Informatica">Informática</option>
                                      <option value="Mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-lg-6 col-md-6">
                                  <label for="periodo" class="texto">Período:</label>
                                  <div class="input select">
                                    <select name="periodo_turma" class="form-control" id="periodo_turma">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                              <input type="hidden" name="tipo" value="8">
                              <button type="submit" class="btn btn-primary btn-outline-light">Cadastrar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-buscarTurma" role="tabpanel" aria-labelledby="nav-buscar-tab">
                            <form action="ResultadosAdm.php" method="get">
                              <div class="form-row text-white">
                                  <input type="hidden" name="acao" value="buscarTurma">
                                    <div class="form-group col-md-6">
                                      <label for="nome">Código da Turma:</label>
                                      <div class="input select">
                                        <select name="cod_turma" class="form-control" id="cod_turma">
                                          <option value="">Selecione:</option>
                                          <<?php
                                          include_once "config.php";
                                          include_once "connection.php";

                                          session_start();

                                          $conexao = new Connection($host, $user, $password, $database);

                                          $sql ="SELECT cod_turma FROM turma ORDER BY cod_turma";
                                          $conexao->query($sql);
                                          for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                          {
                                            echo"<option value='$tupla[cod_turma]'> $tupla[cod_turma]</option>";
                                          }
                                          ?>
                                        </select>
                                      </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                      <label>Turno:</label>
                                      <div class="input select">
                                        <select name="turno_turma" class="form-control" id="turno_turma">
                                          <option value="">Selecione:</option>
                                          <option value="Matutino">Matutino</option>
                                          <option value="Vespertino">Vespertino</option>
                                          <option value="Noturno">Noturno</option>
                                        </select>
                                      </div>
                                    </div>

                                    <div class="form-group col-lg-6 col-md-6">
                                      <label for="curso" class="texto">Curso:</label>
                                      <div class="input select">
                                        <select name="curso_turma" class="form-control" id="curso_turma">
                                          <option value="">Selecione:</option>
                                          <option value="Eletrotecnica">Eletrotécnica</option>
                                          <option value="Informatica">Informática</option>
                                          <option value="Mecanica">Mecânica</option>
                                        </select>
                                      </div>
                                    </div>
                                    <div class="form-group col-lg-6 col-md-6">
                                      <label for="periodo" class="texto">Período:</label>
                                      <div class="input select">
                                        <select name="periodo_turma" class="form-control" id="periodo_turma">
                                          <option value="">Selecione:</option>
                                          <option value="1">1° Semestre</option>
                                          <option value="2">2° Semestre</option>
                                          <option value="3">3° Semestre</option>
                                          <option value="4">4° Semestre</option>
                                          <option value="5">5° Semestre</option>
                                          <option value="6">6° Semestre</option>
                                          <option value="7">7° Semestre</option>
                                        </select>
                                      </div>
                                  </div>
                              </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                      			</form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarTurma" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white mt-2">Listagem de Turmas:</h5><a href="ResultadosAdm.php?acao=listarTurma"><button type="submit" class="btn btn-primary btn-outline-light mt-3">Listar Todas</button></a>
                          </div>
                        </div>
                      </div>
                    </div>

              <div class="col-sm-12 col-p-6 col-lg-6 col-md-12 mb-4" id="administrador">
                      <a href="#administrador" onclick="Mudarestado('DivAdmin')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Administrador</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivAdmin" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-cadastrar-tab" data-toggle="tab" href="#nav-cadastrarAdmin" role="tab" aria-controls="nav-cadastrar-aluno" aria-selected="true">Cadastrar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarAdmin" role="tab" aria-controls="nav-listar-aluno" aria-selected="false">Listar</a></a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane fade show active text-white" id="nav-cadastrarAdmin" role="tabpanel" aria-labelledby="nav-cadastrar-tab">
                            <form action="processa.php" method="POST">
                              <div class="form-row">
                                <div class="form-group col-md-6">
                                  <label for="nome">Nome Completo:</label>
                                  <input type="text" class="form-control" name="nome_admin" id="nome_admin" placeholder="Nome Completo">
                                </div>
                                <div class="form-group col-md-6">
                                  <label for="nome">E-mail:</label>
                                  <input type="email" class="form-control" name="email_admin" id="email_admin">
                                </div>
                                <div class="form-group col-md-6">
                                  <label for="nome">Senha:</label>
                                  <input type="password" class="form-control" name="senha_admin" id="senha_admin">
                                </div>
                                <div class="form-group col-md-6">
                                  <label for="nome">Confirmar Senha:</label>
                                  <input type="password" class="form-control" name="csenha_admin" id="csenha_admin">
                                </div>
                              </div>
                              <input type="hidden" name="tipo" value="10">
                              <button type="submit" class="btn btn-primary btn-outline-light">Cadastrar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarAdmin" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white mt-2">Listagem de Turmas:</h5><a href="ResultadosAdm.php?acao=listarAdmin "><button type="submit" class="btn btn-primary btn-outline-light mt-3">Listar Todas</button></a>
                          </div>
                        </div>
                      </div>
                    </div>

            </div>
          </div>

          <div class="jumbotron px-6 pt-4 pb-0 mt-2 bg-primary" id="Vinculos">
            <h3 class="text-white">Vínculos de Disciplinas com:</h3>
            <div class="row d-flex">

              <div class="col-sm-12 col-p-6 col-lg-4 col-md-4 mb-4" id="SalaDisciplina">
                      <a href="#SalaDisciplina" onclick="Mudarestado('DivVinculoSD')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Salas</h4>
                          </div>
                        </div>
                       </a>
                      <div id="DivVinculoSD" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-vinculo-sala" role="tab" aria-controls="nav-home" aria-selected="true">Filtar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listar-vinculos-sala" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-listarVinculos" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Listar</a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">

                          <div class="tab-pane fade show active text-white" id="nav-vinculo-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="VincularSala.php" method="GET" name="f1" onsubmit="return verificaUsuario()">

                              <div class="form-row">
                                <div class="form-group col-xl-6 col-lg-12 col-p-12 col-md-12 col-sm-12">
                                  <label for="periodo" class="texto">Semestre:</label>
                                  <div class="input select">
                                    <select name="semestre" class="form-control" id="semestre">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-6 col-lg-12 col-p-12 col-md-12 col-sm-12">
                                  <label for="periodo" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="curso" class="form-control" id="curso">
                                      <option value="">Selecione:</option>
                                      <option value="eletrotecnica">Eletrotécnica</option>
                                      <option value="informatica">Informática</option>
                                      <option value="mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                                <button type="submit" class="btn btn-primary btn-outline-light">Filtrar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listar-vinculos-sala" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white">Selecione filtros para uma listagem especifica</h5>
                            <form action="ResultadosAdm.php" method="GET" name="f1" onsubmit="return verificaUsuario()">
                              <input type="hidden" name="acao" value="buscarVinculoSala">
                              <div class="form-row">
                                <div class="form-group col-xl-6 col-lg-6 col-p-12 col-md-12 col-sm-12 text-white">
                                  <label for="periodo" class="texto">Disciplina:</label>
                                  <div class="input select">
                                    <select name="cod_disciplina" class="form-control" id="cod_disciplina">
                                      <option value="">Selecione:</option>
                                      <?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $semestre=$_GET['semestre'];
                                      $curso= $_GET['curso'];
                                      $comum="comum";

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina WHERE periodo_disciplina LIKE '%$semestre%' AND curso_disciplina LIKE '%$curso%' ORDER BY descricao_disciplina";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_disciplina]'> $tupla[cod_disciplina] - $tupla[descricao_disciplina]</option>";
                                      }
                                      $sql2 ="SELECT cod_disciplina,descricao_disciplina,periodo_disciplina FROM disciplina WHERE periodo_disciplina LIKE '%$semestre%' AND curso_disciplina LIKE '%$comum%'";
                                      $conexao->query($sql2);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_disciplina]'> $tupla[cod_disciplina] - $tupla[descricao_disciplina]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-2 col-lg-2 col-p-12 col-md-12 col-sm-12 text-white">
                                  <label for="periodo" class="texto">Sala:</label>
                                  <div class="input select">
                                    <select name="cod_sala" class="form-control" id="cod_sala">
                                      <option value="">Selecione:</option>
                                      <<?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT cod_sala FROM sala ORDER BY cod_sala";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_sala]'> $tupla[cod_sala]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-4 col-lg-4 col-p-12 col-md-12 col-sm-12 text-white">
                                <label for="periodo" class="texto">Dia da semana:</label>
                                <div class="input select">
                                  <select name="diaSemana" class="form-control" id="diaSemana">
                                    <option value="">Selecione:</option>
                                    <option value="Segunda">Segunda Feira</option>
                                    <option value="Terca">Terça Feira</option>
                                    <option value="Quarta">Quarta Feira</option>
                                    <option value="Quinta">Quinta Feira</option>
                                    <option value="Sexta">Sexta Feira</option>
                                  </select>
                                </div>
                              </div>
                              </div>
                                <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-listarVinculos" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white mt-2">Listagem de todos os Vinculos de Disciplinas com as Salas!</h5>
                            <a href="ResultadosAdm.php?acao=listarVinculos"<button type="submit" class="btn btn-primary btn-outline-light">Listar todos</button></a>
                          </div>

                        </div>
                      </div>
              </div>

              <div class="col-sm-12 col-p-6 col-lg-4 col-md-4 mb-4" id="VinculoDisciplinaAluno">
                      <a href="#VinculoDisciplinaAluno" onclick="Mudarestado('DivDisciplinaAluno')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Alunos</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivDisciplinaAluno" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-vinculo-aluno" role="tab" aria-controls="nav-home" aria-selected="true">Vincular</a>
                            <a class="nav-item nav-link text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-vinculo-busca-aluno" role="tab" aria-controls="nav-profile" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-vinculos-lista-aluno" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Listar</a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">

                          <div class="tab-pane fade show active text-white" id="nav-vinculo-aluno" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="VincularAluno.php" method="GET">

                              <div class="form-row">
                                <div class="form-group col-xl-6 col-lg-12 col-p-12 col-md-12 col-sm-12">
                                  <label for="periodo" class="texto">Semestre:</label>
                                  <div class="input select">
                                    <select name="semestre" class="form-control" id="semestre">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-6 col-lg-12 col-p-12 col-md-12 col-sm-12">
                                  <label for="periodo" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="curso" class="form-control" id="curso">
                                      <option value="">Selecione:</option>
                                      <option value="eletrotecnica">Eletrotécnica</option>
                                      <option value="informatica">Informática</option>
                                      <option value="mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                                <button type="submit" class="btn btn-primary btn-outline-light">Filtrar</button>
                            </form>

                          </div>
                          <div class="tab-pane fade" id="nav-vinculo-busca-aluno" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <h5 class="text-white">Buscar os vinculos dos Alunos nas Disciplinas</h5>
                            <form action="ResultadosAdm.php" method="get">
                              <div class="form-row">
                                <div class="form-group col-md-12">
                                  <input type="hidden" name="acao" value="buscarVinculoAluno">
                                  <label for="nome" class="text-white">Nome:</label>
                                  <input type="text" class="form-control" name="nome" id="nome">
                                </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-vinculos-lista-aluno" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white">Listar os vinculos dos Alunos nas Disciplinas</h5>
                            <a href="ResultadosAdm.php?acao=listarVinculosAlunos"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>

                        </div>
                      </div>
              </div>

              <div class="col-sm-12 col-p-6 col-lg-4 col-md-4 mb-4" id="VinculoDisciplinaTurma">
                      <a href="#VinculoDisciplinaTurma" onclick="Mudarestado('DivDisciplinaTurma')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Turmas</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivDisciplinaTurma" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-vinculo-turma" role="tab" aria-controls="nav-home" aria-selected="true">Vincular</a>
                            <a class="nav-item nav-link text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-vinculo-busca-turma" role="tab" aria-controls="nav-profile" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-vinculos-lista-turma" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Listar</a>
                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">

                          <div class="tab-pane fade show active text-white" id="nav-vinculo-turma" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="VincularTurma.php" method="GET">

                              <div class="form-row">
                                <div class="form-group col-xl-6 col-lg-12 col-p-12 col-md-12 col-sm-12">
                                  <label for="periodo" class="texto">Semestre:</label>
                                  <div class="input select">
                                    <select name="semestre" class="form-control" id="semestre">
                                      <option value="">Selecione:</option>
                                      <option value="1">1° Semestre</option>
                                      <option value="2">2° Semestre</option>
                                      <option value="3">3° Semestre</option>
                                      <option value="4">4° Semestre</option>
                                      <option value="5">5° Semestre</option>
                                      <option value="6">6° Semestre</option>
                                      <option value="7">7° Semestre</option>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-xl-6 col-lg-12 col-p-12 col-md-12 col-sm-12">
                                  <label for="periodo" class="texto">Curso:</label>
                                  <div class="input select">
                                    <select name="curso" class="form-control" id="curso">
                                      <option value="">Selecione:</option>
                                      <option value="Eletrotecnica">Eletrotécnica</option>
                                      <option value="Informatica">Informática</option>
                                      <option value="Mecanica">Mecânica</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                                <button type="submit" class="btn btn-primary btn-outline-light">Filtrar</button>
                            </form>

                          </div>
                          <div class="tab-pane fade" id="nav-vinculo-busca-turma" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <h5 class="text-white">Buscar os vinculos das Turmas</h5>
                            <form action="ResultadosAdm.php" method="get">
                              <input type="hidden" name="acao" value="buscarVinculoTurma">
                              <div class="form-row">
                                <div class="form-group col-xl-3 col-lg-3 col-p-3 col-md-6 col-sm-6 text-white">
                                  <label for="nome">Código da Turma:</label>
                                  <div class="input select">
                                    <select name="cod_turma" class="form-control" id="cod_turma">
                                      <option value="">Selecione:</option>
                                      <?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT cod_turma FROM turma ORDER BY cod_turma";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[cod_turma]'> $tupla[cod_turma]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-vinculos-lista-turma" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white">Listar os vinculos das Turmas</h5>
                            <a href="ResultadosAdm.php?acao=listarVinculosTurmas"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>

                        </div>
                      </div>
              </div>

              <div class="col-sm-12 col-p-6 col-lg-12 col-md-4 mb-4" id="VinculoDisciplinaProfessor">
                      <a href="#VinculoDisciplinaProfessor" onclick="Mudarestado('DivDisciplinaProfessor')" class="card-link">
                        <div class="card py-4">
                          <div class="card-body text-center">
                            <h4 class="card-tittle">Professores</h4>
                          </div>
                        </div>
                      </a>
                      <div id="DivDisciplinaProfessor" class="jumbotron p-4 mt-2 bg-dark">
                        <nav>
                          <div class="nav nav-tabs" id="nav-tab" role="tablist">

                            <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-vinculo-professor" role="tab" aria-controls="nav-home" aria-selected="true">Vincular</a>
                            <a class="nav-item nav-link text-white" id="nav-profile-tab" data-toggle="tab" href="#nav-vinculo-busca-professor" role="tab" aria-controls="nav-profile" aria-selected="false">Buscar</a>
                            <a class="nav-item nav-link text-white" id="nav-listar-tab" data-toggle="tab" href="#nav-vinculos-lista-professor" role="tab" aria-controls="nav-listar-disciplina" aria-selected="false">Listar</a>

                          </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">

                          <div class="tab-pane fade show active text-white" id="nav-vinculo-professor" role="tabpanel" aria-labelledby="nav-home-tab">
                            <form action="processa.php" method="POST">
                              <input type="hidden" name="tipo" value="6">
                              <div class="form-row">
                                <div class="form-group col-lg-12 col-sm-12 col-md-12">
                                  <label for="nome">SIAPE - Professor:</label>
                                  <div class="input select">
                                    <select name="SIAPE" class="form-control" id="SIAPE">
                                      <option value="">Selecione:</option>
                                      <<?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      session_start();

                                      $conexao = new Connection($host, $user, $password, $database);

                                      $sql ="SELECT SIAPE, nome_professor FROM  professor ORDER BY nome_professor";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo"<option value='$tupla[SIAPE]'> $tupla[SIAPE] - $tupla[nome_professor]</option>";
                                      }
                                      ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="form-group col-lg-12 col-sm-12 col-md-12">
                                  <label for="nome">Vinculo:</label>
                                  <div style="overflow:scroll; height: 500px" class="form-check bg-white text-dark">
                                      <?php
                                      include_once "config.php";
                                      include_once "connection.php";

                                      $conexao = new Connection($host, $user, $password, $database);
                                      $sql ="SELECT v.cod_vinculo,v.cod_disciplina, d.descricao_disciplina,v.cod_sala,v.dia_semana,v.periodo,v.horario FROM vinculo v, disciplina d WHERE v.cod_disciplina LIKE d.cod_disciplina";
                                      $conexao->query($sql);
                                      for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                      {
                                        echo "<div class='py-3 px-4'>";
                                        echo "<input type='checkbox' class='form-check-input' name='vinculo[]' value='$tupla[cod_vinculo]'>";
                                        echo "<label class='form-check-label'>$tupla[cod_disciplina] : $tupla[descricao_disciplina] - $tupla[cod_sala] - $tupla[dia_semana] feira - $tupla[periodo] - $tupla[horario]° tempo</label><br>";
                                        echo "</div>";
                                      }
                                      ?>
                                  </div>
                                </div>
                              </div>

                              <button type="submit" class="btn btn-primary btn-outline-light">Vincular</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-vinculo-busca-professor" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <form action="ResultadosAdm.php" method="get">
                              <div class="form-row">
                                  <input type="hidden" name="acao" value="buscarVinculoProfessor">
                                  <div class="form-group col-lg-12 col-sm-12 col-md-12 text-white">
                                    <label for="nome">SIAPE - Professor:</label>
                                    <div class="input select">
                                      <select name="siape" class="form-control" id="siape">
                                        <option value="">Selecione:</option>
                                        <<?php
                                        include_once "config.php";
                                        include_once "connection.php";

                                        session_start();

                                        $conexao = new Connection($host, $user, $password, $database);

                                        $sql ="SELECT SIAPE, nome_professor FROM  professor ORDER BY nome_professor";
                                        $conexao->query($sql);
                                        for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                        {
                                          echo"<option value='$tupla[SIAPE]'> $tupla[SIAPE] - $tupla[nome_professor]</option>";
                                        }
                                        ?>
                                      </select>
                                    </div>
                                  </div>
                             </div>
                             <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                            </form>
                          </div>
                          <div class="tab-pane fade" id="nav-vinculos-lista-professor" role="tabpanel" aria-labelledby="nav-listar-tab">
                            <h5 class="text-white">Listar os vinculos dos Professores nas Disciplinas</h5>
                            <a href="ResultadosAdm.php?acao=listarVinculosProfessores"<button type="submit" class="btn btn-primary btn-outline-light">Listar Todas</button></a>
                          </div>

                        </div>
                      </div>
              </div>

            </div>
          </div>

          <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary" id="Horarios">
            <h3 class="text-white">Horários de:</h3>
             <div class="row d-flex">

               <div class="col-sm-12 col-p-3 col-xl-3 col-lg-3 col-md-12 mb-4" id="HorarioSala" >
                       <a href="#HorarioSala" onclick="Mudarestado('DivHorarioSala')" class="card-link">
                         <div class="card py-4">
                           <div class="card-body text-center">
                             <h4 class="card-tittle">Salas</h4>
                           </div>
                         </div>
                        </a>
                       <div id="DivHorarioSala" class="jumbotron p-4 mt-2 bg-dark">
                         <nav>
                           <div class="nav nav-tabs" id="nav-tab" role="tablist">
                             <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-horario-sala" role="tab" aria-controls="nav-home" aria-selected="true">Selecionar</a>
                           </div>
                         </nav>
                         <div class="tab-content" id="nav-tabContent">

                           <div class="tab-pane fade show active text-white" id="nav-horario-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                             <form action="ResultadosAdm.php" method="GET">
                               <div class="form-row">
                                 <div class="form-group col-md-12 mt-3">
                                   <label for="inputName">Codigo da Sala:</label>
                                   <div class="input select">
                                     <select name="cod_sala" class="form-control" id="cod_sala">
                                       <option value="">Selecione:</option>
                                       <<?php
                                       include_once "config.php";
                                       include_once "connection.php";

                                       session_start();

                                       $conexao = new Connection($host, $user, $password, $database);

                                       $sql ="SELECT cod_sala FROM sala ORDER BY cod_sala";
                                       $conexao->query($sql);
                                       for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                       {
                                         echo"<option value='$tupla[cod_sala]'> $tupla[cod_sala]</option>";
                                       }
                                       ?>
                                     </select>
                                   </div>
                                 </div>

                               </div>
                               <input type="hidden" name="acao" value="horarioSala">
                               <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                             </form>
                           </div>

                         </div>
                       </div>
                     </div>

               <div class="col-sm-12 col-p-3 col-xl-9 col-lg-9 col-md-12 mb-4" id="HorarioProfessor">
                       <a href="#HorarioProfessor" onclick="Mudarestado('DivHorarioProfessor')" class="card-link">
                         <div class="card py-4">
                           <div class="card-body text-center">
                             <h4 class="card-tittle">Professores</h4>
                           </div>
                         </div>
                       </a>
                       <div id="DivHorarioProfessor" class="jumbotron p-4 mt-2 bg-dark">
                         <nav>
                           <div class="nav nav-tabs" id="nav-tab" role="tablist">

                             <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-horario-professor" role="tab" aria-controls="nav-home" aria-selected="true">Selecionar</a>

                           </div>
                         </nav>
                         <div class="tab-content" id="nav-tabContent">

                           <div class="tab-pane fade show active text-white" id="nav-horario-professor" role="tabpanel" aria-labelledby="nav-home-tab">
                             <form action="ResultadosAdm.php" method="GET">
                               <input type="hidden" name="acao" value="horarioProfessor">
                               <div class="form-row">
                                 <div class="form-group col-lg-12 col-sm-12 col-md-12">
                                   <label for="nome">SIAPE - Professor:</label>
                                   <div class="input select">
                                     <select name="SIAPE" class="form-control" id="SIAPE">
                                       <option value="">Selecione:</option>
                                       <<?php
                                       include_once "config.php";
                                       include_once "connection.php";

                                       session_start();

                                       $conexao = new Connection($host, $user, $password, $database);

                                       $sql ="SELECT SIAPE, nome_professor FROM  professor ORDER BY nome_professor";
                                       $conexao->query($sql);
                                       for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                       {
                                         echo"<option value='$tupla[SIAPE]'> $tupla[SIAPE] - $tupla[nome_professor]</option>";
                                       }
                                       ?>
                                     </select>
                                   </div>
                                 </div>
                               </div>

                               <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                             </form>
                           </div>

                         </div>
                       </div>
               </div>

               <div class="col-sm-12 col-p-3 col-xl-3 col-lg-3 col-md-12 mb-4" id="HorarioTurma" >
                       <a href="#HorarioTurma" onclick="Mudarestado('DivHorarioTurma')" class="card-link">
                         <div class="card py-4">
                           <div class="card-body text-center">
                             <h4 class="card-tittle">Turmas</h4>
                           </div>
                         </div>
                        </a>
                       <div id="DivHorarioTurma" class="jumbotron p-4 mt-2 bg-dark">
                         <nav>
                           <div class="nav nav-tabs" id="nav-tab" role="tablist">
                             <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-horario-sala" role="tab" aria-controls="nav-home" aria-selected="true">Selecionar</a>
                           </div>
                         </nav>
                         <div class="tab-content" id="nav-tabContent">

                           <div class="tab-pane fade show active text-white" id="nav-horario-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                             <form action="ResultadosAdm.php" method="GET">
                               <div class="form-row">
                                 <div class="form-group col-xl-12 col-lg-12 col-p-12 col-md-12 col-sm-12 text-white">
                                   <label for="nome">Código da Turma:</label>
                                   <div class="input select">
                                     <select name="cod_turma" class="form-control" id="cod_turma">
                                       <option value="">Selecione:</option>
                                       <?php
                                       include_once "config.php";
                                       include_once "connection.php";

                                       session_start();

                                       $conexao = new Connection($host, $user, $password, $database);

                                       $sql ="SELECT cod_turma FROM turma ORDER BY cod_turma";
                                       $conexao->query($sql);
                                       for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                       {
                                         echo"<option value='$tupla[cod_turma]'> $tupla[cod_turma]</option>";
                                       }
                                       ?>
                                     </select>
                                   </div>
                                 </div>
                               </div>
                               <input type="hidden" name="acao" value="horarioTurma">
                               <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                             </form>
                           </div>

                         </div>
                       </div>
                     </div>

               <div class="col-sm-12 col-p-3 col-xl-9 col-lg-9 col-md-12 mb-4" id="HorarioAluno">
                       <a href="#HorarioAluno" onclick="Mudarestado('DivHorarioAluno')" class="card-link">
                         <div class="card py-4">
                           <div class="card-body text-center">
                             <h4 class="card-tittle">Alunos</h4>
                           </div>
                         </div>
                       </a>
                       <div id="DivHorarioAluno" class="jumbotron p-4 mt-2 bg-dark">
                         <nav>
                           <div class="nav nav-tabs" id="nav-tab" role="tablist">
                             <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-vinculo-aluno" role="tab" aria-controls="nav-home" aria-selected="true">Filtrar Alunos</a>
                           </div>
                         </nav>
                         <div class="tab-content" id="nav-tabContent">

                           <div class="tab-pane fade show active text-white" id="nav-vinculo-aluno" role="tabpanel" aria-labelledby="nav-home-tab">
                             <form action="BuscaHorarioAluno.php" method="POST">
                               <div class="form-row">
                                 <div class="form-group col-xl-12 col-lg-6 col-p-12 col-md-12 col-sm-12">
                                   <label for="periodo" class="texto">Semestre:</label>
                                   <div class="input select">
                                     <select name="semestre" class="form-control" id="semestre">
                                       <option value="">Selecione:</option>
                                       <option value="1">1° Semestre</option>
                                       <option value="2">2° Semestre</option>
                                       <option value="3">3° Semestre</option>
                                       <option value="4">4° Semestre</option>
                                       <option value="5">5° Semestre</option>
                                       <option value="6">6° Semestre</option>
                                       <option value="7">7° Semestre</option>
                                     </select>
                                   </div>
                                 </div>
                                 <div class="form-group col-xl-12 col-lg-6 col-p-12 col-md-12 col-sm-12">
                                   <label for="Curso" class="texto">Curso:</label>
                                   <div class="input select">
                                     <select name="curso" class="form-control" id="curso">
                                       <option value="">Selecione:</option>
                                       <option value="eletrotecnica">Eletrotécnica</option>
                                       <option value="informatica">Informática</option>
                                       <option value="mecanica">Mecânica</option>
                                     </select>
                                   </div>
                                 </div>
                               </div>

                               <button type="submit" class="btn btn-primary btn-outline-light">Filtrar</button>
                             </form>
                           </div>
                           <div class="tab-pane fade" id="nav-vinculo-busca-aluno" role="tabpanel" aria-labelledby="nav-profile-tab">
                             <h5 class="text-white">Buscar os vinculos dos Alunos nas Disciplinas</h5>
                           </div>

                         </div>
                       </div>
               </div>

             </div>
          </div>

      <script>
         window.onload = function(){
         document.getElementById("DivAluno").style.display = 'none';
         document.getElementById("DivProfessor").style.display = 'none';
         document.getElementById("DivSala").style.display = 'none';
         document.getElementById("DivDisciplina").style.display = 'none';
         document.getElementById("DivTurma").style.display = 'none';
         document.getElementById("DivVinculoSD").style.display = 'none';
         document.getElementById("DivDisciplinaProfessor").style.display = 'none';
         document.getElementById("DivDisciplinaAluno").style.display = 'none';
         document.getElementById("DivHorarioSala").style.display = 'none';
         document.getElementById("DivHorarioProfessor").style.display = 'none';
         document.getElementById("DivHorarioAluno").style.display = 'none';
         document.getElementById("DivDisciplinaTurma").style.display = 'none';
         document.getElementById("DivHorarioTurma").style.display = 'none';
         document.getElementById("DivAdmin").style.display = 'none';


         }
      </script>
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
    </body>
</html>
