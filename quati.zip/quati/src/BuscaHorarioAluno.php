<!doctype html>
<html lang="pt-br">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>InFo IF</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/styles.css">
  </head>

  <body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="index.php"><span><img src="../images/logoScoo.png" style="width:50px"alt=""> </span></a>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/site">Site IFMS</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://academico.ifms.edu.br/">Sistema Acadêmico</a></li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://selecao.ifms.edu.br/">Central de Seleção</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://www.ifms.edu.br/assuntos/estudante/calendario">Calendário</a> </li>
          <div class="dropdown-divider"></div>
          <li class="nav-item"> <a class="nav-link" href="http://biblioteca.ifms.edu.br/pergamum/biblioteca/index.php">Biblioteca</a></li>

        </ul>
      </div>
    </nav>

    <div class="container mt-4">
      <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-dark">
        <div class="jumbotron px-6 pt-4 pb-2 mt-2 bg-primary">
          <h3 class="text-white">Horario do Aluno</h3>

          <div class="row d-flex">

            <div class="col-sm-12 col-p-6 col-lg-12 col-md-12 mb-4" id="SalaDisciplina">

                  <div id="DivVinculoSala" class="jumbotron p-4 mt-2 bg-dark">
                      <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                          <a class="nav-item nav-link active text-white" id="nav-home-tab" data-toggle="tab" href="#nav-cadastro-vinculo-sala" role="tab" aria-controls="nav-home" aria-selected="true">Selecionar Aluno</a>
                        </div>
                      </nav>
                      <div class="tab-content" id="nav-tabContent">

                        <div class="tab-pane fade show active text-white" id="nav-cadastro-vinculo-sala" role="tabpanel" aria-labelledby="nav-home-tab">
                          <form action="HorarioAluno.php" class="form-group" method="GET">
                            <input type="hidden" name="acao" value="HorarioAluno">
                            <div class="row d-flex text-white">
                              <div class="form-group col-lg-12 col-sm-12 col-md-12">
                                <label for="nome">RA - Aluno:</label>
                                <div class="input select">
                                  <select name="RA" class="form-control" id="RA">
                                    <option value="">Selecione:</option>
                                    <<?php
                                    include_once "config.php";
                                    include_once "connection.php";

                                    session_start();

                                    $conexao = new Connection($host, $user, $password, $database);
                                    $semestre=$_POST['semestre'];
                                    $curso= $_POST['curso'];

                                    $sql ="SELECT RA, nome_aluno FROM aluno WHERE periodo_aluno LIKE '%$semestre%' AND curso_aluno LIKE '%$curso%' ORDER BY nome_aluno";
                                    $conexao->query($sql);
                                    for($tupla = $conexao->fetch_assoc(); $tupla != NULL; $tupla = $conexao->fetch_assoc())
                                    {
                                      echo"<option value='$tupla[RA]'> $tupla[RA] - $tupla[nome_aluno]</option>";
                                    }
                                    ?>
                                  </select>
                                </div>
                              </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-outline-light">Buscar</button>
                          </form>
                        </div>
                      </div>
                    </div>
            </div>

          </div>
        </div>
      </div>

    </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>

  </body>
